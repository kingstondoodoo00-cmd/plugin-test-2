package com.example.cbspawner;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.BlockCommandSender;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ProxiedCommandSender;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.minecart.CommandMinecart;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The Arrow Cannon (like the arrow cannons / railguns on the SMP): a fishing rod that works the same way as the
 * Ender Pearl Cannon. Cast it, then reel in (unhook) while pointing at something: a volley of extremely fast
 * arrows slams down on that spot from 20 blocks up, fired by you only (it does not use /link).
 * The rod breaks after one use.
 *
 * Arrows do more damage the faster they fly, and these fly very fast; the volley comes in rapid waves and each
 * arrow ignores the target's hit-immunity, so they land as several quick hits.
 *
 * Get it with  /give:arrowcannon [player]  (or /give <player> arrowcannon) from chat or the console.
 * Command blocks cannot give it.
 */
public class ArrowCannon implements Listener {

    private static final String ITEM_ID = "arrowcannon";
    private static final String DOMAIN_WORLD_NAME = "black_domain";

    private static final Material CANNON_MATERIAL = Material.FISHING_ROD;
    /** Shows as "Durability: 8 / 64" so it can be told apart from the Ender Pearl Cannon (4 / 64). */
    private static final int MAX_DURABILITY = 64;
    private static final int DURABILITY_LEFT = 8;

    private static final double RANGE = 150.0;
    private static final double SPAWN_HEIGHT = 20.0;
    /** How many blocks apart the shooters' arrows land from each other. */
    private static final double SPACING = 2.0;
    /** The volley: this many waves, a couple of ticks apart, one arrow per shooter in each wave. */
    private static final int WAVES = 8;
    /** Arrows each shooter sends per wave, scattered around their landing spot, so the ground fills with arrows. */
    private static final int ARROWS_PER_WAVE = 12;
    /** Half of the arrows land tightly on the target (so it takes the hits); the rest rain over a wide area. */
    private static final double ARROW_SCATTER_TIGHT = 2.0;
    private static final double ARROW_SCATTER_WIDE = 14.0;
    /** 0 = every wave comes out in the same tick, so all the arrows leave together and land together. */
    private static final int TICKS_BETWEEN_WAVES = 0;
    /** Arrow speed in blocks per tick (a normal full bow shot is about 3). Damage grows with speed. */
    private static final double ARROW_SPEED = 14.0;
    /** Base arrow damage: the arrow hits for about speed x this, before armor. */
    private static final double ARROW_BASE_DAMAGE = 5.0;
    /** The arrows stay stuck in the ground for this long (30 seconds). */
    private static final int ARROW_LIFETIME_TICKS = 600;
    private static final int MAX_GIVE = 36;
    /** Every arrow that hits a player wears down EACH armor piece by this share of its max durability (0.04 = 4%). */
    private static final double ARMOR_DAMAGE_FRACTION = 0.04;

    private final Random random = new Random();
    private final JavaPlugin plugin;
    private final NamespacedKey cannonKey;
    private final NamespacedKey arrowKey;

    public ArrowCannon(JavaPlugin plugin) {
        this.plugin = plugin;
        this.cannonKey = new NamespacedKey(plugin, "arrow_cannon");
        this.arrowKey = new NamespacedKey(plugin, "cannon_arrow");
    }

    // ---- The item ----

    public ItemStack createCannon() {
        // A plain-looking fishing rod: only a hidden tag and the durability (8 left of 64) mark it
        ItemStack item = new ItemStack(CANNON_MATERIAL);
        ItemMeta meta = item.getItemMeta();
        if (meta instanceof Damageable damageable) {
            damageable.setMaxDamage(MAX_DURABILITY);
            damageable.setDamage(MAX_DURABILITY - DURABILITY_LEFT);
        }
        meta.getPersistentDataContainer().set(cannonKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isCannon(ItemStack stack) {
        if (stack == null || stack.getType() != CANNON_MATERIAL || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(cannonKey, PersistentDataType.BYTE);
    }

    // ---- Reeling in (unhooking) ----

    @EventHandler
    public void onFish(PlayerFishEvent event) {
        PlayerFishEvent.State state = event.getState();
        if (state != PlayerFishEvent.State.REEL_IN && state != PlayerFishEvent.State.IN_GROUND
                && state != PlayerFishEvent.State.CAUGHT_ENTITY && state != PlayerFishEvent.State.CAUGHT_FISH
                && state != PlayerFishEvent.State.FAILED_ATTEMPT) {
            return;
        }
        Player player = event.getPlayer();
        EquipmentSlot hand = event.getHand();
        if (hand == null) return;
        ItemStack rod = player.getInventory().getItem(hand);
        if (!isCannon(rod)) return;

        // The cannon never catches anything: it just fires
        event.setCancelled(true);
        event.getHook().remove();

        RayTraceResult hit = player.getWorld().rayTrace(player.getEyeLocation(), player.getEyeLocation().getDirection(),
                RANGE, FluidCollisionMode.NEVER, true, 0.2, e -> !e.equals(player));
        if (hit == null) {
            player.sendActionBar(Component.text("Point at a block or player to fire.", NamedTextColor.RED));
            return;
        }
        Vector target = hit.getHitPosition();

        // No link system: only the person holding the rod fires
        List<Player> shooters = new ArrayList<>();
        shooters.add(player);

        World w = player.getWorld();
        Location above = spawnPoint(w, target);
        List<Location> spots = new ArrayList<>();
        for (int i = 0; i < shooters.size(); i++) {
            // Spiral around the target so the shooters' arrows don't all land on one spot
            double radius = SPACING * Math.sqrt(i);
            double angle = i * 2.399963;
            Location at = above.clone().add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
            spots.add(at.getBlock().isPassable() ? at : above.clone());
        }

        for (int wave = 0; wave < WAVES; wave++) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                for (int i = 0; i < shooters.size(); i++) {
                    Player shooter = shooters.get(i);
                    if (!shooter.isOnline()) continue;
                    for (int k = 0; k < ARROWS_PER_WAVE; k++) {
                        double spread = k % 2 == 0 ? ARROW_SCATTER_TIGHT : ARROW_SCATTER_WIDE;
                        Location scattered = spots.get(i).clone().add((random.nextDouble() * 2 - 1) * spread, 0,
                                (random.nextDouble() * 2 - 1) * spread);
                        if (!scattered.getBlock().isPassable()) scattered = spots.get(i);
                        fireArrow(w, scattered, shooter);
                    }
                }
            }, (long) wave * TICKS_BETWEEN_WAVES);
        }

        w.playSound(player.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1.0f, 0.5f);
        w.playSound(target.toLocation(w), Sound.ENTITY_GENERIC_EXPLODE, 0.5f, 2.0f);
        w.spawnParticle(Particle.CRIT, target.toLocation(w), 40, 0.6, 0.6, 0.6, 0.5);

        // One use, then the rod breaks
        player.getInventory().setItem(hand, null);
        w.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
    }

    private void fireArrow(World w, Location at, Player shooter) {
        Arrow arrow = w.spawn(at, Arrow.class, a -> {
            a.setShooter(shooter);
            a.setCritical(true);
            a.setDamage(ARROW_BASE_DAMAGE);
            a.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
            a.setPersistent(false);
            a.getPersistentDataContainer().set(arrowKey, PersistentDataType.BYTE, (byte) 1);
            a.setVelocity(new Vector(0, -ARROW_SPEED, 0));
        });
        // Don't leave arrows lying around
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (arrow.isValid()) arrow.remove();
        }, ARROW_LIFETIME_TICKS);
    }

    /** The point 20 blocks above the target, or just under a ceiling if something is in the way. */
    private Location spawnPoint(World w, Vector target) {
        Location base = target.toLocation(w);
        RayTraceResult up = w.rayTraceBlocks(base.clone().add(0, 0.3, 0), new Vector(0, 1, 0), SPAWN_HEIGHT,
                FluidCollisionMode.NEVER, true);
        if (up != null) {
            return up.getHitPosition().toLocation(w).subtract(0, 0.6, 0);
        }
        return base.add(0, SPAWN_HEIGHT, 0);
    }

    /** Cannon arrows ignore the target's hit-immunity, so every arrow of the volley counts as its own hit. */
    @EventHandler
    public void onArrowHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Arrow arrow)) return;
        if (!arrow.getPersistentDataContainer().has(arrowKey, PersistentDataType.BYTE)) return;
        // Shield: the people firing the cannon are never hit by its arrows (this is the job of the TNT block
        // in the video, which just sits over the shooter to block arrows). The arrow flies on through them.
        if (event.getHitEntity() instanceof Player hit
                && hit.equals(arrow.getShooter())) {
            event.setCancelled(true);
            return;
        }
        if (event.getHitEntity() instanceof LivingEntity target) {
            target.setNoDamageTicks(0);
            if (target instanceof Player player && player.getGameMode() != org.bukkit.GameMode.CREATIVE) {
                wearDownArmor(player);
            }
        }
    }

    /** The arrows chew through armor: each hit takes a big bite out of every piece, and pieces can shatter. */
    private void wearDownArmor(Player player) {
        ItemStack[] armor = player.getInventory().getArmorContents();
        boolean broke = false;
        for (int i = 0; i < armor.length; i++) {
            ItemStack piece = armor[i];
            if (piece == null || piece.getType() == Material.AIR || !(piece.getItemMeta() instanceof Damageable meta)) continue;
            int max = meta.hasMaxDamage() ? meta.getMaxDamage() : piece.getType().getMaxDurability();
            if (max <= 0) continue;
            int damage = meta.getDamage() + Math.max(1, (int) Math.round(max * ARMOR_DAMAGE_FRACTION));
            if (damage >= max) {
                armor[i] = null; // shattered
                broke = true;
            } else {
                meta.setDamage(damage);
                piece.setItemMeta(meta);
            }
        }
        player.getInventory().setArmorContents(armor);
        if (broke) {
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 0.8f);
        }
    }

    // ---- Getting it: /give <player> arrowcannon ----

    private boolean isFromCommandBlock(CommandSender sender) {
        if (sender instanceof ProxiedCommandSender proxied) {
            return isFromCommandBlock(proxied.getCaller()) || isFromCommandBlock(proxied.getCallee());
        }
        return sender instanceof BlockCommandSender || sender instanceof CommandMinecart;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        String message = event.getMessage();
        if (!message.startsWith("/")) return;
        if (handleGive(event.getPlayer(), message.substring(1))) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onServerCommand(ServerCommandEvent event) {
        if (handleGive(event.getSender(), event.getCommand())) event.setCancelled(true);
    }

    /** Returns true if this was a  /give <targets> arrowcannon  that we dealt with. */
    private boolean handleGive(CommandSender sender, String commandLine) {
        String[] t = commandLine.trim().split("\\s+");
        if (t.length < 1 || t[0].isEmpty()) return false;
        String cmd = t[0].toLowerCase();
        String targetArg;
        String countArg;
        if (cmd.equals("give:" + ITEM_ID) || cmd.equals("minecraft:give:" + ITEM_ID)) {
            // Short form:  /give:arrowcannon [player] [count]
            targetArg = t.length >= 2 ? t[1] : "@s";
            countArg = t.length >= 3 ? t[2] : null;
        } else if (cmd.equals("give") || cmd.equals("minecraft:give")) {
            // Normal form:  /give <player> arrowcannon [count]
            if (t.length < 3) return false;
            String item = t[2].toLowerCase();
            if (item.startsWith("minecraft:")) item = item.substring("minecraft:".length());
            if (!item.equals(ITEM_ID)) return false;
            targetArg = t[1];
            countArg = t.length >= 4 ? t[3] : null;
        } else {
            return false;
        }

        // From here on it is ours. Command blocks are silently refused.
        if (isFromCommandBlock(sender)) return true;
        if (!sender.hasPermission("minecraft.command.give") && !sender.isOp()) {
            sender.sendMessage(Component.text("You don't have permission to do that.", NamedTextColor.RED));
            return true;
        }

        int count = 1;
        if (countArg != null) {
            try {
                count = Math.max(1, Math.min(MAX_GIVE, Integer.parseInt(countArg)));
            } catch (NumberFormatException e) {
                sender.sendMessage(Component.text("Usage: /give:arrowcannon [player] [count]", NamedTextColor.RED));
                return true;
            }
        }

        int given = 0;
        try {
            for (Entity e : plugin.getServer().selectEntities(sender, targetArg)) {
                if (!(e instanceof Player target)) continue;
                for (int i = 0; i < count; i++) {
                    target.getInventory().addItem(createCannon())
                            .values().forEach(left -> target.getWorld().dropItemNaturally(target.getLocation(), left));
                }
                target.sendMessage(Component.text("You received the Arrow Cannon!", NamedTextColor.DARK_AQUA));
                given++;
            }
        } catch (IllegalArgumentException ex) {
            Player byName = plugin.getServer().getPlayerExact(targetArg);
            if (byName != null) {
                for (int i = 0; i < count; i++) {
                    byName.getInventory().addItem(createCannon())
                            .values().forEach(left -> byName.getWorld().dropItemNaturally(byName.getLocation(), left));
                }
                byName.sendMessage(Component.text("You received the Arrow Cannon!", NamedTextColor.DARK_AQUA));
                given++;
            }
        }
        if (given == 0) {
            sender.sendMessage(Component.text("No player found for '" + targetArg + "'.", NamedTextColor.RED));
        } else {
            sender.sendMessage(Component.text("Gave the Arrow Cannon to " + given + " player(s).",
                    NamedTextColor.DARK_AQUA));
        }
        return true;
    }
}
