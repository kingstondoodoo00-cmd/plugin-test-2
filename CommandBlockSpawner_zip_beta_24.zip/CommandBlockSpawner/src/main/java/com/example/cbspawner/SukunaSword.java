package com.example.cbspawner;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.LargeFireball;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * The Command Block Sword, based on Sukuna from Jujutsu Kaisen.
 * Shift + right-click: switch move. Right-click: use the move.
 * Moves: Dismantle, Cleave, Fuga and Malevolent Shrine.
 */
public class SukunaSword implements Listener {

    private enum Move {
        DISMANTLE("Dismantle", 3_000L),
        CLEAVE("Cleave", 5_000L),
        FUGA("Fuga", 20_000L),
        MALEVOLENT_SHRINE("Malevolent Shrine", 60_000L);

        final String label;
        final long cooldownMs;

        Move(String label, long cooldownMs) {
            this.label = label;
            this.cooldownMs = cooldownMs;
        }

        Move next() {
            Move[] all = values();
            return all[(ordinal() + 1) % all.length];
        }
    }

    // ---- Tuning ----

    /** Dismantle: a flurry of invisible slashes in front of you. */
    private static final int DISMANTLE_SLASHES = 6;
    private static final double DISMANTLE_RANGE = 16.0;
    private static final double DISMANTLE_DAMAGE = 16.0;

    /** Cleave: one cut that scales with how tough the target is. */
    private static final double CLEAVE_RANGE = 25.0;
    private static final double CLEAVE_MIN_DAMAGE = 30.0;
    private static final double CLEAVE_HEALTH_FRACTION = 0.8;

    /** Fuga: a huge flaming arrow. */
    private static final float FUGA_YIELD = 12.0f;
    private static final double FUGA_SPEED = 2.5;

    /** Malevolent Shrine: everything around you is slashed over and over. */
    private static final double SHRINE_RADIUS = 14.0;
    private static final int SHRINE_TICKS = 160;
    private static final int SHRINE_INTERVAL = 4;
    private static final double SHRINE_DAMAGE = 8.0;

    /**
     * Normal hits: a full-strength hit takes this fraction of a player's max health AFTER armor and enchantments,
     * so 0.2 means a player wearing Protection IV armor dies in 5 hits.
     */
    private static final double HIT_HEALTH_FRACTION = 0.2;

    private final JavaPlugin plugin;
    private final NamespacedKey swordKey;
    private final NamespacedKey moveKey;
    private final Random random = new Random();
    private final Map<UUID, Map<Move, Long>> cooldowns = new HashMap<>();

    public SukunaSword(JavaPlugin plugin) {
        this.plugin = plugin;
        this.swordKey = new NamespacedKey(plugin, "sukuna_sword");
        this.moveKey = new NamespacedKey(plugin, "sukuna_move");
    }

    // ---- The item ----

    public ItemStack createSword() {
        ItemStack item = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Command Block Sword", NamedTextColor.DARK_RED, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                line("The King of Curses' blade", NamedTextColor.GRAY),
                line("Shift + right-click: switch move", NamedTextColor.DARK_GRAY),
                line("Right-click: use the move", NamedTextColor.DARK_GRAY),
                line("Dismantle, Cleave, Fuga, Malevolent Shrine", NamedTextColor.DARK_RED)));
        // Enchanted instead of unbreakable, so Mending and Unbreaking actually do something
        meta.addEnchant(Enchantment.SHARPNESS, 5, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(swordKey, PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(moveKey, PersistentDataType.INTEGER, 0);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isSword(ItemStack stack) {
        if (stack == null || stack.getType() != Material.NETHERITE_SWORD || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(swordKey, PersistentDataType.BYTE);
    }

    private static Component line(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private Move currentMove(ItemStack sword) {
        int i = sword.getItemMeta().getPersistentDataContainer().getOrDefault(moveKey, PersistentDataType.INTEGER, 0);
        Move[] all = Move.values();
        return all[Math.floorMod(i, all.length)];
    }

    private void setMove(ItemStack sword, Move move) {
        ItemMeta meta = sword.getItemMeta();
        meta.getPersistentDataContainer().set(moveKey, PersistentDataType.INTEGER, move.ordinal());
        sword.setItemMeta(meta);
    }

    // ---- Using it ----

    @EventHandler
    public void onUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
        Player player = event.getPlayer();
        ItemStack sword = player.getInventory().getItemInMainHand();
        if (!isSword(sword)) return;
        event.setCancelled(true);

        if (player.isSneaking()) {
            Move next = currentMove(sword).next();
            setMove(sword, next);
            player.getInventory().setItemInMainHand(sword);
            player.sendActionBar(Component.text("Move: " + next.label, NamedTextColor.DARK_RED));
            player.playSound(player.getLocation(), Sound.ITEM_ARMOR_EQUIP_NETHERITE, 1.0f, 1.2f);
            return;
        }

        Move move = currentMove(sword);
        long now = System.currentTimeMillis();
        Long readyAt = cooldowns.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>()).get(move);
        if (readyAt != null && now < readyAt) {
            long left = (readyAt - now + 999) / 1000;
            player.sendActionBar(Component.text(move.label + " recharging: " + left + "s", NamedTextColor.RED));
            return;
        }

        boolean used = switch (move) {
            case DISMANTLE -> dismantle(player);
            case CLEAVE -> cleave(player);
            case FUGA -> fuga(player);
            case MALEVOLENT_SHRINE -> malevolentShrine(player);
        };
        if (used) {
            cooldowns.get(player.getUniqueId()).put(move, now + move.cooldownMs);
            player.sendActionBar(Component.text(move.label + "!", NamedTextColor.DARK_RED));
        }
    }

    // ---- Normal hits: 5 taps, even through Protection IV ----

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent event) {
        if (event.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        if (!(event.getDamager() instanceof Player attacker) || !(event.getEntity() instanceof Player victim)) return;
        if (!isSword(attacker.getInventory().getItemInMainHand())) return;
        if (attacker.getAttackCooldown() < 0.9f) return; // only full-strength hits, so spam-clicking doesn't count

        double maxHealth = victim.getAttribute(Attribute.MAX_HEALTH) != null
                ? victim.getAttribute(Attribute.MAX_HEALTH).getValue() : 20.0;
        double wanted = maxHealth * HIT_HEALTH_FRACTION;

        // Armor reduction isn't a straight percentage, so raise the base damage until the damage that
        // actually lands (after armor, Protection and so on) is what we want.
        for (int i = 0; i < 10 && event.getFinalDamage() < wanted - 0.01; i++) {
            double landed = event.getFinalDamage();
            double base = event.getDamage();
            event.setDamage(landed <= 0.0001 ? base * 2 + 1 : Math.min(5000.0, base * wanted / landed));
        }
    }

    // ---- Dismantle ----

    private boolean dismantle(Player player) {
        World w = player.getWorld();
        w.playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.6f);
        new BukkitRunnable() {
            int count = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead() || count >= DISMANTLE_SLASHES) {
                    cancel();
                    return;
                }
                count++;
                // Each slash is aimed a little differently, around where you are looking
                Vector dir = player.getEyeLocation().getDirection().clone();
                dir.rotateAroundY(Math.toRadians((random.nextDouble() - 0.5) * 50));
                dir.setY(dir.getY() + (random.nextDouble() - 0.5) * 0.5).normalize();
                slashLine(player, dir);
            }
        }.runTaskTimer(plugin, 0L, 2L);
        return true;
    }

    /** One invisible slash: hurts everything along a line and draws sparks on it. */
    private void slashLine(Player player, Vector dir) {
        World w = player.getWorld();
        Location start = player.getEyeLocation();
        Set<UUID> hit = new HashSet<>();
        for (double d = 1.0; d <= DISMANTLE_RANGE; d += 1.0) {
            Location p = start.clone().add(dir.clone().multiply(d));
            if (!p.getBlock().isPassable()) break;
            w.spawnParticle(Particle.SWEEP_ATTACK, p, 1, 0, 0, 0, 0);
            w.spawnParticle(Particle.CRIT, p, 3, 0.15, 0.15, 0.15, 0.05);
            for (LivingEntity target : w.getNearbyLivingEntities(p, 1.2)) {
                if (target.equals(player) || !hit.add(target.getUniqueId())) continue;
                target.setNoDamageTicks(0);
                target.damage(DISMANTLE_DAMAGE, player);
            }
        }
        w.playSound(start, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 0.6f, 1.4f);
    }

    // ---- Cleave ----

    private boolean cleave(Player player) {
        World w = player.getWorld();
        RayTraceResult hit = w.rayTraceEntities(player.getEyeLocation(), player.getEyeLocation().getDirection(),
                CLEAVE_RANGE, 0.6, e -> e instanceof LivingEntity && !e.equals(player));
        if (hit == null || !(hit.getHitEntity() instanceof LivingEntity target)) {
            player.sendActionBar(Component.text("Look at something to Cleave.", NamedTextColor.RED));
            return false;
        }
        // The tougher the target, the deeper the cut
        double maxHealth = target.getAttribute(Attribute.MAX_HEALTH) != null
                ? target.getAttribute(Attribute.MAX_HEALTH).getValue() : 20.0;
        double damage = Math.max(CLEAVE_MIN_DAMAGE, maxHealth * CLEAVE_HEALTH_FRACTION);

        Location at = target.getLocation().add(0, target.getHeight() / 2, 0);
        w.spawnParticle(Particle.SWEEP_ATTACK, at, 6, 0.5, 0.5, 0.5, 0);
        w.spawnParticle(Particle.CRIT, at, 30, 0.5, 0.5, 0.5, 0.3);
        w.playSound(at, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 0.5f);
        target.setNoDamageTicks(0);
        target.damage(damage, player);
        return true;
    }

    // ---- Fuga ----

    private boolean fuga(Player player) {
        World w = player.getWorld();
        Vector dir = player.getEyeLocation().getDirection().normalize();
        LargeFireball fire = player.launchProjectile(LargeFireball.class, dir.multiply(FUGA_SPEED));
        fire.setYield(FUGA_YIELD);
        fire.setIsIncendiary(true);
        w.playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.5f, 0.5f);
        w.playSound(player.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1.5f, 0.5f);
        return true;
    }

    // ---- Malevolent Shrine ----

    private boolean malevolentShrine(Player player) {
        World w = player.getWorld();
        Location center = player.getLocation();
        w.playSound(center, Sound.ENTITY_WITHER_SPAWN, 1.5f, 0.6f);
        player.sendMessage(Component.text("Domain Expansion: Malevolent Shrine.", NamedTextColor.DARK_RED));

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead() || ticks >= SHRINE_TICKS) {
                    cancel();
                    return;
                }
                ticks += SHRINE_INTERVAL;

                // A ring of slashes on the edge, and sparks all over the ground
                for (int i = 0; i < 24; i++) {
                    double angle = Math.PI * 2 * i / 24;
                    Location edge = center.clone().add(Math.cos(angle) * SHRINE_RADIUS, 0.5,
                            Math.sin(angle) * SHRINE_RADIUS);
                    w.spawnParticle(Particle.FLAME, edge, 2, 0.1, 0.4, 0.1, 0.01);
                }
                for (int i = 0; i < 12; i++) {
                    double angle = random.nextDouble() * Math.PI * 2;
                    double dist = random.nextDouble() * SHRINE_RADIUS;
                    Location spot = center.clone().add(Math.cos(angle) * dist, 0.5 + random.nextDouble() * 2,
                            Math.sin(angle) * dist);
                    w.spawnParticle(Particle.SWEEP_ATTACK, spot, 1, 0, 0, 0, 0);
                    w.spawnParticle(Particle.CRIT, spot, 4, 0.3, 0.3, 0.3, 0.1);
                }
                w.playSound(center, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.5f + random.nextFloat() * 0.5f);

                // Everything inside is cut, again and again
                for (LivingEntity target : w.getNearbyLivingEntities(center, SHRINE_RADIUS)) {
                    if (target.equals(player)) continue;
                    target.setNoDamageTicks(0);
                    target.damage(SHRINE_DAMAGE, player);
                }
            }
        }.runTaskTimer(plugin, 0L, SHRINE_INTERVAL);
        return true;
    }
}
