package com.example.cbspawner;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Zombie;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class CommandBlockSpawner extends JavaPlugin implements Listener {

    // The one command block this plugin cares about
    // (change it in game with /setcommandblock; these are only the starting values)
    private int blockX = 500;
    private int blockY = 150;
    private int blockZ = 500;
    /** Name of the world the command block is in. null means the main world. */
    private String blockWorldName = null;

    /** Upward speed given to the player when the mace is first created. */
    private static final double LAUNCH_VELOCITY = 1.5;
    /** How long (in ticks) we watch a dropped mace before giving up. */
    private static final int WATCH_TICKS = 200;

    // ---- Smash shockwave (hitting a player while falling) ----
    /** How far the shockwave reaches, in blocks. */
    private static final double SHOCK_RADIUS = 4.0;
    /** Sideways push on nearby players. */
    private static final double SHOCK_PUSH = 1.2;
    /** Upward pop on nearby players. */
    private static final double SHOCK_PUSH_UP = 0.4;
    /** Upward speed the mace holder gets from the shockwave (1.5 is roughly 12 blocks high). */
    private static final double SHOCK_SELF_LAUNCH = 1.5;

    // ---- Hook ----
    /** How far the hook flies, in blocks, in the direction you're looking. */
    private static final double HOOK_RANGE = 50.0;
    /** How fast the black line shoots out, in blocks per tick. */
    private static final double HOOK_LINE_SPEED = 5.0;
    /** Extra upward speed added to the hook pull (0.9 is roughly 5 blocks of lift). */
    private static final double HOOK_LIFT = 0.9;

    // ---- Purple shockwave ----
    /**
     * Sideways speed in the direction you're looking. In game this lands about 4 blocks away
     * (it comes out shorter than the math says because of ground friction). Raise it to go farther.
     */
    private static final double BLAST_FORWARD = 0.56;
    /** Upward speed (0.8 is about 4 blocks up). */
    private static final double BLAST_UP = 0.8;
    /** How many shockwaves you can use before the cooldown. */
    private static final int BLAST_MAX_USES = 5;
    /** Cooldown after the last shockwave (5 seconds). */
    private static final long BLAST_RECHARGE_MS = 5_000;
    /** Tiny gap between uses so one click can't fire twice. */
    private static final long BLAST_SHOT_GAP_MS = 300;

    /** How many hooks you can fire before the long cooldown. */
    private static final int HOOK_MAX_USES = 3;
    /** Cooldown after the last hook (5 seconds). */
    private static final long HOOK_RECHARGE_MS = 5_000;
    /** Tiny gap between shots so one click can't fire twice. */
    private static final long HOOK_SHOT_GAP_MS = 300;
    /** Base pull speed toward the hook, plus a bit more per block of distance. */
    private static final double HOOK_PULL_BASE = 0.5;
    private static final double HOOK_PULL_PER_BLOCK = 0.06;
    /** Cap on the pull speed so you don't get flung across the map. */
    private static final double HOOK_PULL_MAX = 3.0;
    /** Minimum fall (blocks) for a hit on a player to count (same as a vanilla smash). */
    private static final double MIN_SMASH_FALL = 1.5;
    /** Time between shockwaves for one player. */
    private static final long SHOCK_COOLDOWN_MS = 1000;

    // ---- Black dome ----
    /** Radius of the dome in blocks. */
    private static final int DOME_RADIUS = 7;
    /** How long the dome stays up (10 seconds). */
    private static final int DOME_DURATION_TICKS = 200;
    /** Cooldown before you can make another dome (20 seconds). */
    private static final long DOME_COOLDOWN_MS = 20_000;
    /** The block the dome is built from. */
    private static final Material DOME_MATERIAL = Material.BLACK_CONCRETE;

    /** The mace's moves. Shift + right-click cycles through them in this order. */
    private enum Move {
        HOOKS("Hooks", NamedTextColor.GRAY),
        PURPLE_SHOCKWAVE("Purple Shockwave", NamedTextColor.LIGHT_PURPLE),
        BLACK_DOME("Black Dome", NamedTextColor.DARK_GRAY);

        final String displayName;
        final NamedTextColor color;

        Move(String displayName, NamedTextColor color) {
            this.displayName = displayName;
            this.color = color;
        }
    }

    private NamespacedKey maceKey;
    private NamespacedKey moveKey;
    private NamespacedKey zombieKey;
    private NamespacedKey compassKey;
    private final Map<UUID, Long> lastShock = new HashMap<>();
    private final Map<UUID, Long> lastHook = new HashMap<>();
    private final Map<UUID, Integer> hookUses = new HashMap<>();
    private final Map<UUID, Long> hookCooldownEnd = new HashMap<>();
    private final Map<UUID, Long> lastBlast = new HashMap<>();
    private final Map<UUID, Integer> blastUses = new HashMap<>();
    private final Map<UUID, Long> blastCooldownEnd = new HashMap<>();
    private final Map<UUID, Long> domeCooldownEnd = new HashMap<>();
    /** Every dome block currently standing, with the block that was there before. */
    private final Map<Block, BlockData> domeOriginal = new HashMap<>();

    @Override
    public void onEnable() {
        maceKey = new NamespacedKey(this, "command_block_mace");
        moveKey = new NamespacedKey(this, "selected_move");
        zombieKey = new NamespacedKey(this, "compass_zombie");
        compassKey = new NamespacedKey(this, "dimension_compass");
        loadBlockLocation();
        getServer().getPluginManager().registerEvents(this, this);
    }

    /** Reads the command block location from config.yml (creating it on first run). */
    private void loadBlockLocation() {
        getConfig().addDefault("command-block.x", 500);
        getConfig().addDefault("command-block.y", 150);
        getConfig().addDefault("command-block.z", 500);
        getConfig().addDefault("command-block.world", "");
        getConfig().options().copyDefaults(true);
        saveConfig();

        blockX = getConfig().getInt("command-block.x");
        blockY = getConfig().getInt("command-block.y");
        blockZ = getConfig().getInt("command-block.z");
        String worldName = getConfig().getString("command-block.world", "");
        blockWorldName = (worldName == null || worldName.isEmpty()) ? null : worldName;
    }

    @Override
    public void onDisable() {
        restoreAllDomes(); // don't leave dome blocks behind when the server stops
    }

    /** The world the command block lives in (the main world). */
    private World world() {
        World saved = blockWorldName == null ? null : getServer().getWorld(blockWorldName);
        return saved != null ? saved : getServer().getWorlds().get(0);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("summonzombie")) {
            return summonZombie(sender);
        }
        if (command.getName().equalsIgnoreCase("setcommandblock")) {
            return setCommandBlockLocation(sender, args);
        }

        World world = world();

        if (blockY < world.getMinHeight() || blockY >= world.getMaxHeight()) {
            sender.sendMessage("§cY=" + blockY + " is outside this world's build limits.");
            return true;
        }

        new Location(world, blockX, blockY, blockZ).getBlock().setType(Material.COMMAND_BLOCK);
        sender.sendMessage("§aPlaced a command block at " + blockX + " " + blockY + " " + blockZ + " in " + world.getName() + ".");
        sender.sendMessage("§7Drop a mace on it to get the Command Block Mace.");
        return true;
    }

    // ---- Dropping a mace on the command block ----

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        Item item = event.getItemDrop();
        // Only a mace counts. Everything else is ignored.
        if (item.getItemStack().getType() != Material.MACE) return;

        UUID playerId = event.getPlayer().getUniqueId();

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                ticks += 2;
                if (!item.isValid() || ticks > WATCH_TICKS) {
                    cancel();
                    return;
                }
                if (isOnCommandBlock(item)) {
                    cancel();
                    Player player = getServer().getPlayer(playerId);
                    if (player != null && player.isOnline()) {
                        trigger(player, item);
                    }
                }
            }
        }.runTaskTimer(this, 2L, 2L);
    }

    /** True if the item is resting on top of the command block at blockX blockY blockZ. */
    private boolean isOnCommandBlock(Item item) {
        Location loc = item.getLocation();
        if (!loc.getWorld().equals(world())) return false;
        return loc.getBlockX() == blockX
                && loc.getBlockZ() == blockZ
                && loc.getY() >= blockY + 0.9
                && loc.getY() <= blockY + 1.6
                && loc.getWorld().getBlockAt(blockX, blockY, blockZ).getType() == Material.COMMAND_BLOCK;
    }

    private void trigger(Player player, Item droppedMace) {
        droppedMace.remove(); // the dropped mace is consumed

        // The command block breaks (it's one use; run /commandblockmacestart to place it again)
        Location blockLoc = new Location(world(), blockX, blockY, blockZ);
        blockLoc.getBlock().setType(Material.AIR);
        Location center = blockLoc.clone().add(0.5, 0.5, 0.5);
        world().spawnParticle(Particle.BLOCK, center, 40, 0.3, 0.3, 0.3, 0.1,
                Material.COMMAND_BLOCK.createBlockData());
        world().playSound(center, Sound.BLOCK_STONE_BREAK, 1.0f, 0.8f);

        player.setVelocity(new Vector(0, LAUNCH_VELOCITY, 0));

        var leftovers = player.getInventory().addItem(createCommandBlockMace());
        // Inventory full? Drop it at the player's feet.
        leftovers.values().forEach(i -> player.getWorld().dropItemNaturally(player.getLocation(), i));

        player.sendMessage(Component.text("You received the Command Block Mace!", NamedTextColor.GOLD));
    }

    private ItemStack createCommandBlockMace() {
        ItemStack mace = new ItemStack(Material.MACE);
        ItemMeta meta = mace.getItemMeta();
        meta.displayName(Component.text("Command Block Mace", NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Right-click: use the selected move", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Shift + right-click: switch move", NamedTextColor.LIGHT_PURPLE)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.addEnchant(Enchantment.DENSITY, 5, true);
        meta.addEnchant(Enchantment.WIND_BURST, 1, true);
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(maceKey, PersistentDataType.BYTE, (byte) 1);
        mace.setItemMeta(meta);
        return mace;
    }

    private boolean isCommandBlockMace(ItemStack stack) {
        if (stack == null || stack.getType() != Material.MACE || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(maceKey, PersistentDataType.BYTE);
    }

    // ---- Smash shockwave ----

    /** Hitting a player with the mace while falling (landing on the ground does nothing). */
    @EventHandler(ignoreCancelled = true)
    public void onMaceHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof Player victim)) return;
        if (!isCommandBlockMace(attacker.getInventory().getItemInMainHand())) return;
        if (attacker.getFallDistance() < MIN_SMASH_FALL) return;

        shockwave(attacker, victim.getLocation());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        lastShock.remove(event.getPlayer().getUniqueId());
        lastHook.remove(event.getPlayer().getUniqueId());
        hookUses.remove(event.getPlayer().getUniqueId());
        lastBlast.remove(event.getPlayer().getUniqueId());
        blastUses.remove(event.getPlayer().getUniqueId());
    }

    /** Pushes nearby players away from the center and throws the user into the air. */
    private void shockwave(Player user, Location center) {
        UUID id = user.getUniqueId();
        long now = System.currentTimeMillis();
        Long last = lastShock.get(id);
        if (last != null && now - last < SHOCK_COOLDOWN_MS) return;
        lastShock.put(id, now);

        World world = center.getWorld();

        for (Player other : world.getNearbyPlayers(center, SHOCK_RADIUS)) {
            if (other.equals(user)) continue;

            Vector push = other.getLocation().toVector().subtract(center.toVector()).setY(0);
            if (push.lengthSquared() < 0.0001) {
                push = user.getLocation().getDirection().setY(0); // standing exactly on the center
            }
            other.setVelocity(push.normalize().multiply(SHOCK_PUSH).setY(SHOCK_PUSH_UP));
        }

        user.setVelocity(new Vector(0, SHOCK_SELF_LAUNCH, 0));

        world.spawnParticle(Particle.CLOUD, center, 30, 1.5, 0.1, 1.5, 0.05);
        world.playSound(center, Sound.ITEM_MACE_SMASH_GROUND, 1.0f, 1.0f);
    }

    // ---- Hook: right-click to shoot a black line and get pulled to where it lands ----

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack mace = player.getInventory().getItemInMainHand();
        if (!isCommandBlockMace(mace)) return;

        if (player.isSneaking()) {
            switchMove(player, mace);
        } else {
            switch (getMove(mace)) {
                case HOOKS -> fireHook(player);
                case PURPLE_SHOCKWAVE -> purpleShockwave(player);
                case BLACK_DOME -> blackDome(player);
            }
        }
    }

    /** Which move is selected on this mace (saved on the item itself). */
    private Move getMove(ItemStack mace) {
        int index = mace.getItemMeta().getPersistentDataContainer()
                .getOrDefault(moveKey, PersistentDataType.INTEGER, 0);
        Move[] all = Move.values();
        return all[Math.floorMod(index, all.length)];
    }

    /** Shift + right-click: select the next move. */
    private void switchMove(Player player, ItemStack mace) {
        Move[] all = Move.values();
        Move next = all[(getMove(mace).ordinal() + 1) % all.length];

        ItemMeta meta = mace.getItemMeta();
        meta.getPersistentDataContainer().set(moveKey, PersistentDataType.INTEGER, next.ordinal());
        mace.setItemMeta(meta);
        player.getInventory().setItemInMainHand(mace);

        player.sendActionBar(Component.text("Move: " + next.displayName, next.color));
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.2f);
    }

    // ---- Move 2: purple shockwave that launches you up and where you're looking ----

    private void purpleShockwave(Player user) {
        UUID id = user.getUniqueId();
        long now = System.currentTimeMillis();

        // Still recharging after the 5th use?
        Long cooldownEnd = blastCooldownEnd.get(id);
        if (cooldownEnd != null && now < cooldownEnd) {
            long secondsLeft = (cooldownEnd - now + 999) / 1000;
            user.sendActionBar(Component.text("Shockwave recharging: " + secondsLeft + "s", NamedTextColor.RED));
            return;
        }

        Long last = lastBlast.get(id);
        if (last != null && now - last < BLAST_SHOT_GAP_MS) return;
        lastBlast.put(id, now);

        // Count this use. The 5th one starts the cooldown.
        int used = blastUses.merge(id, 1, Integer::sum);
        if (used >= BLAST_MAX_USES) {
            blastUses.remove(id);
            blastCooldownEnd.put(id, now + BLAST_RECHARGE_MS);
            user.sendActionBar(Component.text("Last shockwave! Recharging for "
                    + (BLAST_RECHARGE_MS / 1000) + "s", NamedTextColor.RED));
        } else {
            user.sendActionBar(Component.text("Shockwaves left: " + (BLAST_MAX_USES - used),
                    NamedTextColor.LIGHT_PURPLE));
        }

        World world = user.getWorld();
        Location center = user.getLocation().add(0, 0.2, 0);

        // Push: about 4 blocks up and about 4 blocks in the direction you're facing
        Vector flat = user.getEyeLocation().getDirection().setY(0);
        Vector launch = flat.lengthSquared() > 0.0001
                ? flat.normalize().multiply(BLAST_FORWARD)
                : new Vector(0, 0, 0); // looking straight up or down: no sideways push
        launch.setY(BLAST_UP);
        user.setVelocity(launch);

        world.playSound(center, Sound.ITEM_MACE_SMASH_GROUND, 1.0f, 0.6f);

        // Expanding rings of purple particles
        Particle.DustOptions purple = new Particle.DustOptions(Color.fromRGB(150, 40, 255), 1.6f);
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                double radius = 0.6 + tick * 0.5;
                int points = 28;
                for (int i = 0; i < points; i++) {
                    double angle = 2 * Math.PI * i / points;
                    double x = center.getX() + Math.cos(angle) * radius;
                    double z = center.getZ() + Math.sin(angle) * radius;
                    world.spawnParticle(Particle.DUST, x, center.getY(), z, 1, 0, 0, 0, 0, purple);
                    world.spawnParticle(Particle.DUST, x, center.getY() + 0.6, z, 1, 0, 0, 0, 0, purple);
                }
                if (++tick > 8) cancel();
            }
        }.runTaskTimer(this, 0L, 1L);
    }

    private void fireHook(Player user) {
        UUID id = user.getUniqueId();
        long now = System.currentTimeMillis();

        // Still recharging after the 3rd hook?
        Long cooldownEnd = hookCooldownEnd.get(id);
        if (cooldownEnd != null && now < cooldownEnd) {
            long secondsLeft = (cooldownEnd - now + 999) / 1000;
            user.sendActionBar(Component.text("Hooks recharging: " + secondsLeft + "s", NamedTextColor.RED));
            return;
        }

        Long last = lastHook.get(id);
        if (last != null && now - last < HOOK_SHOT_GAP_MS) return;
        lastHook.put(id, now);

        // Count this shot. The 3rd one starts the 20 second cooldown.
        int used = hookUses.merge(id, 1, Integer::sum);
        if (used >= HOOK_MAX_USES) {
            hookUses.remove(id);
            hookCooldownEnd.put(id, now + HOOK_RECHARGE_MS);
            user.sendActionBar(Component.text("Last hook! Recharging for "
                    + (HOOK_RECHARGE_MS / 1000) + "s", NamedTextColor.RED));
        } else {
            user.sendActionBar(Component.text("Hooks left: " + (HOOK_MAX_USES - used), NamedTextColor.GRAY));
        }

        World world = user.getWorld();
        Location eye = user.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        Vector start = eye.toVector();

        RayTraceResult hit = world.rayTrace(
                eye, dir, HOOK_RANGE, FluidCollisionMode.NEVER, true, 0.2,
                entity -> entity instanceof LivingEntity && !entity.equals(user));

        boolean landed = hit != null && hit.getHitPosition() != null;
        Vector end = landed ? hit.getHitPosition() : start.clone().add(dir.clone().multiply(HOOK_RANGE));
        double totalLength = start.distance(end);

        world.playSound(eye, Sound.ENTITY_FISHING_BOBBER_THROW, 1.0f, 0.8f);

        new BukkitRunnable() {
            double reach = 0;
            boolean pulled = false;
            int pullTicks = 0;

            @Override
            public void run() {
                if (!user.isOnline() || !user.getWorld().equals(world)) {
                    cancel();
                    return;
                }

                // The line starts at the user (so it follows them while they fly) and ends at the tip.
                Vector origin = user.getLocation().toVector().add(new Vector(0, 1.0, 0));
                reach = Math.min(totalLength, reach + HOOK_LINE_SPEED);
                Vector tip = start.clone().add(dir.clone().multiply(reach));
                drawLine(world, origin, tip);

                if (reach < totalLength) return; // still shooting out

                if (!landed) { // hit nothing: the line just disappears
                    cancel();
                    return;
                }

                if (!pulled) {
                    pulled = true;
                    user.setVelocity(hookPull(user, end));
                    world.playSound(end.toLocation(world), Sound.BLOCK_CHAIN_PLACE, 1.0f, 0.8f);
                }

                pullTicks++;
                if (pullTicks > 8) cancel(); // keep drawing the line for a few ticks while you fly
            }
        }.runTaskTimer(this, 0L, 1L);
    }

    /** Velocity that pulls the user toward the point where the hook landed. */
    private Vector hookPull(Player user, Vector landing) {
        Vector toHook = landing.clone().subtract(user.getLocation().toVector());
        double distance = toHook.length();
        if (distance < 1.0) {
            return new Vector(0, HOOK_LIFT, 0);
        }

        double speed = Math.min(HOOK_PULL_MAX, HOOK_PULL_BASE + distance * HOOK_PULL_PER_BLOCK);
        Vector pull = toHook.normalize().multiply(speed);
        pull.setY(pull.getY() + HOOK_LIFT); // still gets lifted off the ground
        return pull;
    }

    /** Draws a black line of particles between two points. */
    private void drawLine(World world, Vector from, Vector to) {
        // (1,1,1) instead of pure black, because pure 0,0,0 dust can render as red
        Particle.DustOptions black = new Particle.DustOptions(Color.fromRGB(1, 1, 1), 1.3f);

        Vector step = to.clone().subtract(from);
        double length = step.length();
        if (length < 0.01) return;
        step.normalize().multiply(0.4);

        Vector point = from.clone();
        for (double d = 0; d < length; d += 0.4) {
            world.spawnParticle(Particle.DUST, point.getX(), point.getY(), point.getZ(), 1, 0, 0, 0, 0, black);
            point.add(step);
        }
    }

    // ---- Move 3: black dome (can't be mined, blinds opponents inside) ----

    private void blackDome(Player user) {
        UUID id = user.getUniqueId();
        long now = System.currentTimeMillis();
        Long cooldownEnd = domeCooldownEnd.get(id);
        if (cooldownEnd != null && now < cooldownEnd) {
            long secondsLeft = (cooldownEnd - now + 999) / 1000;
            user.sendActionBar(Component.text("Black Dome recharging: " + secondsLeft + "s", NamedTextColor.RED));
            return;
        }
        domeCooldownEnd.put(id, now + DOME_COOLDOWN_MS);

        World world = user.getWorld();
        Location base = user.getLocation();
        int cx = base.getBlockX();
        int cy = base.getBlockY();
        int cz = base.getBlockZ();
        Location center = new Location(world, cx + 0.5, cy, cz + 0.5);

        // Don't put a wall block inside anyone's body (that would suffocate them)
        Set<Block> occupied = new HashSet<>();
        for (Player p : world.getNearbyPlayers(center, DOME_RADIUS + 3)) {
            Block feet = p.getLocation().getBlock();
            occupied.add(feet);
            occupied.add(feet.getRelative(0, 1, 0));
        }

        // A hollow half-sphere, one and a half blocks thick, built only on empty space
        List<Block> placed = new ArrayList<>();
        for (int dx = -DOME_RADIUS; dx <= DOME_RADIUS; dx++) {
            for (int dy = 0; dy <= DOME_RADIUS; dy++) {
                for (int dz = -DOME_RADIUS; dz <= DOME_RADIUS; dz++) {
                    double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (dist > DOME_RADIUS + 0.5 || dist <= DOME_RADIUS - 1.0) continue;

                    int y = cy + dy;
                    if (y < world.getMinHeight() || y >= world.getMaxHeight()) continue;

                    Block block = world.getBlockAt(cx + dx, y, cz + dz);
                    if (occupied.contains(block) || domeOriginal.containsKey(block)) continue;
                    if (!(block.getType().isAir() || block.isLiquid() || block.isReplaceable())) continue;

                    domeOriginal.put(block, block.getBlockData());
                    block.setType(DOME_MATERIAL, false);
                    placed.add(block);
                }
            }
        }

        world.playSound(center, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 0.5f);
        world.spawnParticle(Particle.DUST, center.clone().add(0, 1, 0), 80, 3, 1.5, 3, 0,
                new Particle.DustOptions(Color.fromRGB(1, 1, 1), 2.0f));

        new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                // Everyone else inside the dome is blinded (refreshed every half second)
                for (Player p : world.getNearbyPlayers(center, DOME_RADIUS)) {
                    if (p.equals(user)) continue;
                    p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0, false, false));
                }

                elapsed += 10;
                if (elapsed >= DOME_DURATION_TICKS) {
                    for (Block block : placed) {
                        BlockData original = domeOriginal.remove(block);
                        if (original != null) block.setBlockData(original, false);
                    }
                    world.playSound(center, Sound.BLOCK_BEACON_DEACTIVATE, 1.0f, 0.5f);
                    cancel();
                }
            }
        }.runTaskTimer(this, 0L, 10L);
    }

    /** Puts every dome block back the way it was. */
    private void restoreAllDomes() {
        for (Map.Entry<Block, BlockData> entry : domeOriginal.entrySet()) {
            entry.getKey().setBlockData(entry.getValue(), false);
        }
        domeOriginal.clear();
    }

    // Dome blocks can't be mined, blown up or pushed

    @EventHandler(ignoreCancelled = true)
    public void onDomeBreak(BlockBreakEvent event) {
        if (domeOriginal.containsKey(event.getBlock())) event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDomeDamage(BlockDamageEvent event) {
        if (domeOriginal.containsKey(event.getBlock())) event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDomeEntityExplode(EntityExplodeEvent event) {
        event.blockList().removeIf(domeOriginal::containsKey);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDomeBlockExplode(BlockExplodeEvent event) {
        event.blockList().removeIf(domeOriginal::containsKey);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDomePistonExtend(BlockPistonExtendEvent event) {
        if (event.getBlocks().stream().anyMatch(domeOriginal::containsKey)) event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDomePistonRetract(BlockPistonRetractEvent event) {
        if (event.getBlocks().stream().anyMatch(domeOriginal::containsKey)) event.setCancelled(true);
    }

    // ---- Compass Zombie: 100 health, drops a Dimension Compass when it dies ----

    private boolean summonZombie(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only a player can use this command.");
            return true;
        }

        // Spawn it 3 blocks in front of you
        Location spot = player.getLocation();
        Vector ahead = spot.getDirection().setY(0);
        if (ahead.lengthSquared() > 0.0001) {
            spot.add(ahead.normalize().multiply(3));
        }

        player.getWorld().spawn(spot, Zombie.class, zombie -> {
            zombie.getAttribute(Attribute.MAX_HEALTH).setBaseValue(100.0);
            zombie.setHealth(100.0);
            zombie.customName(Component.text("Compass Zombie", NamedTextColor.DARK_RED));
            zombie.setCustomNameVisible(true);
            zombie.setShouldBurnInDay(false); // so the sun doesn't kill it
            zombie.setPersistent(true);
            zombie.setRemoveWhenFarAway(false);
            zombie.getPersistentDataContainer().set(zombieKey, PersistentDataType.BYTE, (byte) 1);
        });

        player.sendMessage("§aSummoned the Compass Zombie (100 health).");
        return true;
    }

    /** When the Compass Zombie dies, it drops the Dimension Compass. */
    @EventHandler
    public void onZombieDeath(EntityDeathEvent event) {
        if (!event.getEntity().getPersistentDataContainer().has(zombieKey, PersistentDataType.BYTE)) return;
        event.getDrops().add(createDimensionCompass());
    }

    private ItemStack createDimensionCompass() {
        ItemStack compass = new ItemStack(Material.COMPASS);
        ItemMeta meta = compass.getItemMeta();
        meta.displayName(Component.text("Dimension Compass", NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Leads to a new dimension", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(compassKey, PersistentDataType.BYTE, (byte) 1);
        compass.setItemMeta(meta);
        return compass;
    }

    /** Placeholder: the dimension isn't built yet, so using the compass just says so. */
    @EventHandler
    public void onCompassUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack held = event.getPlayer().getInventory().getItemInMainHand();
        if (held.getType() != Material.COMPASS || !held.hasItemMeta()) return;
        if (!held.getItemMeta().getPersistentDataContainer().has(compassKey, PersistentDataType.BYTE)) return;

        event.getPlayer().sendMessage(Component.text("The compass hums... the dimension isn't ready yet.",
                NamedTextColor.AQUA));
    }

    // ---- /setcommandblock: choose where the command block goes ----

    private boolean setCommandBlockLocation(CommandSender sender, String[] args) {
        int x = 0, y = 0, z = 0;
        World target;

        if (args.length == 0) {
            // No numbers given: use the block you're standing in
            if (!(sender instanceof Player player)) {
                sender.sendMessage("§cFrom the console use: /setcommandblock <x> <y> <z>");
                return true;
            }
            Location here = player.getLocation();
            x = here.getBlockX();
            y = here.getBlockY();
            z = here.getBlockZ();
            target = player.getWorld();
        } else if (args.length == 3) {
            try {
                x = Integer.parseInt(args[0]);
                y = Integer.parseInt(args[1]);
                z = Integer.parseInt(args[2]);
            } catch (NumberFormatException e) {
                sender.sendMessage("§cUse whole numbers: /setcommandblock <x> <y> <z>");
                return true;
            }
            target = (sender instanceof Player other) ? other.getWorld() : getServer().getWorlds().get(0);
        } else {
            sender.sendMessage("§cUse: /setcommandblock  (your position)  or  /setcommandblock <x> <y> <z>");
            return true;
        }

        if (y < target.getMinHeight() || y >= target.getMaxHeight()) {
            sender.sendMessage("§cY=" + y + " is outside this world's build limits ("
                    + target.getMinHeight() + " to " + (target.getMaxHeight() - 1) + ").");
            return true;
        }

        blockX = x;
        blockY = y;
        blockZ = z;
        blockWorldName = target.getName();

        getConfig().set("command-block.x", x);
        getConfig().set("command-block.y", y);
        getConfig().set("command-block.z", z);
        getConfig().set("command-block.world", target.getName());
        saveConfig();

        sender.sendMessage("§aCommand block location set to " + x + " " + y + " " + z + " in " + target.getName() + ".");
        sender.sendMessage("§7Run /commandblockmacestart to place it there.");
        return true;
    }
}
