package com.example.cbspawner;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LightningStrike;
import org.bukkit.entity.Trident;
import org.bukkit.entity.Zombie;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.block.BlockPlaceEvent;

public class CommandBlockSpawner extends JavaPlugin implements Listener {

    // The one command block this plugin cares about
    // (change it in game with /setcommandblock; these are only the starting values)
    private int blockX = 500;
    private int blockY = 150;
    private int blockZ = 500;
    /** Name of the world the command block is in. null means the main world. */
    private String blockWorldName = null;

    /** Upward speed given to the player when the mace is first created. */
    private static final double LAUNCH_VELOCITY = 1.5;
    /** How long (in ticks) we watch a dropped mace before giving up. */
    private static final int WATCH_TICKS = 200;

    // ---- Smash shockwave (hitting a player while falling) ----
    /** How far the shockwave reaches, in blocks. */
    private static final double SHOCK_RADIUS = 4.0;
    /** Sideways push on nearby players. */
    private static final double SHOCK_PUSH = 1.2;
    /** Upward pop on nearby players. */
    private static final double SHOCK_PUSH_UP = 0.4;
    /** Upward speed the mace holder gets from the shockwave (1.5 is roughly 12 blocks high). */
    private static final double SHOCK_SELF_LAUNCH = 1.5;

    // ---- Hook ----
    /** How far the hook flies, in blocks, in the direction you're looking. */
    private static final double HOOK_RANGE = 50.0;
    /** A player within this many blocks (20) gets targeted by the hook automatically (no aiming needed). */
    private static final double HOOK_AUTO_TARGET_RADIUS = 20.0;
    /** How fast the black line shoots out, in blocks per tick. */
    private static final double HOOK_LINE_SPEED = 5.0;
    /** Extra upward speed added to the hook pull (0.9 is roughly 5 blocks of lift). */
    private static final double HOOK_LIFT = 0.9;

    // ---- Purple shockwave ----
    /**
     * Sideways speed in the direction you're looking. In game this lands about 4 blocks away
     * (it comes out shorter than the math says because of ground friction). Raise it to go farther.
     */
    private static final double BLAST_FORWARD = 0.56;
    /** Upward speed (0.8 is about 4 blocks up). */
    private static final double BLAST_UP = 0.8;
    /** How many shockwaves you can use before the cooldown. */
    private static final int BLAST_MAX_USES = 5;
    /** Cooldown after the last shockwave (5 seconds). */
    private static final long BLAST_RECHARGE_MS = 5_000;
    /** Tiny gap between uses so one click can't fire twice. */
    private static final long BLAST_SHOT_GAP_MS = 300;

    /** How many hooks you can fire before the long cooldown. */
    private static final int HOOK_MAX_USES = 3;
    /** Cooldown after the last hook (5 seconds). */
    private static final long HOOK_RECHARGE_MS = 5_000;
    /** Tiny gap between shots so one click can't fire twice. */
    private static final long HOOK_SHOT_GAP_MS = 300;
    /** Base pull speed toward the hook, plus a bit more per block of distance. */
    private static final double HOOK_PULL_BASE = 0.5;
    private static final double HOOK_PULL_PER_BLOCK = 0.06;
    /** Cap on the pull speed so you don't get flung across the map. */
    private static final double HOOK_PULL_MAX = 3.0;
    /** Every hit with the Command Block Mace does this many times its normal damage (1.0 = vanilla). */
    private static final double MACE_DAMAGE_MULTIPLIER = 4.0;

    /** Minimum fall (blocks) for a hit on a player to count (same as a vanilla smash). */
    private static final double MIN_SMASH_FALL = 1.5;
    /** Time between shockwaves for one player. */
    private static final long SHOCK_COOLDOWN_MS = 1000;

    // ---- Stick of Sealing ----
    /** How far you can aim the stick at a player. */
    private static final double SEAL_RANGE = 30.0;
    /** Corner of the sealing cell in the Null Realm: a 3x3x3 room walled in with bedrock. */
    private static final int SEAL_CELL_X = 3000;
    private static final int SEAL_CELL_Y = 100;
    private static final int SEAL_CELL_Z = 3000;

    // ---- Null Realm ----
    /** Name of the world folder for the Null Realm. */
    private static final String NULL_REALM_NAME = "null_realm";
    /** Top layer of the obsidian floor. You stand on top of it (one block higher). */
    private static final int NULL_REALM_FLOOR_Y = 99;
    /** The command block inside the Null Realm: drop an item on it to get a Null Compass. */
    private static final int REALM_BLOCK_X = 1000;
    private static final int REALM_BLOCK_Y = 100;
    private static final int REALM_BLOCK_Z = 1000;
    /** The compass says something different for clicks 1-3, and takes you on click 4. */
    private static final String[] COMPASS_LINES = {
            "The needle spins wildly, refusing to settle on any direction...",
            "A whisper echoes from nowhere: \"There is nothing left to find.\"",
            "The air turns cold. The needle points at nothing. Click once more..."
    };

    // ---- Black Domain: pulls people into a separate black dome world for a while ----
    private static final String DOMAIN_WORLD_NAME = "black_domain";
    /** Free space inside the domain, in blocks from the center. */
    private static final int DOMAIN_RADIUS = 24;
    /** Height of the domain's floor. */
    private static final int DOMAIN_FLOOR_Y = 64;
    /** Players this close to you when you use the move are pulled into the domain too. */
    private static final double DOMAIN_GATHER_RADIUS = 30.0;
    /** How far from the center the people you pulled in appear. */
    private static final double DOMAIN_SPAWN_DISTANCE = 10.0;
    /** How long the domain lasts: 60 seconds. */
    private static final int DOMAIN_DURATION_TICKS = 1200;
    /** Cooldown before you can use it again: 10 seconds, counted from when the domain ENDS. */
    private static final long DOMAIN_COOLDOWN_MS = 10_000;
    /** Everyone pulled in except you is blinded while inside. Set to false to turn that off. */
    private static final boolean DOMAIN_BLINDS_OPPONENTS = true;

    /** The mace's moves. Shift + right-click cycles through them in this order. */
    private enum Move {
        HOOKS("Hooks", NamedTextColor.GRAY),
        PURPLE_SHOCKWAVE("Purple Shockwave", NamedTextColor.LIGHT_PURPLE),
        BLACK_DOMAIN("Black Domain", NamedTextColor.DARK_GRAY);

        final String displayName;
        final NamedTextColor color;

        Move(String displayName, NamedTextColor color) {
            this.displayName = displayName;
            this.color = color;
        }
    }

    // ---- Command Block Trident ----
    /** How fast the Riptide dash is, in blocks per tick (about 2.2 is a strong riptide III dash). */
    private static final double RIPTIDE_SPEED = 2.6;
    /** Damage dealt to the first thing you slam into during a dash (40 = 20 hearts, before armor). */
    private static final double RIPTIDE_DAMAGE = 40.0;
    /** Cooldown between dashes (1 second). */
    private static final long RIPTIDE_COOLDOWN_MS = 750;
    /** How long a dash can hit things, in ticks. */
    private static final int RIPTIDE_DASH_TICKS = 12;
    /** How many tridents one throw sends out (the real one plus copies). */
    private static final int THROW_COUNT = 3;
    /** How many tridents one throw sends out while Super Charge is on. */
    private static final int THROW_COUNT_CHARGED = 10;
    /** Sideways spread of the extra tridents (bigger = wider fan). */
    private static final double THROW_SPREAD = 0.12;
    /** For this many ticks the dash keeps pushing you (so air drag and friction can't kill it). */
    private static final int RIPTIDE_THRUST_TICKS = 6;
    /** How close something has to be to get hit by the dash, in blocks. */
    private static final double RIPTIDE_HIT_RANGE = 2.2;
    /** How hard things you hit are knocked forward. */
    private static final double RIPTIDE_KNOCKBACK = 1.1;
    /** Dash speed is multiplied by this when you are in water. */
    private static final double RIPTIDE_WATER_MULTIPLIER = 1.8;
    /** Dash speed is multiplied by this when you are standing in the rain (water wins if both apply). */
    private static final double RIPTIDE_RAIN_MULTIPLIER = 1.8;
    /** While gliding with an Elytra the dash is ADDED to your speed. Top speed (blocks per tick) it can reach. */
    private static final double RIPTIDE_ELYTRA_MAX_SPEED = 5.0;
    /** While gliding, each thrust tick adds this fraction of the dash speed on top of your current speed. */
    private static final double RIPTIDE_ELYTRA_THRUST = 0.25;

    // ---- Super Charge ----
    /** Damage multiplier for every trident move while Super Charge is on. */
    private static final double SUPER_CHARGE_MULTIPLIER = 3.0;
    /** How long Super Charge (and the lightning storm) lasts: 15 seconds. */
    private static final int SUPER_CHARGE_TICKS = 300;
    /** Cooldown before you can use Super Charge again: 45 seconds. */
    private static final long SUPER_CHARGE_COOLDOWN_MS = 45_000;
    /** The storm drops a lightning bolt this often (in ticks). */
    private static final int STORM_STRIKE_INTERVAL = 20;
    /** Storm bolts land between these distances from the user. */
    private static final double STORM_MIN_DISTANCE = 6.0;
    private static final double STORM_MAX_DISTANCE = 20.0;

    /** The trident's two modes. Shift + right-click switches between them. */
    private enum TridentMode {
        RIPTIDE("Riptide", NamedTextColor.AQUA),
        THROW("Throw", NamedTextColor.BLUE),
        SUPER_CHARGE("Super Charge", NamedTextColor.GOLD);

        final String displayName;
        final NamedTextColor color;

        TridentMode(String displayName, NamedTextColor color) {
            this.displayName = displayName;
            this.color = color;
        }
    }

    private NamespacedKey tridentKey;
    private NamespacedKey tridentModeKey;
    private final Map<UUID, Long> lastRiptide = new HashMap<>();
    /** The extra tridents from a multi-throw (they vanish after they hit something). */
    private final Set<UUID> extraTridents = new HashSet<>();
    /** Players with Super Charge on, and when it ends. */
    private final Map<UUID, Long> chargedUntil = new HashMap<>();
    private final Map<UUID, Long> superChargeCooldownEnd = new HashMap<>();
    /** Lightning bolts made by the trident, and the player each one belongs to. */
    private final Map<UUID, UUID> lightningOwner = new HashMap<>();

    private NamespacedKey maceKey;
    private NamespacedKey moveKey;
    private NamespacedKey zombieKey;
    private NamespacedKey compassKey;
    private NamespacedKey nullCompassKey;
    private NamespacedKey targetKey;
    private NamespacedKey stickKey;
    private NamespacedKey stickTargetKey;
    private NamespacedKey sealedKey;
    private BookOfKnowledge book;
    private SukunaSword sukunaSword;
    /** Players the plugin itself is teleporting in or out of a seal right now. */
    private final Set<UUID> sealTeleportAllowed = new HashSet<>();
    private final Map<UUID, Long> lastStickUse = new HashMap<>();
    private final Map<UUID, Long> lastShock = new HashMap<>();
    private final Map<UUID, Long> lastHook = new HashMap<>();
    private final Map<UUID, Integer> hookUses = new HashMap<>();
    private final Map<UUID, Long> hookCooldownEnd = new HashMap<>();
    private final Map<UUID, Long> lastBlast = new HashMap<>();
    private final Map<UUID, Integer> blastUses = new HashMap<>();
    private final Map<UUID, Long> blastCooldownEnd = new HashMap<>();
    private final Map<UUID, Long> domainCooldownEnd = new HashMap<>();
    private final Map<UUID, Integer> compassClicks = new HashMap<>();
    /** Everyone inside the domain right now, and where they were before. */
    private final Map<UUID, Location> domainOrigins = new HashMap<>();
    /** People who logged off inside the domain: where to put them when they come back. */
    private final Map<UUID, Location> pendingReturn = new HashMap<>();
    /** People who died inside the domain: they respawn where they were before it pulled them in. */
    private final Map<UUID, Location> deathReturn = new HashMap<>();
    private UUID domainOwner = null;
    private BukkitTask domainTask = null;

    @Override
    public void onEnable() {
        maceKey = new NamespacedKey(this, "command_block_mace");
        tridentKey = new NamespacedKey(this, "command_block_trident");
        tridentModeKey = new NamespacedKey(this, "trident_mode");
        moveKey = new NamespacedKey(this, "selected_move");
        zombieKey = new NamespacedKey(this, "compass_zombie");
        compassKey = new NamespacedKey(this, "dimension_compass");
        nullCompassKey = new NamespacedKey(this, "null_compass");
        targetKey = new NamespacedKey(this, "compass_target");
        stickKey = new NamespacedKey(this, "stick_of_sealing");
        stickTargetKey = new NamespacedKey(this, "sealed_target");
        sealedKey = new NamespacedKey(this, "is_sealed");
        loadBlockLocation();
        loadReturns();
        if (new File(getServer().getWorldContainer(), NULL_REALM_NAME).isDirectory()) {
            getNullRealm();
        }
        getServer().getPluginManager().registerEvents(this, this);
        book = new BookOfKnowledge(this);
        getServer().getPluginManager().registerEvents(book, this);
        getServer().getPluginManager().registerEvents(new EnderPearlCannon(this), this);
        getServer().getPluginManager().registerEvents(new ArrowCannon(this), this);
        sukunaSword = new SukunaSword(this);
        getServer().getPluginManager().registerEvents(sukunaSword, this);
        book.start();
        startSealRegen();

        // The domain keeps itself working: unsticks itself and sends stranded players out
        getServer().getScheduler().runTaskTimer(this, this::domainWatchdog, 100L, 100L);

        // Maces made before the texture pack existed get the custom model added automatically
        getServer().getScheduler().runTaskTimer(this, () -> {
            NamespacedKey model = new NamespacedKey("cbspawner", "command_block_mace");
            for (Player online : getServer().getOnlinePlayers()) {
                ItemStack[] contents = online.getInventory().getContents();
                for (int slot = 0; slot < contents.length; slot++) {
                    ItemStack stack = contents[slot];
                    if (!isCommandBlockMace(stack)) continue;
                    ItemMeta meta = stack.getItemMeta();
                    if (model.equals(meta.getItemModel())) continue;
                    meta.setItemModel(model);
                    stack.setItemMeta(meta);
                    online.getInventory().setItem(slot, stack);
                }
            }
        }, 20L, 20L);
    }

    /** Reads the command block location from config.yml (creating it on first run). */
    private void loadBlockLocation() {
        getConfig().addDefault("command-block.x", 500);
        getConfig().addDefault("command-block.y", 150);
        getConfig().addDefault("command-block.z", 500);
        getConfig().addDefault("command-block.world", "");
        getConfig().options().copyDefaults(true);
        saveConfig();

        blockX = getConfig().getInt("command-block.x");
        blockY = getConfig().getInt("command-block.y");
        blockZ = getConfig().getInt("command-block.z");
        String worldName = getConfig().getString("command-block.world", "");
        blockWorldName = (worldName == null || worldName.isEmpty()) ? null : worldName;
    }

    @Override
    public void onDisable() {
        endDomain(); // send everyone back before the server stops
        saveReturns();
    }

    /** The world the command block lives in (the main world). */
    private World world() {
        World saved = blockWorldName == null ? null : getServer().getWorld(blockWorldName);
        return saved != null ? saved : getServer().getWorlds().get(0);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("summonzombie")) {
            return summonZombie(sender);
        }
        if (command.getName().equalsIgnoreCase("unseal")) {
            return unsealCommand(sender, args);
        }
        if (command.getName().equalsIgnoreCase("giveweapons")) {
            return giveWeapons(sender);
        }
        if (command.getName().equalsIgnoreCase("leavenullrealm")) {
            return leaveNullRealm(sender);
        }
        if (command.getName().equalsIgnoreCase("givetrident")) {
            return giveTrident(sender);
        }
        if (command.getName().equalsIgnoreCase("givesword")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Only a player can use /givesword.");
                return true;
            }
            player.getInventory().addItem(sukunaSword.createSword())
                    .values().forEach(i -> player.getWorld().dropItemNaturally(player.getLocation(), i));
            player.sendMessage(Component.text("You received the Command Block Sword!", NamedTextColor.DARK_RED));
            return true;
        }
        if (command.getName().equalsIgnoreCase("givebook")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Only a player can use /givebook.");
                return true;
            }
            giveBook(player);
            return true;
        }
        if (command.getName().equalsIgnoreCase("link")) {
            return linkCommand(sender, args);
        }
        if (command.getName().equalsIgnoreCase("bookaction")) {
            if (sender instanceof Player player) book.handleAction(player, args);
            return true;
        }
        if (command.getName().equalsIgnoreCase("setorigin")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Only a player can use /setorigin.");
                return true;
            }
            book.setOrigin(player);
            return true;
        }
        if (command.getName().equalsIgnoreCase("setcommandblock")) {
            return setCommandBlockLocation(sender, args);
        }

        World world = world();

        if (blockY < world.getMinHeight() || blockY >= world.getMaxHeight()) {
            sender.sendMessage("§cY=" + blockY + " is outside this world's build limits.");
            return true;
        }

        new Location(world, blockX, blockY, blockZ).getBlock().setType(Material.COMMAND_BLOCK);
        sender.sendMessage("§aPlaced a command block at " + blockX + " " + blockY + " " + blockZ + " in " + world.getName() + ".");
        sender.sendMessage("§7Drop a mace on it for the Command Block Mace, a trident for the Command Block Trident, a stick for the Stick of Sealing, or a book for the Book o' Knowledge, or a netherite sword for the Command Block Sword.");
        return true;
    }

    // ---- Dropping a mace on the command block ----

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        Item item = event.getItemDrop();
        // Only a normal mace, trident or stick counts. Everything else is ignored.
        ItemStack dropped = item.getItemStack();
        Material type = dropped.getType();
        if (type != Material.MACE && type != Material.TRIDENT && type != Material.STICK && type != Material.BOOK
                && type != Material.NETHERITE_SWORD) return;
        if (isCommandBlockMace(dropped) || isCommandBlockTrident(dropped) || isStickOfSealing(dropped)
                || book.isBook(dropped) || sukunaSword.isSword(dropped)) return; // already one of ours

        UUID playerId = event.getPlayer().getUniqueId();

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                ticks += 2;
                if (!item.isValid() || ticks > WATCH_TICKS) {
                    cancel();
                    return;
                }
                if (isOnCommandBlock(item)) {
                    cancel();
                    Player player = getServer().getPlayer(playerId);
                    if (player != null && player.isOnline()) {
                        trigger(player, item);
                    }
                }
            }
        }.runTaskTimer(this, 2L, 2L);
    }

    /** True if the item is resting on top of the command block at blockX blockY blockZ. */
    private boolean isOnCommandBlock(Item item) {
        Location loc = item.getLocation();
        if (!loc.getWorld().equals(world())) return false;
        return loc.getBlockX() == blockX
                && loc.getBlockZ() == blockZ
                && loc.getY() >= blockY + 0.9
                && loc.getY() <= blockY + 1.6
                && loc.getWorld().getBlockAt(blockX, blockY, blockZ).getType() == Material.COMMAND_BLOCK;
    }

    private void trigger(Player player, Item droppedItem) {
        ItemStack droppedStack = droppedItem.getItemStack();
        Material droppedType = droppedStack.getType();
        // Only one item is used up (a dropped stack of sticks keeps the rest)
        if (droppedStack.getAmount() > 1) {
            droppedStack.setAmount(droppedStack.getAmount() - 1);
            droppedItem.setItemStack(droppedStack);
        } else {
            droppedItem.remove();
        }

        // The command block breaks (it's one use; run /commandblockmacestart to place it again)
        Location blockLoc = new Location(world(), blockX, blockY, blockZ);
        blockLoc.getBlock().setType(Material.AIR);
        Location center = blockLoc.clone().add(0.5, 0.5, 0.5);
        world().spawnParticle(Particle.BLOCK, center, 40, 0.3, 0.3, 0.3, 0.1,
                Material.COMMAND_BLOCK.createBlockData());
        world().playSound(center, Sound.BLOCK_STONE_BREAK, 1.0f, 0.8f);

        player.setVelocity(new Vector(0, LAUNCH_VELOCITY, 0));

        ItemStack reward = droppedType == Material.TRIDENT ? createCommandBlockTrident()
                : droppedType == Material.STICK ? createStickOfSealing()
                : droppedType == Material.BOOK ? book.createBook()
                : droppedType == Material.NETHERITE_SWORD ? sukunaSword.createSword()
                : createCommandBlockMace();
        var leftovers = player.getInventory().addItem(reward);
        // Inventory full? Drop it at the player's feet.
        leftovers.values().forEach(i -> player.getWorld().dropItemNaturally(player.getLocation(), i));

        player.sendMessage(droppedType == Material.TRIDENT
                ? Component.text("You received the Command Block Trident!", NamedTextColor.AQUA)
                : droppedType == Material.STICK
                ? Component.text("You received the Stick of Sealing!", NamedTextColor.DARK_PURPLE)
                : droppedType == Material.BOOK
                ? Component.text("You received the Book o' Knowledge!", NamedTextColor.LIGHT_PURPLE)
                : droppedType == Material.NETHERITE_SWORD
                ? Component.text("You received the Command Block Sword!", NamedTextColor.DARK_RED)
                : Component.text("You received the Command Block Mace!", NamedTextColor.GOLD));
    }

    private ItemStack createCommandBlockMace() {
        ItemStack mace = new ItemStack(Material.MACE);
        ItemMeta meta = mace.getItemMeta();
        meta.displayName(Component.text("Command Block Mace", NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Right-click: use the selected move", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Shift + right-click: switch move", NamedTextColor.LIGHT_PURPLE)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.setItemModel(new NamespacedKey("cbspawner", "command_block_mace")); // the texture pack uses this
        meta.addEnchant(Enchantment.DENSITY, 5, true);
        meta.addEnchant(Enchantment.WIND_BURST, 1, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(maceKey, PersistentDataType.BYTE, (byte) 1);
        mace.setItemMeta(meta);
        return mace;
    }

    private boolean isCommandBlockMace(ItemStack stack) {
        if (stack == null || stack.getType() != Material.MACE || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(maceKey, PersistentDataType.BYTE);
    }

    // ---- Smash shockwave ----

    /** Hitting a player with the mace while falling (landing on the ground does nothing). */
    @EventHandler(ignoreCancelled = true)
    public void onMaceHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof Player victim)) return;
        if (!isCommandBlockMace(attacker.getInventory().getItemInMainHand())) return;
        if (attacker.getFallDistance() < MIN_SMASH_FALL) return;

        shockwave(attacker, victim.getLocation());
    }

    /** The Command Block Mace hits harder than a normal mace (smash damage included). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMaceDamage(EntityDamageByEntityEvent event) {
        if (event.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!isCommandBlockMace(attacker.getInventory().getItemInMainHand())) return;
        event.setDamage(event.getDamage() * MACE_DAMAGE_MULTIPLIER);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        lastShock.remove(event.getPlayer().getUniqueId());
        lastRiptide.remove(event.getPlayer().getUniqueId());
        chargedUntil.remove(event.getPlayer().getUniqueId());
        superChargeCooldownEnd.remove(event.getPlayer().getUniqueId());
        lastHook.remove(event.getPlayer().getUniqueId());
        hookUses.remove(event.getPlayer().getUniqueId());
        lastBlast.remove(event.getPlayer().getUniqueId());
        compassClicks.remove(event.getPlayer().getUniqueId());
        blastUses.remove(event.getPlayer().getUniqueId());
    }

    /** Pushes nearby players away from the center and throws the user into the air. */
    private void shockwave(Player user, Location center) {
        UUID id = user.getUniqueId();
        long now = System.currentTimeMillis();
        Long last = lastShock.get(id);
        if (last != null && now - last < SHOCK_COOLDOWN_MS) return;
        lastShock.put(id, now);

        World world = center.getWorld();

        for (Player other : world.getNearbyPlayers(center, SHOCK_RADIUS)) {
            if (other.equals(user)) continue;

            Vector push = other.getLocation().toVector().subtract(center.toVector()).setY(0);
            if (push.lengthSquared() < 0.0001) {
                push = user.getLocation().getDirection().setY(0); // standing exactly on the center
            }
            other.setVelocity(push.normalize().multiply(SHOCK_PUSH).setY(SHOCK_PUSH_UP));
        }

        user.setVelocity(new Vector(0, SHOCK_SELF_LAUNCH, 0));

        world.spawnParticle(Particle.CLOUD, center, 30, 1.5, 0.1, 1.5, 0.05);
        world.playSound(center, Sound.ITEM_MACE_SMASH_GROUND, 1.0f, 1.0f);
    }

    // ---- Hook: right-click to shoot a black line and get pulled to where it lands ----

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack mace = player.getInventory().getItemInMainHand();
        if (!isCommandBlockMace(mace)) return;

        if (player.isSneaking()) {
            switchMove(player, mace);
        } else {
            switch (getMove(mace)) {
                case HOOKS -> fireHook(player);
                case PURPLE_SHOCKWAVE -> purpleShockwave(player);
                case BLACK_DOMAIN -> blackDomain(player);
            }
        }
    }

    /** Which move is selected on this mace (saved on the item itself). */
    private Move getMove(ItemStack mace) {
        int index = mace.getItemMeta().getPersistentDataContainer()
                .getOrDefault(moveKey, PersistentDataType.INTEGER, 0);
        Move[] all = Move.values();
        return all[Math.floorMod(index, all.length)];
    }

    /** Shift + right-click: select the next move. */
    private void switchMove(Player player, ItemStack mace) {
        Move[] all = Move.values();
        Move next = all[(getMove(mace).ordinal() + 1) % all.length];

        ItemMeta meta = mace.getItemMeta();
        meta.getPersistentDataContainer().set(moveKey, PersistentDataType.INTEGER, next.ordinal());
        mace.setItemMeta(meta);
        player.getInventory().setItemInMainHand(mace);

        player.sendActionBar(Component.text("Move: " + next.displayName, next.color));
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.2f);
    }

    // ---- Move 2: purple shockwave that launches you up and where you're looking ----

    private void purpleShockwave(Player user) {
        UUID id = user.getUniqueId();
        long now = System.currentTimeMillis();

        // Still recharging after the 5th use?
        Long cooldownEnd = blastCooldownEnd.get(id);
        if (cooldownEnd != null && now < cooldownEnd) {
            long secondsLeft = (cooldownEnd - now + 999) / 1000;
            user.sendActionBar(Component.text("Shockwave recharging: " + secondsLeft + "s", NamedTextColor.RED));
            return;
        }

        Long last = lastBlast.get(id);
        if (last != null && now - last < BLAST_SHOT_GAP_MS) return;
        lastBlast.put(id, now);

        // Count this use. The 5th one starts the cooldown.
        int used = blastUses.merge(id, 1, Integer::sum);
        if (used >= BLAST_MAX_USES) {
            blastUses.remove(id);
            blastCooldownEnd.put(id, now + BLAST_RECHARGE_MS);
            user.sendActionBar(Component.text("Last shockwave! Recharging for "
                    + (BLAST_RECHARGE_MS / 1000) + "s", NamedTextColor.RED));
        } else {
            user.sendActionBar(Component.text("Shockwaves left: " + (BLAST_MAX_USES - used),
                    NamedTextColor.LIGHT_PURPLE));
        }

        World world = user.getWorld();
        Location center = user.getLocation().add(0, 0.2, 0);

        // Push: about 4 blocks up and about 4 blocks in the direction you're facing
        Vector flat = user.getEyeLocation().getDirection().setY(0);
        Vector launch = flat.lengthSquared() > 0.0001
                ? flat.normalize().multiply(BLAST_FORWARD)
                : new Vector(0, 0, 0); // looking straight up or down: no sideways push
        launch.setY(BLAST_UP);
        user.setVelocity(launch);

        world.playSound(center, Sound.ITEM_MACE_SMASH_GROUND, 1.0f, 0.6f);

        // Expanding rings of purple particles
        Particle.DustOptions purple = new Particle.DustOptions(Color.fromRGB(150, 40, 255), 1.6f);
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                double radius = 0.6 + tick * 0.5;
                int points = 28;
                for (int i = 0; i < points; i++) {
                    double angle = 2 * Math.PI * i / points;
                    double x = center.getX() + Math.cos(angle) * radius;
                    double z = center.getZ() + Math.sin(angle) * radius;
                    world.spawnParticle(Particle.DUST, x, center.getY(), z, 1, 0, 0, 0, 0, purple);
                    world.spawnParticle(Particle.DUST, x, center.getY() + 0.6, z, 1, 0, 0, 0, 0, purple);
                }
                if (++tick > 8) cancel();
            }
        }.runTaskTimer(this, 0L, 1L);
    }

    /** The closest other player within 20 blocks of the user, if there is one. */
    private Player findHookTarget(Player user) {
        Player closest = null;
        double best = Double.MAX_VALUE;
        for (Player other : user.getWorld().getNearbyPlayers(user.getLocation(), HOOK_AUTO_TARGET_RADIUS)) {
            if (other.equals(user) || other.isDead() || other.getGameMode() == GameMode.SPECTATOR) continue;
            double d = other.getLocation().distanceSquared(user.getLocation());
            if (d < best) {
                best = d;
                closest = other;
            }
        }
        return closest;
    }

    private void fireHook(Player user) {
        UUID id = user.getUniqueId();
        long now = System.currentTimeMillis();

        // Still recharging after the 3rd hook?
        Long cooldownEnd = hookCooldownEnd.get(id);
        if (cooldownEnd != null && now < cooldownEnd) {
            long secondsLeft = (cooldownEnd - now + 999) / 1000;
            user.sendActionBar(Component.text("Hooks recharging: " + secondsLeft + "s", NamedTextColor.RED));
            return;
        }

        Long last = lastHook.get(id);
        if (last != null && now - last < HOOK_SHOT_GAP_MS) return;
        lastHook.put(id, now);

        // Count this shot. The 3rd one starts the 20 second cooldown.
        int used = hookUses.merge(id, 1, Integer::sum);
        if (used >= HOOK_MAX_USES) {
            hookUses.remove(id);
            hookCooldownEnd.put(id, now + HOOK_RECHARGE_MS);
            user.sendActionBar(Component.text("Last hook! Recharging for "
                    + (HOOK_RECHARGE_MS / 1000) + "s", NamedTextColor.RED));
        } else {
            user.sendActionBar(Component.text("Hooks left: " + (HOOK_MAX_USES - used), NamedTextColor.GRAY));
        }

        World world = user.getWorld();
        Location eye = user.getEyeLocation();
        Vector start = eye.toVector();

        // A player within 20 blocks is targeted automatically; otherwise the hook goes where you look
        final Vector dir;
        final boolean landed;
        final Vector end;
        Player autoTarget = findHookTarget(user);
        if (autoTarget != null) {
            end = autoTarget.getBoundingBox().getCenter();
            dir = end.clone().subtract(start).normalize();
            landed = true;
            user.sendActionBar(Component.text("Hook locked on to " + autoTarget.getName(), NamedTextColor.DARK_RED));
        } else {
            dir = eye.getDirection().normalize();
            RayTraceResult hit = world.rayTrace(
                    eye, dir, HOOK_RANGE, FluidCollisionMode.NEVER, true, 0.2,
                    entity -> entity instanceof LivingEntity && !entity.equals(user));
            landed = hit != null && hit.getHitPosition() != null;
            end = landed ? hit.getHitPosition() : start.clone().add(dir.clone().multiply(HOOK_RANGE));
        }
        double totalLength = start.distance(end);

        world.playSound(eye, Sound.ENTITY_FISHING_BOBBER_THROW, 1.0f, 0.8f);

        new BukkitRunnable() {
            double reach = 0;
            boolean pulled = false;
            int pullTicks = 0;

            @Override
            public void run() {
                if (!user.isOnline() || !user.getWorld().equals(world)) {
                    cancel();
                    return;
                }

                // The line starts at the user (so it follows them while they fly) and ends at the tip.
                Vector origin = user.getLocation().toVector().add(new Vector(0, 1.0, 0));
                reach = Math.min(totalLength, reach + HOOK_LINE_SPEED);
                Vector tip = start.clone().add(dir.clone().multiply(reach));
                drawLine(world, origin, tip);

                if (reach < totalLength) return; // still shooting out

                if (!landed) { // hit nothing: the line just disappears
                    cancel();
                    return;
                }

                if (!pulled) {
                    pulled = true;
                    user.setVelocity(hookPull(user, end));
                    world.playSound(end.toLocation(world), Sound.BLOCK_CHAIN_PLACE, 1.0f, 0.8f);
                }

                pullTicks++;
                if (pullTicks > 8) cancel(); // keep drawing the line for a few ticks while you fly
            }
        }.runTaskTimer(this, 0L, 1L);
    }

    /** Velocity that pulls the user toward the point where the hook landed. */
    private Vector hookPull(Player user, Vector landing) {
        Vector toHook = landing.clone().subtract(user.getLocation().toVector());
        double distance = toHook.length();
        if (distance < 1.0) {
            return new Vector(0, HOOK_LIFT, 0);
        }

        double speed = Math.min(HOOK_PULL_MAX, HOOK_PULL_BASE + distance * HOOK_PULL_PER_BLOCK);
        Vector pull = toHook.normalize().multiply(speed);
        pull.setY(pull.getY() + HOOK_LIFT); // still gets lifted off the ground
        return pull;
    }

    /** Draws a black line of particles between two points. */
    private void drawLine(World world, Vector from, Vector to) {
        // (1,1,1) instead of pure black, because pure 0,0,0 dust can render as red
        Particle.DustOptions black = new Particle.DustOptions(Color.fromRGB(1, 1, 1), 1.3f);

        Vector step = to.clone().subtract(from);
        double length = step.length();
        if (length < 0.01) return;
        step.normalize().multiply(0.4);

        Vector point = from.clone();
        for (double d = 0; d < length; d += 0.4) {
            world.spawnParticle(Particle.DUST, point.getX(), point.getY(), point.getZ(), 1, 0, 0, 0, 0, black);
            point.add(step);
        }
    }

    // ---- Move 3: Black Domain (everyone nearby is pulled into a black dome world for 60 seconds) ----

    /** When the current domain started. A domain older than its duration is stuck and gets reset. */
    private long domainStartedAt = 0;
    /** Errors are logged at most once every 30 seconds, so a repeating problem can't flood the console. */
    private long lastDomainErrorLog = 0;

    private void logDomainError(String what, Throwable t) {
        long now = System.currentTimeMillis();
        if (now - lastDomainErrorLog < 30_000) return;
        lastDomainErrorLog = now;
        getLogger().log(java.util.logging.Level.SEVERE, "Black Domain: " + what, t);
    }

    private boolean domainIsStuck() {
        return System.currentTimeMillis() - domainStartedAt > DOMAIN_DURATION_TICKS * 50L + 5000;
    }

    private void blackDomain(Player user) {
        try {
            startBlackDomain(user);
        } catch (Throwable t) {
            logDomainError("could not open", t);
            user.sendMessage(Component.text("The Black Domain failed to open.", NamedTextColor.RED));
            resetDomain();
        }
    }

    /** Closes the domain no matter what state it is in, so it can always be used again. */
    private void resetDomain() {
        try {
            endDomain();
        } catch (Throwable t) {
            domainTask = null;
            domainOwner = null;
            domainStartedAt = 0;
            domainOrigins.clear();
        }
    }

    // ---- Remembering where people were, even across logouts and restarts ----

    private File returnsFile() {
        return new File(getDataFolder(), "domain_returns.yml");
    }

    /** Writes every saved "where to send you back" spot to disk. */
    private void saveReturns() {
        try {
            org.bukkit.configuration.file.YamlConfiguration yml = new org.bukkit.configuration.file.YamlConfiguration();
            Map<UUID, Location> all = new HashMap<>(pendingReturn);
            all.putAll(deathReturn);
            all.putAll(domainOrigins);
            for (Map.Entry<UUID, Location> e : all.entrySet()) {
                Location l = e.getValue();
                if (l == null || l.getWorld() == null) continue;
                String key = "returns." + e.getKey();
                yml.set(key + ".world", l.getWorld().getName());
                yml.set(key + ".x", l.getX());
                yml.set(key + ".y", l.getY());
                yml.set(key + ".z", l.getZ());
                yml.set(key + ".yaw", (double) l.getYaw());
                yml.set(key + ".pitch", (double) l.getPitch());
            }
            getDataFolder().mkdirs();
            yml.save(returnsFile());
        } catch (Throwable t) {
            logDomainError("could not save return spots", t);
        }
    }

    /** Reads the saved spots at startup. Nobody is in a domain then, so they all count as "waiting to go back". */
    private void loadReturns() {
        try {
            File f = returnsFile();
            if (!f.exists()) return;
            org.bukkit.configuration.file.YamlConfiguration yml =
                    org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(f);
            var section = yml.getConfigurationSection("returns");
            if (section == null) return;
            for (String key : section.getKeys(false)) {
                try {
                    World w = getServer().getWorld(section.getString(key + ".world", ""));
                    if (w == null) continue;
                    pendingReturn.put(UUID.fromString(key), new Location(w,
                            section.getDouble(key + ".x"), section.getDouble(key + ".y"), section.getDouble(key + ".z"),
                            (float) section.getDouble(key + ".yaw"), (float) section.getDouble(key + ".pitch")));
                } catch (Throwable ignored) {
                    // skip a bad entry
                }
            }
        } catch (Throwable t) {
            logDomainError("could not load return spots", t);
        }
    }

    /** Takes (and forgets) the saved spot for this player, if there is one. */
    private Location takeSavedReturn(UUID id) {
        Location back = pendingReturn.remove(id);
        if (back == null) back = deathReturn.remove(id);
        if (back != null) saveReturns();
        return back;
    }

    private void startBlackDomain(Player user) {
        UUID id = user.getUniqueId();
        long now = System.currentTimeMillis();

        Long cooldownEnd = domainCooldownEnd.get(id);
        if (cooldownEnd != null && now < cooldownEnd) {
            long secondsLeft = (cooldownEnd - now + 999) / 1000;
            user.sendActionBar(Component.text("Black Domain recharging: " + secondsLeft + "s", NamedTextColor.RED));
            getLogger().info("Black Domain: " + user.getName() + " is recharging (" + secondsLeft + "s left)");
            return;
        }

        if (domainOwner != null) {
            Player currentOwner = getServer().getPlayer(domainOwner);
            boolean healthy = domainTask != null && !domainTask.isCancelled() && !domainIsStuck()
                    && currentOwner != null && currentOwner.isOnline() && !currentOwner.isDead()
                    && domainOrigins.containsKey(domainOwner);
            if (healthy) {
                long left = Math.max(0, (domainStartedAt + DOMAIN_DURATION_TICKS * 50L - now) / 1000);
                user.sendActionBar(Component.text("A domain is already open (" + currentOwner.getName()
                        + ", " + left + "s left).", NamedTextColor.RED));
                getLogger().info("Black Domain: " + user.getName() + " tried to open one while "
                        + currentOwner.getName() + "'s is open");
                return;
            }
            // A leftover from a domain that never closed properly: close it and carry on
            getLogger().info("Black Domain: clearing a leftover domain before opening a new one");
            resetDomain();
            domainCooldownEnd.remove(id);
        }
        getLogger().info("Black Domain: opening for " + user.getName());

        // Standing in the domain world with no domain running: just walk you out
        if (user.getWorld().getName().equals(DOMAIN_WORLD_NAME)) {
            returnFromDomain(user, bestReturn(user));
            return;
        }

        World domain = getDomainWorld();
        if (domain == null) {
            user.sendMessage(Component.text("The Black Domain could not be opened.", NamedTextColor.RED));
            return;
        }
        // Load every chunk of the dome first, so the teleport never waits on world generation
        for (int cx = -2; cx <= 1; cx++) {
            for (int cz = -2; cz <= 1; cz++) domain.getChunkAt(cx, cz);
        }
        if (domainLooksBroken(domain)) repairDomain(domain);
        clearDomainEntities(domain);

        // Everyone close enough comes with you
        World from = user.getWorld();
        List<Player> pulled = new ArrayList<>();
        pulled.add(user);
        for (Player p : from.getNearbyPlayers(user.getLocation(), DOMAIN_GATHER_RADIUS)) {
            if (!p.equals(user) && p.getGameMode() != GameMode.SPECTATOR) pulled.add(p);
        }

        from.playSound(user.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 0.5f);
        from.spawnParticle(Particle.DUST, user.getLocation().add(0, 1, 0), 80, 3, 1.5, 3, 0,
                new Particle.DustOptions(Color.fromRGB(1, 1, 1), 2.0f));

        domainOwner = id;
        domainStartedAt = now;
        domainOrigins.clear();

        Location center = new Location(domain, 0.5, DOMAIN_FLOOR_Y, 0.5);
        int others = Math.max(1, pulled.size() - 1);
        int index = 0;
        for (Player p : pulled) {
            Location origin = p.getLocation();
            Location spot = center.clone();
            if (!p.equals(user)) {
                double angle = 2 * Math.PI * (index++) / others;
                spot.add(Math.cos(angle) * DOMAIN_SPAWN_DISTANCE, 0, Math.sin(angle) * DOMAIN_SPAWN_DISTANCE);
                spot.setDirection(center.toVector().subtract(spot.toVector()));
            }
            try {
                p.leaveVehicle();
                if (!p.teleport(spot)) { // someone else's plugin said no: they just stay out
                    getLogger().warning("Black Domain: the teleport of " + p.getName()
                            + " into the domain was refused (another plugin cancelled it?)");
                    continue;
                }
            } catch (Throwable t) {
                logDomainError("could not pull " + p.getName() + " in", t);
                continue;
            }
            domainOrigins.put(p.getUniqueId(), origin);
            rememberReturn(p, origin);
            p.playSound(spot, Sound.BLOCK_BEACON_POWER_SELECT, 1.0f, 0.5f);
            p.sendMessage(Component.text(p.equals(user)
                    ? "Domain Expansion: Black Domain."
                    : "You have been pulled into a Black Domain...", NamedTextColor.DARK_GRAY));
        }

        if (!domainOrigins.containsKey(id)) {
            // Couldn't even get the owner in
            user.sendMessage(Component.text("The Black Domain could not be opened.", NamedTextColor.RED));
            resetDomain();
            domainCooldownEnd.remove(id);
            return;
        }

        saveReturns(); // remember everyone's spot on disk, in case the server stops while they're inside
        getLogger().info("Black Domain opened by " + user.getName() + " (" + domainOrigins.size() + " players inside)");

        domainTask = new BukkitRunnable() {
            int age = 0;

            @Override
            public void run() {
                try {
                    Player owner = getServer().getPlayer(id);
                    if (age >= DOMAIN_DURATION_TICKS || owner == null || !owner.isOnline() || owner.isDead()
                            || !domainOrigins.containsKey(id)) {
                        endDomain();
                        return;
                    }
                    int secondsLeft = (DOMAIN_DURATION_TICKS - age) / 20;
                    for (UUID inside : new ArrayList<>(domainOrigins.keySet())) {
                        Player p = getServer().getPlayer(inside);
                        if (p == null || !p.isOnline()) continue;
                        p.sendActionBar(Component.text("Black Domain: " + secondsLeft + "s", NamedTextColor.DARK_GRAY));
                        if (DOMAIN_BLINDS_OPPONENTS && !inside.equals(id)) {
                            p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0, false, false));
                        }
                    }
                    age += 10;
                } catch (Throwable t) {
                    // Stop this timer for good, so one error can't repeat forever, then close the domain
                    logDomainError("timer error", t);
                    try {
                        cancel();
                    } catch (Throwable ignored) {
                        // already stopped
                    }
                    resetDomain();
                }
            }
        }.runTaskTimer(this, 10L, 10L);
    }

    /** Ends the domain and sends everyone back to where they were. Safe to call more than once. */
    private void endDomain() {
        BukkitTask task = domainTask;
        domainTask = null;
        if (task != null) task.cancel();

        UUID owner = domainOwner;
        Map<UUID, Location> inside = new HashMap<>(domainOrigins);
        domainOrigins.clear();
        domainOwner = null;
        domainStartedAt = 0;

        if (owner != null) {
            domainCooldownEnd.put(owner, System.currentTimeMillis() + DOMAIN_COOLDOWN_MS);
        }
        if (owner == null && inside.isEmpty()) return; // nothing was open

        getLogger().info("Black Domain closed (" + inside.size() + " players sent back)");

        for (Map.Entry<UUID, Location> entry : inside.entrySet()) {
            try {
                Player p = getServer().getPlayer(entry.getKey());
                if (p == null || !p.isOnline()) {
                    pendingReturn.put(entry.getKey(), entry.getValue());
                    continue;
                }
                returnFromDomain(p, entry.getValue());
            } catch (Throwable t) {
                logDomainError("could not send a player back", t);
            }
        }
        saveReturns();
    }

    // The spot a player was pulled in from is ALSO saved on the player themselves, so it can never be lost
    // (it survives resets, restarts and anything else that clears the plugin's own lists).

    private NamespacedKey domainReturnKey() {
        return new NamespacedKey(this, "domain_return");
    }

    private void rememberReturn(Player p, Location l) {
        if (l == null || l.getWorld() == null) return;
        p.getPersistentDataContainer().set(domainReturnKey(), PersistentDataType.STRING,
                l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ()
                        + ";" + l.getYaw() + ";" + l.getPitch());
    }

    private Location recallReturn(Player p) {
        String text = p.getPersistentDataContainer().get(domainReturnKey(), PersistentDataType.STRING);
        if (text == null) return null;
        try {
            String[] a = text.split(";");
            World w = getServer().getWorld(a[0]);
            if (w == null) return null;
            return new Location(w, Double.parseDouble(a[1]), Double.parseDouble(a[2]), Double.parseDouble(a[3]),
                    Float.parseFloat(a[4]), Float.parseFloat(a[5]));
        } catch (RuntimeException e) {
            return null;
        }
    }

    /** Where to send someone who is stuck in the domain: their saved spot, then the spot on them, then their bed. */
    private Location bestReturn(Player p) {
        Location back = takeSavedReturn(p.getUniqueId());
        if (back == null) back = recallReturn(p);
        if (back == null) back = p.getRespawnLocation();
        return back;
    }

    private void returnFromDomain(Player p, Location origin) {
        returnFromDomain(p, origin, 0);
    }

    private void returnFromDomain(Player p, Location origin, int attempt) {
        if (!p.isOnline() || p.isDead()) return;
        if (attempt > 0 && !p.getWorld().getName().equals(DOMAIN_WORLD_NAME)) return; // already got out

        p.removePotionEffect(PotionEffectType.BLINDNESS);
        p.leaveVehicle();
        Location spawn = getServer().getWorlds().get(0).getSpawnLocation();
        Location dest = origin;
        if (dest == null || dest.getWorld() == null || dest.getWorld().getName().equals(DOMAIN_WORLD_NAME)) {
            dest = recallReturn(p); // the spot saved on the player
        }
        boolean usingSpawn = false;
        if (dest == null || dest.getWorld() == null || dest.getWorld().getName().equals(DOMAIN_WORLD_NAME)) {
            dest = spawn;
            usingSpawn = true;
        }

        boolean ok = p.teleport(dest);
        if (!ok && !usingSpawn && attempt < 3) {
            // Something said no. Try the SAME spot again in a moment before giving up on it.
            getLogger().warning("Black Domain: sending " + p.getName() + " back was refused, trying again");
            final Location again = dest;
            final int next = attempt + 1;
            getServer().getScheduler().runTaskLater(this, () -> returnFromDomain(p, again, next), 5L);
            return;
        }
        if (!ok && !usingSpawn) {
            dest = spawn;
            ok = p.teleport(dest); // their old spot never worked: use the main world's spawn
        }
        if (ok) {
            p.setFallDistance(0f);
            p.getPersistentDataContainer().remove(domainReturnKey());
            p.playSound(dest, Sound.BLOCK_BEACON_DEACTIVATE, 1.0f, 0.5f);
            p.sendMessage(Component.text("The Black Domain fades away.", NamedTextColor.GRAY));
            getLogger().info("Black Domain: sent " + p.getName() + " back to " + dest.getWorld().getName() + " "
                    + dest.getBlockX() + " " + dest.getBlockY() + " " + dest.getBlockZ());
        }
    }

    /** A quick check of a few spots, so the full repair only runs when something is actually wrong. */
    private boolean domainLooksBroken(World domain) {
        int[][] samples = {
                {0, -1, 0}, {6, -1, 0}, {0, -1, 6}, {-6, -1, -6},
                {DOMAIN_RADIUS, 0, 0}, {0, 0, DOMAIN_RADIUS}, {0, DOMAIN_RADIUS, 0}
        };
        for (int[] spot : samples) {
            int y = DOMAIN_FLOOR_Y + spot[1];
            Material want = DomainGenerator.materialAt(spot[0], y, spot[2]);
            Material have = domain.getBlockAt(spot[0], y, spot[2]).getType();
            if (want == null ? !have.isAir() : have != want) return true;
        }
        return false;
    }

    /** Puts every block of the domain back the way it should be. */
    private void repairDomain(World domain) {
        int outer = DOMAIN_RADIUS + 2;
        for (int x = -outer; x <= outer; x++) {
            for (int z = -outer; z <= outer; z++) {
                if (x * x + z * z > outer * outer) continue;
                for (int y = DOMAIN_FLOOR_Y - 2; y <= DOMAIN_FLOOR_Y + outer; y++) {
                    Material want = DomainGenerator.materialAt(x, y, z);
                    Block block = domain.getBlockAt(x, y, z);
                    Material have = block.getType();
                    if (want == null) {
                        if (!have.isAir()) block.setType(Material.AIR, false);
                    } else if (have != want) {
                        block.setType(want, false);
                    }
                }
            }
        }
    }

    /** Clears dropped items, arrows, tridents and so on left behind inside the domain. */
    private void clearDomainEntities(World domain) {
        for (Entity entity : domain.getEntities()) {
            if (!(entity instanceof Player)) entity.remove();
        }
    }

    /** Nothing in the domain can be blown up. */
    @EventHandler(ignoreCancelled = true)
    public void onDomainExplode(EntityExplodeEvent event) {
        if (event.getLocation().getWorld().getName().equals(DOMAIN_WORLD_NAME)) event.blockList().clear();
    }

    @EventHandler(ignoreCancelled = true)
    public void onDomainBlockExplode(BlockExplodeEvent event) {
        if (event.getBlock().getWorld().getName().equals(DOMAIN_WORLD_NAME)) event.blockList().clear();
    }

    /** Every few seconds: closes a domain that got stuck, and sends out anyone left behind in the domain world. */
    private void domainWatchdog() {
        try {
            if (domainOwner != null) {
                Player owner = getServer().getPlayer(domainOwner);
                boolean timerDead = domainTask == null || domainTask.isCancelled();
                if (timerDead || domainIsStuck() || owner == null || !owner.isOnline()
                        || !domainOrigins.containsKey(domainOwner)) {
                    endDomain();
                }
            }
            World domain = getServer().getWorld(DOMAIN_WORLD_NAME);
            if (domain != null && domainOwner == null) {
                for (Player stuck : new ArrayList<>(domain.getPlayers())) {
                    if (stuck.isDead()) continue;
                    // their saved spot first, then the spot saved on them, then their bed, then the main spawn
                    returnFromDomain(stuck, bestReturn(stuck));
                }
            }
        } catch (Throwable t) {
            logDomainError("watchdog error", t);
        }
    }

    /** Gets the Black Domain world, creating it the first time. */
    private World getDomainWorld() {
        World domain = getServer().getWorld(DOMAIN_WORLD_NAME);
        if (domain != null) {
            domain.setAutoSave(false);
            return domain;
        }

        try {
            WorldCreator creator = new WorldCreator(DOMAIN_WORLD_NAME);
            creator.environment(World.Environment.NORMAL);
            creator.generator(new DomainGenerator());
            creator.generateStructures(false);
            domain = creator.createWorld();
        } catch (Exception e) {
            logDomainError("could not create the world", e);
            return null;
        }
        if (domain == null) return null;
        // Never save the dome's chunks: every time it is opened it is built fresh, so it can't be left damaged
        domain.setAutoSave(false);
        domain.setSpawnFlags(false, false); // no monsters or animals inside
        domain.setSpawnLocation(0, DOMAIN_FLOOR_Y, 0);
        return domain;
    }

    /** Builds the domain: a black floor and a black half-sphere, with glowing lights in the floor. */
    public static class DomainGenerator extends ChunkGenerator {
        /** What block belongs at this spot in the domain (null = air). Used to build AND to repair it. */
        static Material materialAt(int wx, int wy, int wz) {
            int outer = DOMAIN_RADIUS + 2;
            int h2 = wx * wx + wz * wz;
            if (h2 > outer * outer) return null;
            int dy = wy - DOMAIN_FLOOR_Y;
            if (dy == -1) {
                // Floor top, with a light every 6 blocks
                boolean light = wx % 6 == 0 && wz % 6 == 0
                        && h2 < (DOMAIN_RADIUS - 2) * (DOMAIN_RADIUS - 2);
                return light ? Material.PEARLESCENT_FROGLIGHT : Material.BLACK_CONCRETE;
            }
            if (dy == -2) return Material.BLACK_CONCRETE;
            if (dy >= 0) {
                int d2 = h2 + dy * dy;
                // The dome wall: a shell two blocks thick
                if (d2 >= DOMAIN_RADIUS * DOMAIN_RADIUS && d2 <= outer * outer) return Material.BLACK_CONCRETE;
            }
            return null;
        }

        @Override
        public void generateNoise(WorldInfo worldInfo, Random random, int chunkX, int chunkZ, ChunkData chunkData) {
            int outer = DOMAIN_RADIUS + 2;
            int baseX = chunkX << 4;
            int baseZ = chunkZ << 4;
            if (baseX > outer || baseX + 15 < -outer || baseZ > outer || baseZ + 15 < -outer) return;

            for (int x = 0; x < 16; x++) {
                for (int z = 0; z < 16; z++) {
                    for (int y = DOMAIN_FLOOR_Y - 2; y <= DOMAIN_FLOOR_Y + outer; y++) {
                        Material m = materialAt(baseX + x, y, baseZ + z);
                        if (m != null) chunkData.setBlock(x, y, z, m);
                    }
                }
            }
        }

        @Override
        public Location getFixedSpawnLocation(World world, Random random) {
            return new Location(world, 0.5, DOMAIN_FLOOR_Y, 0.5);
        }
    }

    // Rules inside the domain

    @EventHandler(ignoreCancelled = true)
    public void onDomainBreak(BlockBreakEvent event) {
        if (event.getBlock().getWorld().getName().equals(DOMAIN_WORLD_NAME)
                && event.getPlayer().getGameMode() != GameMode.CREATIVE) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDomainPlace(BlockPlaceEvent event) {
        if (event.getBlock().getWorld().getName().equals(DOMAIN_WORLD_NAME)
                && event.getPlayer().getGameMode() != GameMode.CREATIVE) {
            event.setCancelled(true);
        }
    }

    /** No ender pearl or chorus fruit escapes. */
    @EventHandler(ignoreCancelled = true)
    public void onDomainTeleport(PlayerTeleportEvent event) {
        if (!domainOrigins.containsKey(event.getPlayer().getUniqueId())) return;
        PlayerTeleportEvent.TeleportCause cause = event.getCause();
        if (cause == PlayerTeleportEvent.TeleportCause.ENDER_PEARL
                || cause == PlayerTeleportEvent.TeleportCause.CHORUS_FRUIT) {
            event.setCancelled(true);
        }
    }

    /** Someone who dies inside is not teleported back when the domain ends (they respawn normally). */
    @EventHandler
    public void onDomainDeath(PlayerDeathEvent event) {
        Location origin = domainOrigins.remove(event.getEntity().getUniqueId());
        if (origin != null) {
            deathReturn.put(event.getEntity().getUniqueId(), origin);
            saveReturns();
        }
    }

    /** Someone who died inside the domain respawns where they were before it pulled them in. */
    @EventHandler(priority = EventPriority.HIGH)
    public void onDomainRespawn(PlayerRespawnEvent event) {
        Player p = event.getPlayer();
        if (isSealed(p)) return; // the seal always wins
        Location back = deathReturn.remove(p.getUniqueId());
        if (back == null) return;
        saveReturns();
        if (back.getWorld() == null || back.getWorld().getName().equals(DOMAIN_WORLD_NAME)) return;
        event.setRespawnLocation(back);
    }

    /** Someone who logged off inside the domain is put back where they belong when they return. */
    @EventHandler
    public void onDomainJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        Location back = takeSavedReturn(p.getUniqueId());
        if (back != null && !p.getWorld().getName().equals(DOMAIN_WORLD_NAME)) {
            return; // an old leftover spot: they're not inside the domain, so leave them where they are
        }
        if (back != null) {
            returnFromDomain(p, back);
        } else if (p.getWorld().getName().equals(DOMAIN_WORLD_NAME)
                && !domainOrigins.containsKey(p.getUniqueId())) {
            returnFromDomain(p, bestReturn(p)); // their saved spot first, the main world's spawn only as a last resort
        }
    }

    // ---- Compass Zombie: 100 health, drops a Dimension Compass when it dies ----

    private boolean summonZombie(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only a player can use this command.");
            return true;
        }

        // Spawn it 3 blocks in front of you
        Location spot = player.getLocation();
        Vector ahead = spot.getDirection().setY(0);
        if (ahead.lengthSquared() > 0.0001) {
            spot.add(ahead.normalize().multiply(3));
        }

        player.getWorld().spawn(spot, Zombie.class, zombie -> {
            zombie.getAttribute(Attribute.MAX_HEALTH).setBaseValue(100.0);
            zombie.setHealth(100.0);
            zombie.customName(Component.text("Compass Zombie", NamedTextColor.DARK_RED));
            zombie.setCustomNameVisible(true);
            zombie.setShouldBurnInDay(false); // so the sun doesn't kill it
            zombie.setPersistent(true);
            zombie.setRemoveWhenFarAway(false);
            zombie.getPersistentDataContainer().set(zombieKey, PersistentDataType.BYTE, (byte) 1);
        });

        player.sendMessage("§aSummoned the Compass Zombie (100 health).");
        return true;
    }

    /** When the Compass Zombie dies, it drops the Dimension Compass. */
    @EventHandler
    public void onZombieDeath(EntityDeathEvent event) {
        if (!event.getEntity().getPersistentDataContainer().has(zombieKey, PersistentDataType.BYTE)) return;
        event.getDrops().add(createDimensionCompass());
    }

    private boolean isDimensionCompass(ItemStack stack) {
        if (stack == null || stack.getType() != Material.COMPASS || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(compassKey, PersistentDataType.BYTE);
    }

    private ItemStack createDimensionCompass() {
        ItemStack compass = new ItemStack(Material.COMPASS);
        ItemMeta meta = compass.getItemMeta();
        meta.displayName(Component.text("Dimension Compass", NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Leads to a new dimension", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Drop it on the command block there", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(compassKey, PersistentDataType.BYTE, (byte) 1);
        compass.setItemMeta(meta);
        return compass;
    }

    /** Right-clicking the Dimension Compass: clicks 1-3 say something, click 4 takes you to the Null Realm. */
    @EventHandler
    public void onCompassUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack held = event.getPlayer().getInventory().getItemInMainHand();
        if (held.getType() != Material.COMPASS || !held.hasItemMeta()) return;
        if (!held.getItemMeta().getPersistentDataContainer().has(compassKey, PersistentDataType.BYTE)) return;

        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        int clicks = compassClicks.merge(id, 1, Integer::sum);

        if (clicks < 4) {
            player.sendMessage(Component.text(COMPASS_LINES[clicks - 1], NamedTextColor.AQUA));
            player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 0.6f + clicks * 0.2f);
        } else {
            compassClicks.remove(id);
            enterNullRealm(player, true); // the Dimension Compass brings the command block back
        }
    }

    // ---- The Null Realm: nothing but obsidian ----

    /** Where you arrive: just next to the command block. */
    private Location nullRealmArrival(World realm) {
        return new Location(realm, REALM_BLOCK_X + 0.5, REALM_BLOCK_Y, REALM_BLOCK_Z + 2.5);
    }

    private void enterNullRealm(Player player, boolean respawnBlock) {
        World realm = getNullRealm();
        if (realm == null) {
            player.sendMessage(Component.text("The compass crumbles... the Null Realm could not be opened.",
                    NamedTextColor.RED));
            return;
        }

        // Only the Dimension Compass (from the Compass Zombie) puts the command block back
        if (respawnBlock) {
            Block block = realm.getBlockAt(REALM_BLOCK_X, REALM_BLOCK_Y, REALM_BLOCK_Z);
            if (block.getType() != Material.COMMAND_BLOCK) {
                block.setType(Material.COMMAND_BLOCK, false);
                Location center = block.getLocation().add(0.5, 0.5, 0.5);
                realm.spawnParticle(Particle.DUST, center, 40, 0.4, 0.4, 0.4, 0,
                        new Particle.DustOptions(Color.fromRGB(110, 0, 200), 1.5f));
                realm.playSound(center, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 0.6f);
            }
        }

        player.sendMessage(Component.text("The world fades. You step into the Null Realm.",
                NamedTextColor.DARK_GRAY));
        player.playSound(player.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 0.6f, 0.5f);
        player.teleport(nullRealmArrival(realm));
    }

    /** Gets the Null Realm world, creating it the first time. */
    private World getNullRealm() {
        World realm = getServer().getWorld(NULL_REALM_NAME);
        if (realm == null) {
            try {
                WorldCreator creator = new WorldCreator(NULL_REALM_NAME);
                creator.environment(World.Environment.NORMAL);
                creator.generator(new ObsidianGenerator());
                creator.generateStructures(false);
                realm = creator.createWorld();
            } catch (Exception e) {
                getLogger().severe("Could not create the Null Realm: " + e.getMessage());
                return null;
            }
        }
        if (realm == null) return null;

        realm.setSpawnFlags(false, false); // no monsters or animals in the Null Realm
        realm.setSpawnLocation(REALM_BLOCK_X, REALM_BLOCK_Y, REALM_BLOCK_Z + 2);

        return realm; // the command block is placed by enterNullRealm (Dimension Compass only)
    }

    /** A world generator that fills the bottom of the world with solid obsidian and nothing else. */
    public static class ObsidianGenerator extends ChunkGenerator {
        @Override
        public void generateNoise(WorldInfo worldInfo, Random random, int chunkX, int chunkZ, ChunkData chunkData) {
            chunkData.setRegion(0, NULL_REALM_FLOOR_Y - 4, 0, 16, NULL_REALM_FLOOR_Y + 1, 16, Material.OBSIDIAN);
        }

        @Override
        public Location getFixedSpawnLocation(World world, Random random) {
            return new Location(world, REALM_BLOCK_X + 0.5, REALM_BLOCK_Y, REALM_BLOCK_Z + 2.5);
        }
    }

    // ---- Dropping an item on the Null Realm's command block gives a Null Compass ----

    @EventHandler
    public void onDropOnRealmBlock(PlayerDropItemEvent event) {
        Item item = event.getItemDrop();
        if (!isDimensionCompass(item.getItemStack())) return; // only the Dimension Compass works here

        UUID playerId = event.getPlayer().getUniqueId();

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                ticks += 2;
                if (!item.isValid() || ticks > WATCH_TICKS) {
                    cancel();
                    return;
                }
                if (isOnRealmBlock(item)) {
                    cancel();
                    giveNullCompass(playerId, item);
                }
            }
        }.runTaskTimer(this, 2L, 2L);
    }

    private boolean isOnRealmBlock(Item item) {
        Location loc = item.getLocation();
        if (!loc.getWorld().getName().equals(NULL_REALM_NAME)) return false;
        return loc.getBlockX() == REALM_BLOCK_X
                && loc.getBlockZ() == REALM_BLOCK_Z
                && loc.getY() >= REALM_BLOCK_Y + 0.9
                && loc.getY() <= REALM_BLOCK_Y + 1.6
                && loc.getWorld().getBlockAt(REALM_BLOCK_X, REALM_BLOCK_Y, REALM_BLOCK_Z).getType() == Material.COMMAND_BLOCK;
    }

    private void giveNullCompass(UUID playerId, Item dropped) {
        Location spot = dropped.getLocation();
        World world = spot.getWorld();
        // One Dimension Compass is used up...
        ItemStack stack = dropped.getItemStack();
        if (stack.getAmount() > 1) {
            stack.setAmount(stack.getAmount() - 1);
            dropped.setItemStack(stack);
        } else {
            dropped.remove();
        }
        // ...and so is the command block. It only comes back when someone enters with a new Dimension Compass.
        Block realmBlock = world.getBlockAt(REALM_BLOCK_X, REALM_BLOCK_Y, REALM_BLOCK_Z);
        if (realmBlock.getType() == Material.COMMAND_BLOCK) {
            realmBlock.setType(Material.AIR, false);
            world.spawnParticle(Particle.BLOCK, realmBlock.getLocation().add(0.5, 0.5, 0.5), 40, 0.3, 0.3, 0.3, 0.1,
                    Material.COMMAND_BLOCK.createBlockData());
            world.playSound(spot, Sound.BLOCK_STONE_BREAK, 1.0f, 0.8f);
        }

        world.spawnParticle(Particle.DUST, spot, 40, 0.3, 0.3, 0.3, 0,
                new Particle.DustOptions(Color.fromRGB(110, 0, 200), 1.5f));
        world.playSound(spot, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 0.5f);

        Player player = getServer().getPlayer(playerId);
        ItemStack compass = createNullCompass();
        if (player != null && player.isOnline()) {
            var leftovers = player.getInventory().addItem(compass);
            leftovers.values().forEach(i -> world.dropItemNaturally(player.getLocation(), i));
            player.sendMessage(Component.text("The command block forges a Null Compass for you.",
                    NamedTextColor.DARK_PURPLE));
        } else {
            world.dropItemNaturally(spot.clone().add(0, 0.5, 0), compass);
        }
    }

    // ---- The Null Compass: teleports you to the Null Realm or to any player ----

    private ItemStack createNullCompass() {
        ItemStack compass = new ItemStack(Material.COMPASS);
        ItemMeta meta = compass.getItemMeta();
        meta.displayName(Component.text("Null Compass", NamedTextColor.DARK_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Right-click: teleport to the selected target", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Shift + right-click: change target", NamedTextColor.LIGHT_PURPLE)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(nullCompassKey, PersistentDataType.BYTE, (byte) 1);
        compass.setItemMeta(meta);
        return compass;
    }

    private boolean isNullCompass(ItemStack stack) {
        if (stack == null || stack.getType() != Material.COMPASS || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(nullCompassKey, PersistentDataType.BYTE);
    }

    @EventHandler
    public void onNullCompassUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack compass = player.getInventory().getItemInMainHand();
        if (!isNullCompass(compass)) return;

        if (player.isSneaking()) {
            switchCompassTarget(player, compass);
        } else {
            useCompassTarget(player, compass);
        }
    }

    /** The selected target: "realm" for the Null Realm, otherwise a player's UUID. */
    private String getCompassTarget(ItemStack compass) {
        return compass.getItemMeta().getPersistentDataContainer()
                .getOrDefault(targetKey, PersistentDataType.STRING, "realm");
    }

    private static final String WORLD_TARGET_PREFIX = "world:";

    /** Worlds the Null Compass must never list: the Null Realm has its own entry, the domain is managed by the move. */
    private boolean isCompassWorld(World w) {
        String n = w.getName();
        return !n.equals(NULL_REALM_NAME) && !n.equals(DOMAIN_WORLD_NAME);
    }

    private String worldLabel(World w) {
        return switch (w.getEnvironment()) {
            case NORMAL -> "Overworld (" + w.getName() + ")";
            case NETHER -> "Nether (" + w.getName() + ")";
            case THE_END -> "The End (" + w.getName() + ")";
            default -> w.getName();
        };
    }

    private String targetName(String target) {
        if (target.equals("realm")) return "Null Realm";
        if (target.startsWith(WORLD_TARGET_PREFIX)) {
            World w = getServer().getWorld(target.substring(WORLD_TARGET_PREFIX.length()));
            return w != null ? worldLabel(w) : "an unloaded dimension";
        }
        try {
            Player p = getServer().getPlayer(UUID.fromString(target));
            return p != null ? p.getName() : "an offline player";
        } catch (IllegalArgumentException e) {
            return "unknown";
        }
    }

    /** A safe place to arrive in a dimension: its spawn, moved to open air (the Nether has a roof and lava). */
    private Location safeArrival(World w) {
        if (w.getName().equals(NULL_REALM_NAME)) return nullRealmArrival(w);
        Location spawn = w.getSpawnLocation();
        int bx = spawn.getBlockX();
        int bz = spawn.getBlockZ();

        if (w.getEnvironment() == World.Environment.NETHER) {
            // Search outward from the spawn for solid ground with two free blocks above it, below the roof
            for (int radius = 0; radius <= 24; radius += 2) {
                for (int dx = -radius; dx <= radius; dx += 2) {
                    for (int dz = -radius; dz <= radius; dz += 2) {
                        if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) continue;
                        for (int y = 100; y >= 32; y--) {
                            Block floor = w.getBlockAt(bx + dx, y, bz + dz);
                            if (!floor.getType().isSolid() || floor.getType() == Material.BEDROCK) continue;
                            if (floor.getRelative(0, 1, 0).isPassable() && !floor.getRelative(0, 1, 0).isLiquid()
                                    && floor.getRelative(0, 2, 0).isPassable() && !floor.getRelative(0, 2, 0).isLiquid()) {
                                return new Location(w, bx + dx + 0.5, y + 1, bz + dz + 0.5);
                            }
                        }
                    }
                }
            }
            // Nothing found: build a small platform
            int y = 64;
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    w.getBlockAt(bx + dx, y - 1, bz + dz).setType(Material.NETHERRACK, false);
                    for (int dy = 0; dy <= 2; dy++) {
                        w.getBlockAt(bx + dx, y + dy, bz + dz).setType(Material.AIR, false);
                    }
                }
            }
            return new Location(w, bx + 0.5, y, bz + 0.5);
        }

        if (w.getEnvironment() == World.Environment.THE_END) {
            return spawn.clone().add(0.5, 0, 0.5); // the obsidian platform
        }

        // Overworld and other worlds: stand on the highest block at the spawn
        int y = w.getHighestBlockYAt(bx, bz) + 1;
        return new Location(w, bx + 0.5, y, bz + 0.5);
    }

    /** Shift + right-click: next target. The list is the Null Realm, then every other online player. */
    private void switchCompassTarget(Player user, ItemStack compass) {
        List<Player> others = new ArrayList<>();
        for (Player p : getServer().getOnlinePlayers()) {
            if (!p.equals(user)) others.add(p);
        }
        others.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));

        List<String> targets = new ArrayList<>();
        targets.add("realm");
        // Every other dimension on the server (Overworld, Nether, End and any custom world)
        for (World w : getServer().getWorlds()) {
            if (isCompassWorld(w)) targets.add(WORLD_TARGET_PREFIX + w.getName());
        }
        for (Player p : others) targets.add(p.getUniqueId().toString());

        int index = targets.indexOf(getCompassTarget(compass));
        String next = targets.get((index + 1) % targets.size());

        ItemMeta meta = compass.getItemMeta();
        meta.getPersistentDataContainer().set(targetKey, PersistentDataType.STRING, next);
        compass.setItemMeta(meta);
        user.getInventory().setItemInMainHand(compass);

        user.sendActionBar(Component.text("Target: " + targetName(next), NamedTextColor.LIGHT_PURPLE));
        user.playSound(user.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.2f);
    }

    /** Right-click: teleport to the selected target. */
    private void useCompassTarget(Player user, ItemStack compass) {
        String target = getCompassTarget(compass);

        if (target.equals("realm")) {
            enterNullRealm(user, false); // the Null Compass does NOT bring it back
            return;
        }

        if (target.startsWith(WORLD_TARGET_PREFIX)) {
            World w = getServer().getWorld(target.substring(WORLD_TARGET_PREFIX.length()));
            if (w == null) {
                user.sendMessage(Component.text("That dimension isn't loaded. Shift + right-click to pick another target.",
                        NamedTextColor.RED));
                return;
            }
            // Load the chunks around the spawn without freezing the server, then teleport
            Location spawn = w.getSpawnLocation();
            int cx = spawn.getBlockX() >> 4;
            int cz = spawn.getBlockZ() >> 4;
            List<java.util.concurrent.CompletableFuture<?>> loads = new ArrayList<>();
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) loads.add(w.getChunkAtAsync(cx + dx, cz + dz));
            }
            java.util.concurrent.CompletableFuture.allOf(loads.toArray(new java.util.concurrent.CompletableFuture[0]))
                    .thenRun(() -> getServer().getScheduler().runTask(this, () -> {
                        if (!user.isOnline()) return;
                        user.teleportAsync(safeArrival(w)).thenAccept(ok -> getServer().getScheduler().runTask(this, () -> {
                            if (!ok || !user.isOnline()) return;
                            user.playSound(user.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 0.6f, 0.5f);
                            user.sendMessage(Component.text("Teleported to " + worldLabel(w) + ".",
                                    NamedTextColor.DARK_PURPLE));
                        }));
                    }));
            return;
        }

        Player other;
        try {
            other = getServer().getPlayer(UUID.fromString(target));
        } catch (IllegalArgumentException e) {
            other = null;
        }
        if (other == null || !other.isOnline()) {
            user.sendMessage(Component.text("That player isn't online. Shift + right-click to pick another target.",
                    NamedTextColor.RED));
            return;
        }

        user.teleport(other.getLocation());
        user.playSound(user.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 0.6f, 0.5f);
        user.sendMessage(Component.text("Teleported to " + other.getName() + ".", NamedTextColor.DARK_PURPLE));
    }

    // ---- /setcommandblock: choose where the command block goes ----

    private boolean setCommandBlockLocation(CommandSender sender, String[] args) {
        int x = 0, y = 0, z = 0;
        World target;

        if (args.length == 0) {
            // No numbers given: use the block you're standing in
            if (!(sender instanceof Player player)) {
                sender.sendMessage("§cFrom the console use: /setcommandblock <x> <y> <z>");
                return true;
            }
            Location here = player.getLocation();
            x = here.getBlockX();
            y = here.getBlockY();
            z = here.getBlockZ();
            target = player.getWorld();
        } else if (args.length == 3) {
            try {
                x = Integer.parseInt(args[0]);
                y = Integer.parseInt(args[1]);
                z = Integer.parseInt(args[2]);
            } catch (NumberFormatException e) {
                sender.sendMessage("§cUse whole numbers: /setcommandblock <x> <y> <z>");
                return true;
            }
            target = (sender instanceof Player other) ? other.getWorld() : getServer().getWorlds().get(0);
        } else {
            sender.sendMessage("§cUse: /setcommandblock  (your position)  or  /setcommandblock <x> <y> <z>");
            return true;
        }

        if (y < target.getMinHeight() || y >= target.getMaxHeight()) {
            sender.sendMessage("§cY=" + y + " is outside this world's build limits ("
                    + target.getMinHeight() + " to " + (target.getMaxHeight() - 1) + ").");
            return true;
        }

        blockX = x;
        blockY = y;
        blockZ = z;
        blockWorldName = target.getName();

        getConfig().set("command-block.x", x);
        getConfig().set("command-block.y", y);
        getConfig().set("command-block.z", z);
        getConfig().set("command-block.world", target.getName());
        saveConfig();

        sender.sendMessage("§aCommand block location set to " + x + " " + y + " " + z + " in " + target.getName() + ".");
        sender.sendMessage("§7Run /commandblockmacestart to place it there.");
        return true;
    }

    // ---- Command Block Trident: two modes, Riptide and Throw ----

    /** /giveweapons: the Command Block Mace and the Command Block Trident. */
    /** Name of the scoreboard tag that /link toggles. It works with vanilla selectors like @a[tag=linked]. */
    private static final String LINK_TAG = "linked";

    /** True if a command block, a command block minecart, or /execute from one is running the command. */
    private boolean isFromCommandBlock(CommandSender sender) {
        if (sender instanceof org.bukkit.command.ProxiedCommandSender proxied) {
            return isFromCommandBlock(proxied.getCaller()) || isFromCommandBlock(proxied.getCallee());
        }
        return sender instanceof org.bukkit.command.BlockCommandSender
                || sender instanceof org.bukkit.entity.minecart.CommandMinecart;
    }

    /** /link <players or selector>: tags players as linked, and takes the tag off the ones that already have it. */
    private boolean linkCommand(CommandSender sender, String[] args) {
        if (isFromCommandBlock(sender)) {
            // Command blocks can never run this one
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(Component.text("Usage: /link <player|@a|@p|@r|@a[...]> [army]", NamedTextColor.RED));
            return true;
        }

        List<Player> targets = new ArrayList<>();
        try {
            for (org.bukkit.entity.Entity e : getServer().selectEntities(sender, args[0])) {
                if (e instanceof Player p) targets.add(p);
            }
        } catch (IllegalArgumentException ex) {
            Player byName = getServer().getPlayerExact(args[0]);
            if (byName != null) {
                targets.add(byName);
            } else {
                sender.sendMessage(Component.text("No player found for '" + args[0] + "'.", NamedTextColor.RED));
                return true;
            }
        }
        if (targets.isEmpty()) {
            sender.sendMessage(Component.text("No players matched.", NamedTextColor.RED));
            return true;
        }

        // Optional army name: each Ender Pearl Cannon rod can belong to its own army
        String linkTagName = EnderPearlCannon.linkTag(args.length >= 2 ? args[1] : "");
        int linked = 0;
        int unlinked = 0;
        for (Player p : targets) {
            if (p.getScoreboardTags().contains(linkTagName)) {
                p.removeScoreboardTag(linkTagName);
                unlinked++;
                p.sendMessage(Component.text("You are no longer linked.", NamedTextColor.GRAY));
            } else {
                p.addScoreboardTag(linkTagName);
                linked++;
                p.sendMessage(Component.text("You are now linked.", NamedTextColor.LIGHT_PURPLE));
            }
        }
        sender.sendMessage(Component.text("Linked " + linked + " player(s), unlinked " + unlinked + ".",
                NamedTextColor.LIGHT_PURPLE));
        return true;
    }

    private void giveBook(Player player) {
        var leftovers = player.getInventory().addItem(book.createBook());
        leftovers.values().forEach(i -> player.getWorld().dropItemNaturally(player.getLocation(), i));
        player.sendMessage(Component.text("You received the Book o' Knowledge!", NamedTextColor.LIGHT_PURPLE));
    }

    private boolean giveWeapons(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only a player can use /giveweapons.");
            return true;
        }
        var leftovers = player.getInventory().addItem(createCommandBlockMace(), createCommandBlockTrident(), createStickOfSealing());
        leftovers.values().forEach(i -> player.getWorld().dropItemNaturally(player.getLocation(), i));
        player.sendMessage(Component.text("You received the Command Block Mace, the Command Block Trident and the Stick of Sealing!",
                NamedTextColor.GOLD));
        return true;
    }

    /** /leavenullrealm: back to your bed (or the main world's spawn). */
    private boolean leaveNullRealm(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only a player can use /leavenullrealm.");
            return true;
        }
        if (isSealed(player)) {
            player.sendMessage(Component.text("You are sealed. You can't leave until you're unsealed.",
                    NamedTextColor.DARK_RED));
            return true;
        }
        if (!player.getWorld().getName().equals(NULL_REALM_NAME)) {
            player.sendMessage(Component.text("You're not in the Null Realm.", NamedTextColor.RED));
            return true;
        }
        Location back = player.getRespawnLocation();
        if (back == null || back.getWorld() == null || back.getWorld().getName().equals(NULL_REALM_NAME)) {
            back = getServer().getWorlds().get(0).getSpawnLocation();
        }
        player.teleport(back);
        player.playSound(player.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 0.6f, 1.2f);
        player.sendMessage(Component.text("You leave the Null Realm.", NamedTextColor.DARK_GRAY));
        return true;
    }

    private boolean giveTrident(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only a player can use /givetrident.");
            return true;
        }
        var leftovers = player.getInventory().addItem(createCommandBlockTrident());
        leftovers.values().forEach(i -> player.getWorld().dropItemNaturally(player.getLocation(), i));
        player.sendMessage(Component.text("You received the Command Block Trident!", NamedTextColor.AQUA));
        return true;
    }

    private ItemStack createCommandBlockTrident() {
        ItemStack trident = new ItemStack(Material.TRIDENT);
        ItemMeta meta = trident.getItemMeta();
        meta.displayName(Component.text("Command Block Trident", NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Right-click: use the current mode", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Shift + right-click: switch mode", NamedTextColor.LIGHT_PURPLE)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.addEnchant(Enchantment.LOYALTY, 3, true); // a thrown trident flies back to you
        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(tridentKey, PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(tridentModeKey, PersistentDataType.INTEGER,
                TridentMode.RIPTIDE.ordinal());
        trident.setItemMeta(meta);
        return trident;
    }

    private boolean isCommandBlockTrident(ItemStack stack) {
        if (stack == null || stack.getType() != Material.TRIDENT || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(tridentKey, PersistentDataType.BYTE);
    }

    private TridentMode getTridentMode(ItemStack trident) {
        int index = trident.getItemMeta().getPersistentDataContainer()
                .getOrDefault(tridentModeKey, PersistentDataType.INTEGER, 0);
        TridentMode[] all = TridentMode.values();
        return all[Math.floorMod(index, all.length)];
    }

    private void switchTridentMode(Player player, ItemStack trident) {
        TridentMode[] all = TridentMode.values();
        TridentMode next = all[(getTridentMode(trident).ordinal() + 1) % all.length];

        ItemMeta meta = trident.getItemMeta();
        meta.getPersistentDataContainer().set(tridentModeKey, PersistentDataType.INTEGER, next.ordinal());
        trident.setItemMeta(meta);
        player.getInventory().setItemInMainHand(trident);

        player.sendActionBar(Component.text("Mode: " + next.displayName, next.color));
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.2f);
    }

    @EventHandler
    public void onTridentClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack trident = player.getInventory().getItemInMainHand();
        if (!isCommandBlockTrident(trident)) return;

        if (player.isSneaking()) {
            event.setUseItemInHand(Event.Result.DENY); // switching modes never throws it
            switchTridentMode(player, trident);
        } else {
            switch (getTridentMode(trident)) {
                case RIPTIDE -> {
                    event.setUseItemInHand(Event.Result.DENY); // dash instead of charging a throw
                    riptideDash(player);
                }
                case SUPER_CHARGE -> {
                    event.setUseItemInHand(Event.Result.DENY);
                    superCharge(player, trident);
                }
                case THROW -> { } // works like a normal trident (hold to charge, release to throw)
            }
        }
    }

    /** Safety net: the trident can only be thrown in Throw mode. */
    @EventHandler(ignoreCancelled = true)
    public void onTridentLaunch(ProjectileLaunchEvent event) {
        if (!(event.getEntity() instanceof Trident)) return;
        if (!(event.getEntity().getShooter() instanceof Player player)) return;
        ItemStack held = player.getInventory().getItemInMainHand();
        if (!isCommandBlockTrident(held)) return;
        if (getTridentMode(held) != TridentMode.THROW) {
            event.setCancelled(true);
            return;
        }

        // Throw mode: send out extra tridents next to the real one (3, or 10 while Super Charge is on)
        Trident main = (Trident) event.getEntity();
        if (extraTridents.contains(main.getUniqueId())) return;
        int extras = (isCharged(player.getUniqueId()) ? THROW_COUNT_CHARGED : THROW_COUNT) - 1;
        Location origin = main.getLocation();
        Vector velocity = main.getVelocity();
        ItemStack copy = main.getItemStack().clone();

        getServer().getScheduler().runTask(this, () -> {
            Random random = new Random();
            for (int i = 0; i < extras; i++) {
                Vector spread = new Vector(random.nextGaussian(), random.nextGaussian(), random.nextGaussian())
                        .multiply(THROW_SPREAD);
                Vector v = velocity.clone().add(spread);
                origin.getWorld().spawn(origin, Trident.class, extra -> {
                    extraTridents.add(extra.getUniqueId());
                    extra.setShooter(player);
                    extra.setItemStack(copy.clone());
                    extra.setPickupStatus(AbstractArrow.PickupStatus.CREATIVE_ONLY);
                    extra.setVelocity(v);
                });
            }
        });
    }

    /** Riptide mode: dash forward in the direction you're looking (works anywhere, no water needed). */
    /** Extra damage from falling, the same as a vanilla mace: 4 per block for 3 blocks, then 2, then 1. */
    private double smashBonus(double fall) {
        if (fall < MIN_SMASH_FALL) return 0;
        double bonus = 4.0 * Math.min(fall, 3.0);
        if (fall > 3.0) bonus += 2.0 * Math.min(fall - 3.0, 5.0);
        if (fall > 8.0) bonus += fall - 8.0;
        return bonus;
    }

    /** True if it is raining (or storming) and nothing is above the player to shelter them. */
    private boolean isInRain(Player player) {
        World w = player.getWorld();
        if (!w.hasStorm()) return false;
        Location l = player.getLocation();
        return l.getBlockY() >= w.getHighestBlockYAt(l);
    }

    private void riptideDash(Player player) {
        UUID id = player.getUniqueId();
        long now = System.currentTimeMillis();
        Long last = lastRiptide.get(id);
        if (last != null && now - last < RIPTIDE_COOLDOWN_MS) return;
        lastRiptide.put(id, now);

        // How far you were falling when you started the dash (used for the mace-style smash below)
        final double fallAtStart = player.getFallDistance();

        // Water or rain makes the dash stronger (water wins if both apply)
        final boolean inRain = !player.isInWater() && isInRain(player);
        double speed = RIPTIDE_SPEED;
        if (player.isInWater()) speed *= RIPTIDE_WATER_MULTIPLIER;
        else if (inRain) speed *= RIPTIDE_RAIN_MULTIPLIER;

        // Gliding with an Elytra: the dash stacks on top of the speed you already have
        final boolean gliding = player.isGliding();
        final Vector lookDirection = player.getEyeLocation().getDirection().normalize();
        Vector velocity;
        if (gliding) {
            velocity = player.getVelocity().add(lookDirection.clone().multiply(speed));
            if (velocity.length() > RIPTIDE_ELYTRA_MAX_SPEED) {
                velocity.normalize().multiply(RIPTIDE_ELYTRA_MAX_SPEED);
            }
        } else {
            velocity = lookDirection.clone().multiply(speed);
            if (player.isOnGround() && !player.isInWater() && velocity.getY() < 0.3) {
                velocity.setY(0.3); // small hop so ground friction doesn't eat the dash
            }
        }
        player.setVelocity(velocity);
        if (inRain) {
            player.sendActionBar(Component.text("Rain boost!", NamedTextColor.AQUA));
        }
        player.setFallDistance(0f); // the dash never gives you fall damage
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_TRIDENT_RIPTIDE_3, 1.0f, 1.0f);
        final Vector dashDirection = gliding ? lookDirection.clone() : velocity.clone().normalize();
        final double dashSpeed = gliding ? speed : velocity.length();

        Particle.DustOptions blue = new Particle.DustOptions(Color.fromRGB(40, 140, 255), 1.4f);
        Set<UUID> alreadyHit = new HashSet<>();
        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead() || ticks >= RIPTIDE_DASH_TICKS) {
                    if (player.isOnline()) player.setFallDistance(0f);
                    cancel();
                    return;
                }

                // Keep pushing you along the dash line, fading out, so the dash stays fast and smooth
                if (ticks > 0 && ticks < RIPTIDE_THRUST_TICKS) {
                    double fade = 1.0 - (double) ticks / RIPTIDE_THRUST_TICKS * 0.5;
                    if (gliding && player.isGliding()) {
                        // Keep adding to the glide instead of replacing it, up to the speed cap
                        Vector boosted = player.getVelocity()
                                .add(dashDirection.clone().multiply(dashSpeed * RIPTIDE_ELYTRA_THRUST * fade));
                        if (boosted.length() > RIPTIDE_ELYTRA_MAX_SPEED) {
                            boosted.normalize().multiply(RIPTIDE_ELYTRA_MAX_SPEED);
                        }
                        player.setVelocity(boosted);
                    } else {
                        player.setVelocity(dashDirection.clone().multiply(dashSpeed * fade));
                    }
                }
                ticks++;

                Location loc = player.getLocation().add(0, 1, 0);
                World w = player.getWorld();
                w.spawnParticle(Particle.SPLASH, loc, 16, 0.5, 0.5, 0.5, 0.1);
                w.spawnParticle(Particle.BUBBLE_POP, loc, 6, 0.4, 0.4, 0.4, 0.02);
                w.spawnParticle(Particle.DUST, loc, 12, 0.5, 0.5, 0.5, 0, blue);

                // Anything you slam into takes damage and is knocked forward, once per dash
                for (var nearby : player.getNearbyEntities(RIPTIDE_HIT_RANGE, RIPTIDE_HIT_RANGE, RIPTIDE_HIT_RANGE)) {
                    if (!(nearby instanceof LivingEntity target)) continue;
                    if (target.isDead() || !alreadyHit.add(target.getUniqueId())) continue;
                    // Like a mace: the longer you were falling, the harder the hit (and it makes a shockwave)
                    double bonus = smashBonus(fallAtStart + player.getFallDistance());
                    double base = RIPTIDE_DAMAGE + bonus;
                    double damage = isCharged(id) ? base * SUPER_CHARGE_MULTIPLIER : base;
                    target.damage(damage, player);
                    target.setVelocity(dashDirection.clone().multiply(RIPTIDE_KNOCKBACK).setY(0.35));
                    w.playSound(target.getLocation(), Sound.ITEM_TRIDENT_HIT, 1.0f, 1.0f);
                    if (bonus > 0) {
                        w.playSound(target.getLocation(), Sound.ITEM_MACE_SMASH_GROUND, 1.0f, 1.0f);
                        shockwave(player, target.getLocation());
                    }
                    strikeFor(player, target.getLocation());
                }
            }
        }.runTaskTimer(CommandBlockSpawner.this, 0L, 1L);
    }

    // ---- Lightning ----

    /** Strikes a real lightning bolt that belongs to the player (it never hurts them). */
    private void strikeFor(Player owner, Location where) {
        LightningStrike bolt = where.getWorld().strikeLightning(where);
        UUID boltId = bolt.getUniqueId();
        lightningOwner.put(boltId, owner.getUniqueId());
        getServer().getScheduler().runTaskLater(this, () -> lightningOwner.remove(boltId), 100L);

        // Lightning sets things on fire; keep that off the player if they're close to the bolt
        if (owner.getWorld().equals(where.getWorld()) && owner.getLocation().distanceSquared(where) < 36) {
            for (long delay : new long[]{1L, 3L, 6L}) {
                getServer().getScheduler().runTaskLater(this, () -> {
                    if (owner.isOnline()) owner.setFireTicks(0);
                }, delay);
            }
        }
    }

    /** A thrown trident that hits something calls down lightning on that spot. */
    @EventHandler
    public void onTridentHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Trident thrown)) return;
        if (!(thrown.getShooter() instanceof Player shooter)) return;
        if (!isCommandBlockTrident(thrown.getItemStack())) return;

        Location where;
        if (event.getHitEntity() != null) {
            where = event.getHitEntity().getLocation();
        } else if (event.getHitBlock() != null) {
            where = event.getHitBlock().getLocation().add(0.5, 1, 0.5);
        } else {
            where = thrown.getLocation();
        }
        strikeFor(shooter, where);

        // Extra tridents from a multi-throw disappear after they hit (a moment later so the hit still counts)
        if (extraTridents.remove(thrown.getUniqueId())) {
            getServer().getScheduler().runTaskLater(this, thrown::remove, 2L);
        }
    }

    /** Lightning never hurts its owner, and everything is x3 while Super Charge is on. */
    @EventHandler(ignoreCancelled = true)
    public void onTridentDamage(EntityDamageByEntityEvent event) {
        Entity damager = event.getDamager();

        if (damager instanceof LightningStrike bolt) {
            UUID ownerId = lightningOwner.get(bolt.getUniqueId());
            if (ownerId == null) return;
            if (event.getEntity().getUniqueId().equals(ownerId)) {
                event.setCancelled(true);
                return;
            }
            if (isCharged(ownerId)) {
                event.setDamage(event.getDamage() * SUPER_CHARGE_MULTIPLIER);
            }
            return;
        }

        if (damager instanceof Trident thrown
                && thrown.getShooter() instanceof Player shooter
                && isCommandBlockTrident(thrown.getItemStack())
                && isCharged(shooter.getUniqueId())) {
            event.setDamage(event.getDamage() * SUPER_CHARGE_MULTIPLIER);
        }
    }

    // ---- Super Charge: a lightning storm, and every move does x3 damage ----

    private boolean isCharged(UUID id) {
        Long until = chargedUntil.get(id);
        return until != null && System.currentTimeMillis() < until;
    }

    private void superCharge(Player player, ItemStack trident) {
        UUID id = player.getUniqueId();
        long now = System.currentTimeMillis();

        Long cooldownEnd = superChargeCooldownEnd.get(id);
        if (cooldownEnd != null && now < cooldownEnd) {
            long secondsLeft = (cooldownEnd - now + 999) / 1000;
            player.sendActionBar(Component.text("Super Charge recharging: " + secondsLeft + "s", NamedTextColor.RED));
            return;
        }
        superChargeCooldownEnd.put(id, now + SUPER_CHARGE_COOLDOWN_MS);
        chargedUntil.put(id, now + SUPER_CHARGE_TICKS * 50L);

        // Go back to Riptide so you can fight right away
        ItemMeta meta = trident.getItemMeta();
        meta.getPersistentDataContainer().set(tridentModeKey, PersistentDataType.INTEGER,
                TridentMode.RIPTIDE.ordinal());
        trident.setItemMeta(meta);
        player.getInventory().setItemInMainHand(trident);

        // Summon the storm
        World world = player.getWorld();
        world.setStorm(true);
        world.setThundering(true);
        world.setWeatherDuration(SUPER_CHARGE_TICKS);
        world.setThunderDuration(SUPER_CHARGE_TICKS);
        world.playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 0.8f);
        player.sendMessage(Component.text("SUPER CHARGE! All moves do x"
                + (int) SUPER_CHARGE_MULTIPLIER + " damage for "
                + (SUPER_CHARGE_TICKS / 20) + " seconds.", NamedTextColor.GOLD));

        Random random = new Random();
        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead() || ticks >= SUPER_CHARGE_TICKS) {
                    chargedUntil.remove(id);
                    if (player.isOnline()) {
                        player.sendActionBar(Component.text("Super Charge ended", NamedTextColor.GRAY));
                    }
                    cancel();
                    return;
                }
                ticks += STORM_STRIKE_INTERVAL;

                double angle = random.nextDouble() * 2 * Math.PI;
                double distance = STORM_MIN_DISTANCE
                        + random.nextDouble() * (STORM_MAX_DISTANCE - STORM_MIN_DISTANCE);
                Location base = player.getLocation();
                int x = (int) Math.floor(base.getX() + Math.cos(angle) * distance);
                int z = (int) Math.floor(base.getZ() + Math.sin(angle) * distance);
                Location strike = new Location(base.getWorld(), x + 0.5,
                        base.getWorld().getHighestBlockYAt(x, z) + 1, z + 0.5);
                strikeFor(player, strike);
                player.sendActionBar(Component.text("Super Charge: "
                        + Math.max(0, (SUPER_CHARGE_TICKS - ticks) / 20) + "s left", NamedTextColor.GOLD));
            }
        }.runTaskTimer(this, 0L, STORM_STRIKE_INTERVAL);
    }

    // ---- The Stick of Sealing: seal one player, then unseal them to where you are ----

    private ItemStack createStickOfSealing() {
        ItemStack stick = new ItemStack(Material.STICK);
        ItemMeta meta = stick.getItemMeta();
        meta.displayName(Component.text("Stick of Sealing", NamedTextColor.DARK_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        setStickLore(meta, null);
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(stickKey, PersistentDataType.BYTE, (byte) 1);
        stick.setItemMeta(meta);
        return stick;
    }

    private boolean isStickOfSealing(ItemStack stack) {
        if (stack == null || stack.getType() != Material.STICK || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(stickKey, PersistentDataType.BYTE);
    }

    /** The lore shows what the stick will do next, and who is currently sealed. */
    private void setStickLore(ItemMeta meta, String sealedName) {
        List<Component> lore = new ArrayList<>();
        if (sealedName == null) {
            lore.add(Component.text("Right-click a player to seal them", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        } else {
            lore.add(Component.text("Right-click to unseal them to where you are", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Sealed: " + sealedName, NamedTextColor.DARK_RED)
                    .decoration(TextDecoration.ITALIC, false));
        }
        lore.add(Component.text("Only one player can be sealed at a time", NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
    }

    private boolean isSealed(Player player) {
        return player.getPersistentDataContainer().has(sealedKey, PersistentDataType.BYTE);
    }

    /** Teleports a player in or out of a seal (the plugin's own teleports are allowed through). */
    private void sealTeleport(Player player, Location destination) {
        sealTeleportAllowed.add(player.getUniqueId());
        try {
            player.teleport(destination);
        } finally {
            sealTeleportAllowed.remove(player.getUniqueId());
        }
    }

    @EventHandler
    public void onStickUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player user = event.getPlayer();
        ItemStack stick = user.getInventory().getItemInMainHand();
        if (!isStickOfSealing(stick)) return;

        // One click can fire the event twice, so ignore a second click right after the first
        long now = System.currentTimeMillis();
        Long last = lastStickUse.get(user.getUniqueId());
        if (last != null && now - last < 400) return;
        lastStickUse.put(user.getUniqueId(), now);

        String targetId = stick.getItemMeta().getPersistentDataContainer()
                .get(stickTargetKey, PersistentDataType.STRING);
        if (targetId == null) {
            sealPlayer(user, stick);
        } else {
            unsealPlayer(user, stick, targetId);
        }
    }

    /** Move 1: seal the player you're aiming at. */
    private void sealPlayer(Player user, ItemStack stick) {
        World world = user.getWorld();
        Location eye = user.getEyeLocation();
        RayTraceResult hit = world.rayTrace(
                eye, eye.getDirection(), SEAL_RANGE, FluidCollisionMode.NEVER, true, 0.5,
                entity -> entity instanceof Player other && !other.equals(user));

        if (hit == null || !(hit.getHitEntity() instanceof Player target)) {
            user.sendActionBar(Component.text("Aim at a player to seal them.", NamedTextColor.RED));
            return;
        }
        if (isSealed(target)) {
            user.sendActionBar(Component.text(target.getName() + " is already sealed.", NamedTextColor.RED));
            return;
        }

        World realm = getNullRealm();
        if (realm == null) {
            user.sendMessage(Component.text("The seal fizzles... the sealing cell could not be opened.",
                    NamedTextColor.RED));
            return;
        }
        buildSealCell(realm);

        // Effects where they were standing
        Location was = target.getLocation().add(0, 1, 0);
        world.spawnParticle(Particle.DUST, was, 60, 0.5, 0.8, 0.5, 0,
                new Particle.DustOptions(Color.fromRGB(90, 0, 160), 1.8f));
        world.playSound(was, Sound.BLOCK_BEACON_DEACTIVATE, 1.0f, 0.5f);

        target.getPersistentDataContainer().set(sealedKey, PersistentDataType.BYTE, (byte) 1);
        sealTeleport(target, sealCellSpawn(realm));

        ItemMeta meta = stick.getItemMeta();
        meta.getPersistentDataContainer().set(stickTargetKey, PersistentDataType.STRING,
                target.getUniqueId().toString());
        setStickLore(meta, target.getName());
        stick.setItemMeta(meta);
        user.getInventory().setItemInMainHand(stick);

        user.sendMessage(Component.text("You sealed " + target.getName()
                + ". Right-click again to unseal them to where you are.", NamedTextColor.DARK_PURPLE));
        target.sendMessage(Component.text("You have been sealed by " + user.getName() + ".",
                NamedTextColor.DARK_RED));
    }

    /** Move 2: unseal the sealed player, bringing them to where you are. */
    private void unsealPlayer(Player user, ItemStack stick, String targetId) {
        UUID id = UUID.fromString(targetId);
        Player target = getServer().getPlayer(id);

        if (target == null || !target.isOnline()) {
            String name = getServer().getOfflinePlayer(id).getName();
            user.sendMessage(Component.text((name != null ? name : "The sealed player")
                    + " is offline. They stay sealed until they come back.", NamedTextColor.RED));
            return;
        }

        if (isSealed(target)) {
            Location here = user.getLocation();
            target.getPersistentDataContainer().remove(sealedKey);
            sealTeleport(target, here);

            World world = user.getWorld();
            world.spawnParticle(Particle.DUST, here.clone().add(0, 1, 0), 60, 0.5, 0.8, 0.5, 0,
                    new Particle.DustOptions(Color.fromRGB(90, 0, 160), 1.8f));
            world.playSound(here, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.2f);

            user.sendMessage(Component.text("You unsealed " + target.getName() + " to where you are.",
                    NamedTextColor.DARK_PURPLE));
            target.sendMessage(Component.text("You have been unsealed by " + user.getName() + ".",
                    NamedTextColor.GREEN));
        } else {
            user.sendMessage(Component.text("That seal was already broken. You can seal someone new.",
                    NamedTextColor.GRAY));
        }

        // The stick is free again
        ItemMeta meta = stick.getItemMeta();
        meta.getPersistentDataContainer().remove(stickTargetKey);
        setStickLore(meta, null);
        stick.setItemMeta(meta);
        user.getInventory().setItemInMainHand(stick);
    }

    // The sealing cell: a 3x3x3 room in the Null Realm with a bedrock floor, walls and ceiling

    private Location sealCellSpawn(World realm) {
        return new Location(realm, SEAL_CELL_X + 1.5, SEAL_CELL_Y, SEAL_CELL_Z + 1.5);
    }

    /**
     * Builds the sealing cell, and repairs it if anything is missing. The whole cell is bedrock
     * (floor, walls and ceiling) with a 3x3x3 room of air inside.
     */
    private void buildSealCell(World realm) {
        for (int x = SEAL_CELL_X - 1; x <= SEAL_CELL_X + 3; x++) {
            for (int y = SEAL_CELL_Y - 1; y <= SEAL_CELL_Y + 3; y++) {
                for (int z = SEAL_CELL_Z - 1; z <= SEAL_CELL_Z + 3; z++) {
                    boolean shell = x == SEAL_CELL_X - 1 || x == SEAL_CELL_X + 3
                            || z == SEAL_CELL_Z - 1 || z == SEAL_CELL_Z + 3
                            || y == SEAL_CELL_Y - 1 || y == SEAL_CELL_Y + 3;
                    Material wanted = shell ? Material.BEDROCK : Material.AIR;
                    Block block = realm.getBlockAt(x, y, z);
                    if (block.getType() != wanted) block.setType(wanted, false);
                }
            }
        }
    }

    /** The seal regenerates: while anyone is sealed, the cell is checked every 2 seconds and rebuilt. */
    private void startSealRegen() {
        new BukkitRunnable() {
            @Override
            public void run() {
                World realm = getServer().getWorld(NULL_REALM_NAME);
                if (realm == null) return;
                for (Player p : getServer().getOnlinePlayers()) {
                    if (isSealed(p)) {
                        buildSealCell(realm);
                        return;
                    }
                }
            }
        }.runTaskTimer(this, 100L, 40L);
    }

    // A sealed player can't teleport out, and comes back to the cell if they respawn or log in elsewhere

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onSealedTeleport(PlayerTeleportEvent event) {
        Player player = event.getPlayer();
        if (!isSealed(player) || sealTeleportAllowed.contains(player.getUniqueId())) return;
        event.setCancelled(true);
        player.sendActionBar(Component.text("You are sealed.", NamedTextColor.DARK_RED));
    }

    @EventHandler
    public void onSealedRespawn(PlayerRespawnEvent event) {
        if (!isSealed(event.getPlayer())) return;
        World realm = getNullRealm();
        if (realm == null) return;
        buildSealCell(realm);
        event.setRespawnLocation(sealCellSpawn(realm));
    }

    @EventHandler
    public void onSealedJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (!isSealed(player) || player.getWorld().getName().equals(NULL_REALM_NAME)) return;
        World realm = getNullRealm();
        if (realm == null) return;
        buildSealCell(realm);
        sealTeleport(player, sealCellSpawn(realm));
    }

    /** /unseal <player>: frees a sealed player (for example if the stick was lost). */
    private boolean unsealCommand(CommandSender sender, String[] args) {
        if (args.length != 1) {
            sender.sendMessage("§cUse: /unseal <player>");
            return true;
        }
        Player target = getServer().getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage("§cThat player isn't online.");
            return true;
        }
        if (!isSealed(target)) {
            sender.sendMessage("§e" + target.getName() + " isn't sealed.");
            return true;
        }
        target.getPersistentDataContainer().remove(sealedKey);
        sealTeleport(target, getServer().getWorlds().get(0).getSpawnLocation());
        target.sendMessage(Component.text("You have been unsealed.", NamedTextColor.GREEN));
        sender.sendMessage("§aUnsealed " + target.getName() + " and sent them to the main world's spawn.");
        return true;
    }
}
