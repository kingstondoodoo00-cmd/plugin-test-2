package com.example.cbspawner;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.BlockCommandSender;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ProxiedCommandSender;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.minecart.CommandMinecart;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The Arrow Cannon (like the arrow cannons / railguns on the SMP): a fishing rod that works the same way as the
 * Ender Pearl Cannon. Cast it, then reel in (unhook) while pointing at something: a volley of extremely fast
 * arrows covers a 20-block area around that spot, falling from 20 blocks above the ground. Every player in the
 * area gets arrows aimed straight at them, so it hits everyone, you included. To protect yourself, put a block
 * over your head first and fire at your own feet. It does not use /link.
 * The rod breaks after one use.
 *
 * Arrows do more damage the faster they fly, and these fly very fast; the volley comes in rapid waves and each
 * arrow ignores the target's hit-immunity, so they land as several quick hits.
 *
 * Get it with  /give:arrowcannon [player]  (or /give <player> arrowcannon) from chat or the console.
 * Command blocks cannot give it.
 */
public class ArrowCannon implements Listener {

    private static final String ITEM_ID = "arrowcannon";
    private static final String DOMAIN_WORLD_NAME = "black_domain";

    private static final Material CANNON_MATERIAL = Material.FISHING_ROD;
    /** Shows as "Durability: 8 / 64" so it can be told apart from the Ender Pearl Cannon (4 / 64). */
    private static final int MAX_DURABILITY = 64;
    private static final int DURABILITY_LEFT = 8;

    private static final double RANGE = 150.0;
    private static final double SPAWN_HEIGHT = 20.0;
    /** How many blocks apart the shooters' arrows land from each other. */
    private static final double SPACING = 2.0;
    /** The volley: this many waves, a couple of ticks apart, one arrow per shooter in each wave. */
    private static final int WAVES = 8;
    /** Arrows each shooter sends per wave, scattered around their landing spot, so the ground fills with arrows. */
    private static final int ARROWS_PER_WAVE = 75;
    /** One arrow in every 4 lands tightly on the target (so it takes the hits); the rest cover the battlefield. */
    private static final double ARROW_SCATTER_TIGHT = 2.5;
    /** The arrows cover a circle of this radius around the target, evenly spread, like a carpet over the battlefield. */
    private static final double COVER_RADIUS = 20.0;
    /** Every player inside that circle gets this many arrows aimed straight down on them in each wave. */
    private static final int ARROWS_PER_PLAYER_WAVE = 3;
    /** 0 = every wave comes out in the same tick, so all the arrows leave together and land together. */
    private static final int TICKS_BETWEEN_WAVES = 0;
    /** Arrow speed in blocks per tick (a normal full bow shot is about 3). Damage grows with speed. */
    private static final double ARROW_SPEED = 14.0;
    /** Base arrow damage: the arrow hits for about speed x this, before armor. */
    private static final double ARROW_BASE_DAMAGE = 5.0;
    /** The arrows stay stuck in the ground for this long (30 seconds). */
    private static final int ARROW_LIFETIME_TICKS = 600;
    private static final int MAX_GIVE = 36;
    /** Every arrow that hits a player wears down EACH armor piece by this share of its max durability (0.04 = 4%). */
    private static final double ARMOR_DAMAGE_FRACTION = 0.04;
    /** One volley can wear each armor piece down by at most this much of its full durability. */
    private static final double ARMOR_MAX_PER_VOLLEY = 0.3;
    /** Hits within this many milliseconds of each other count as the same volley. */
    private static final long VOLLEY_WINDOW_MS = 15000L;
    private final java.util.Map<java.util.UUID, long[]> armorWear = new java.util.HashMap<>();

    private final Random random = new Random();
    private final JavaPlugin plugin;
    private final NamespacedKey cannonKey;
    private final NamespacedKey arrowKey;

    public ArrowCannon(JavaPlugin plugin) {
        this.plugin = plugin;
        this.cannonKey = new NamespacedKey(plugin, "arrow_cannon");
        this.arrowKey = new NamespacedKey(plugin, "cannon_arrow");
    }

    // ---- The item ----

    public ItemStack createCannon() {
        // A plain-looking fishing rod: only a hidden tag and the durability (8 left of 64) mark it
        ItemStack item = new ItemStack(CANNON_MATERIAL);
        ItemMeta meta = item.getItemMeta();
        if (meta instanceof Damageable damageable) {
            damageable.setMaxDamage(MAX_DURABILITY);
            damageable.setDamage(MAX_DURABILITY - DURABILITY_LEFT);
        }
        meta.getPersistentDataContainer().set(cannonKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isCannon(ItemStack stack) {
        if (stack == null || stack.getType() != CANNON_MATERIAL || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(cannonKey, PersistentDataType.BYTE);
    }

    // ---- Reeling in (unhooking) ----

    @EventHandler
    public void onFish(PlayerFishEvent event) {
        PlayerFishEvent.State state = event.getState();
        if (state != PlayerFishEvent.State.REEL_IN && state != PlayerFishEvent.State.IN_GROUND
                && state != PlayerFishEvent.State.CAUGHT_ENTITY && state != PlayerFishEvent.State.CAUGHT_FISH
                && state != PlayerFishEvent.State.FAILED_ATTEMPT) {
            return;
        }
        Player player = event.getPlayer();
        EquipmentSlot hand = event.getHand();
        if (hand == null) return;
        ItemStack rod = player.getInventory().getItem(hand);
        if (!isCannon(rod)) return;

        // The cannon never catches anything: it just fires
        event.setCancelled(true);
        event.getHook().remove();

        RayTraceResult hit = player.getWorld().rayTrace(player.getEyeLocation(), player.getEyeLocation().getDirection(),
                RANGE, FluidCollisionMode.NEVER, true, 0.2, e -> !e.equals(player));
        if (hit == null) {
            player.sendActionBar(Component.text("Point at a block or player to fire.", NamedTextColor.RED));
            return;
        }
        Vector target = hit.getHitPosition();

        // No link system: only the person holding the rod fires
        List<Player> shooters = new ArrayList<>();
        shooters.add(player);

        World w = player.getWorld();
        Location above = spawnPoint(w, target);
        List<Location> spots = new ArrayList<>();
        for (int i = 0; i < shooters.size(); i++) {
            // Spiral around the target so the shooters' arrows don't all land on one spot
            double radius = SPACING * Math.sqrt(i);
            double angle = i * 2.399963;
            Location at = above.clone().add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
            spots.add(at.getBlock().isPassable() ? at : above.clone());
        }

        // Everyone within the area (including you) gets arrows aimed at them. A block over your head stops yours.
        List<Location> victims = new ArrayList<>();
        for (Player p : w.getPlayers()) {
            if (p.isDead() || p.getGameMode() == org.bukkit.GameMode.SPECTATOR) continue;
            Location pl = p.getLocation();
            if (Math.hypot(pl.getX() - target.getX(), pl.getZ() - target.getZ()) <= COVER_RADIUS) victims.add(pl);
        }

        for (int wave = 0; wave < WAVES; wave++) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                for (int i = 0; i < shooters.size(); i++) {
                    Player shooter = shooters.get(i);
                    if (!shooter.isOnline()) continue;
                    for (int k = 0; k < ARROWS_PER_WAVE; k++) {
                        fireArrow(w, arrowSpot(w, spots.get(i), k % 4 == 0), shooter);
                    }
                    for (Location v : victims) {
                        for (int k = 0; k < ARROWS_PER_PLAYER_WAVE; k++) {
                            fireArrow(w, skySpot(w, v.getX() + (random.nextDouble() - 0.5) * 0.5,
                                    v.getZ() + (random.nextDouble() - 0.5) * 0.5, v), shooter);
                        }
                    }
                }
            }, (long) wave * TICKS_BETWEEN_WAVES);
        }

        w.playSound(player.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1.0f, 0.5f);
        w.playSound(target.toLocation(w), Sound.ENTITY_GENERIC_EXPLODE, 0.5f, 2.0f);
        w.spawnParticle(Particle.CRIT, target.toLocation(w), 40, 0.6, 0.6, 0.6, 0.5);

        // One use, then the rod breaks
        player.getInventory().setItem(hand, null);
        w.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
    }

    /**
     * Where one arrow of the carpet starts. Tight arrows land right on the target, the others are spread evenly over
     * the whole area. Every arrow starts in the open sky above its spot, so a block over your head (or a roof)
     * really does stop them.
     */
    private Location arrowSpot(World w, Location center, boolean tight) {
        double radius = (tight ? ARROW_SCATTER_TIGHT : COVER_RADIUS) * Math.sqrt(random.nextDouble());
        double angle = random.nextDouble() * Math.PI * 2;
        return skySpot(w, center.getX() + Math.cos(angle) * radius, center.getZ() + Math.sin(angle) * radius, center);
    }

    /**
     * A start point SPAWN_HEIGHT blocks above the highest block at this spot, so anything built above the
     * ground (a block over your head, a roof, a tree) is in the arrow's way. Every arrow falls the same
     * distance, so they all land together. In the Nether and the End there is no open sky, so the arrow starts
     * under the ceiling above {@code near} instead. Returns null if the spot isn't loaded or is blocked.
     */
    private Location skySpot(World w, double x, double z, Location near) {
        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        Location at;
        if (w.getEnvironment() == World.Environment.NORMAL) {
            if (!w.isChunkLoaded(bx >> 4, bz >> 4)) return null;
            double y = Math.min(w.getMaxHeight() - 2, w.getHighestBlockYAt(bx, bz) + 1 + SPAWN_HEIGHT);
            at = new Location(w, x, y, z);
        } else {
            Location base = new Location(w, x, near.getY() + 1, z);
            RayTraceResult up = w.rayTraceBlocks(base, new Vector(0, 1, 0), SPAWN_HEIGHT,
                    FluidCollisionMode.NEVER, true);
            at = up != null ? up.getHitPosition().toLocation(w).subtract(0, 0.6, 0) : base.add(0, SPAWN_HEIGHT, 0);
        }
        return at.getBlock().isPassable() ? at : null;
    }

    private final java.util.Set<Arrow> flying = new java.util.HashSet<>();
    private org.bukkit.scheduler.BukkitTask guard;

    /**
     * Arrows fall very fast, so they could skip over a thin block. Every tick, look at the path each arrow is about to
     * take; if a block is in the way, the arrow is slowed so it ends at the block (hitting anyone on the way) instead of passing through it.
     */
    private void startBlockGuard() {
        if (guard != null) return;
        guard = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            java.util.Iterator<Arrow> it = flying.iterator();
            while (it.hasNext()) {
                Arrow a = it.next();
                if (!a.isValid() || a.isInBlock() || a.isOnGround()) { it.remove(); continue; }
                Vector v = a.getVelocity();
                double len = v.length();
                if (len < 0.01) continue;
                Vector dir = v.clone().normalize();
                RayTraceResult hit = a.getWorld().rayTraceBlocks(a.getLocation(), dir, len + 0.5,
                        FluidCollisionMode.NEVER, true);
                if (hit != null) {
                    // Slow the arrow so this tick's move ends right at the block, never past it.
                    double dist = hit.getHitPosition().distance(a.getLocation().toVector());
                    if (dist < len) a.setVelocity(dir.multiply(Math.max(0.3, dist - 0.1)));
                }
            }
        }, 1L, 1L);
    }

    private void fireArrow(World w, Location at, Player shooter) {
        if (at == null) return;
        Arrow arrow = w.spawn(at, Arrow.class, a -> {
            a.setShooter(shooter);
            a.setCritical(true);
            a.setDamage(ARROW_BASE_DAMAGE);
            a.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
            a.setPersistent(false);
            a.getPersistentDataContainer().set(arrowKey, PersistentDataType.BYTE, (byte) 1);
            a.setVelocity(new Vector(0, -ARROW_SPEED, 0));
        });
        flying.add(arrow);
        startBlockGuard();
        // Don't leave arrows lying around
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (arrow.isValid()) arrow.remove();
        }, ARROW_LIFETIME_TICKS);
    }

    /** The point 20 blocks above the target, or just under a ceiling if something is in the way. */
    private Location spawnPoint(World w, Vector target) {
        Location base = target.toLocation(w);
        RayTraceResult up = w.rayTraceBlocks(base.clone().add(0, 0.3, 0), new Vector(0, 1, 0), SPAWN_HEIGHT,
                FluidCollisionMode.NEVER, true);
        if (up != null) {
            return up.getHitPosition().toLocation(w).subtract(0, 0.6, 0);
        }
        return base.add(0, SPAWN_HEIGHT, 0);
    }

    /** Cannon arrows ignore the target's hit-immunity, so every arrow of the volley counts as its own hit. */
    @EventHandler
    public void onArrowHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Arrow arrow)) return;
        if (!arrow.getPersistentDataContainer().has(arrowKey, PersistentDataType.BYTE)) return;
        // No shield: the cannon's arrows hit anyone they land on, including the person who fired it.
        if (event.getHitEntity() instanceof LivingEntity target) {
            target.setNoDamageTicks(0);
            if (target instanceof Player player && player.getGameMode() != org.bukkit.GameMode.CREATIVE) {
                wearDownArmor(player);
            }
        }
    }

    /** The arrows chew through armor: each hit takes a big bite out of every piece, and pieces can shatter. */
    private void wearDownArmor(Player player) {
        // Per player: [0] = when this volley started, [1..4] = wear already dealt to each armor slot this volley
        long now = System.currentTimeMillis();
        long[] wear = armorWear.get(player.getUniqueId());
        if (wear == null || now - wear[0] > VOLLEY_WINDOW_MS) {
            wear = new long[5];
            wear[0] = now;
            armorWear.put(player.getUniqueId(), wear);
        }
        ItemStack[] armor = player.getInventory().getArmorContents();
        for (int i = 0; i < armor.length; i++) {
            ItemStack piece = armor[i];
            if (piece == null || piece.getType() == Material.AIR || !(piece.getItemMeta() instanceof Damageable meta)) continue;
            int max = meta.hasMaxDamage() ? meta.getMaxDamage() : piece.getType().getMaxDurability();
            if (max <= 0) continue;
            int step = Math.max(1, (int) Math.round(max * ARMOR_DAMAGE_FRACTION));
            long room = (long) Math.floor(max * ARMOR_MAX_PER_VOLLEY) - wear[i + 1];
            int add = (int) Math.min(step, room);
            // The arrows wear armor down hard but never shatter it: one point of durability always stays
            add = Math.min(add, max - 1 - meta.getDamage());
            if (add <= 0) continue;
            wear[i + 1] += add;
            meta.setDamage(meta.getDamage() + add);
            piece.setItemMeta(meta);
        }
        player.getInventory().setArmorContents(armor);
    }

    // ---- Getting it: /give <player> arrowcannon ----

    private boolean isFromCommandBlock(CommandSender sender) {
        if (sender instanceof ProxiedCommandSender proxied) {
            return isFromCommandBlock(proxied.getCaller()) || isFromCommandBlock(proxied.getCallee());
        }
        return sender instanceof BlockCommandSender || sender instanceof CommandMinecart;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        String message = event.getMessage();
        if (!message.startsWith("/")) return;
        if (handleGive(event.getPlayer(), message.substring(1))) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onServerCommand(ServerCommandEvent event) {
        if (handleGive(event.getSender(), event.getCommand())) event.setCancelled(true);
    }

    /** Returns true if this was a  /give <targets> arrowcannon  that we dealt with. */
    private boolean handleGive(CommandSender sender, String commandLine) {
        String[] t = commandLine.trim().split("\\s+");
        if (t.length < 1 || t[0].isEmpty()) return false;
        String cmd = t[0].toLowerCase();
        String targetArg;
        String countArg;
        if (cmd.equals("give:" + ITEM_ID) || cmd.equals("minecraft:give:" + ITEM_ID)) {
            // Short form:  /give:arrowcannon [player] [count]
            targetArg = t.length >= 2 ? t[1] : "@s";
            countArg = t.length >= 3 ? t[2] : null;
        } else if (cmd.equals("give") || cmd.equals("minecraft:give")) {
            // Normal form:  /give <player> arrowcannon [count]
            if (t.length < 3) return false;
            String item = t[2].toLowerCase();
            if (item.startsWith("minecraft:")) item = item.substring("minecraft:".length());
            if (!item.equals(ITEM_ID)) return false;
            targetArg = t[1];
            countArg = t.length >= 4 ? t[3] : null;
        } else {
            return false;
        }

        // From here on it is ours. Command blocks are silently refused.
        if (isFromCommandBlock(sender)) return true;
        if (!sender.hasPermission("minecraft.command.give") && !sender.isOp()) {
            sender.sendMessage(Component.text("You don't have permission to do that.", NamedTextColor.RED));
            return true;
        }

        int count = 1;
        if (countArg != null) {
            try {
                count = Math.max(1, Math.min(MAX_GIVE, Integer.parseInt(countArg)));
            } catch (NumberFormatException e) {
                sender.sendMessage(Component.text("Usage: /give:arrowcannon [player] [count]", NamedTextColor.RED));
                return true;
            }
        }

        int given = 0;
        try {
            for (Entity e : plugin.getServer().selectEntities(sender, targetArg)) {
                if (!(e instanceof Player target)) continue;
                for (int i = 0; i < count; i++) {
                    target.getInventory().addItem(createCannon())
                            .values().forEach(left -> target.getWorld().dropItemNaturally(target.getLocation(), left));
                }
                target.sendMessage(Component.text("You received the Arrow Cannon!", NamedTextColor.DARK_AQUA));
                given++;
            }
        } catch (IllegalArgumentException ex) {
            Player byName = plugin.getServer().getPlayerExact(targetArg);
            if (byName != null) {
                for (int i = 0; i < count; i++) {
                    byName.getInventory().addItem(createCannon())
                            .values().forEach(left -> byName.getWorld().dropItemNaturally(byName.getLocation(), left));
                }
                byName.sendMessage(Component.text("You received the Arrow Cannon!", NamedTextColor.DARK_AQUA));
                given++;
            }
        }
        if (given == 0) {
            sender.sendMessage(Component.text("No player found for '" + targetArg + "'.", NamedTextColor.RED));
        } else {
            sender.sendMessage(Component.text("Gave the Arrow Cannon to " + given + " player(s).",
                    NamedTextColor.DARK_AQUA));
        }
        return true;
    }
}
