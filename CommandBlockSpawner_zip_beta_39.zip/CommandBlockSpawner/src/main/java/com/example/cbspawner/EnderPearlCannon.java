package com.example.cbspawner;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.World;
import org.bukkit.command.BlockCommandSender;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ProxiedCommandSender;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.minecart.CommandMinecart;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * The Ender Pearl Cannon: a plain (unenchanted) fishing rod that works once.
 * Cast it, then reel in (unhook) while pointing at something: every linked player (see /link) gets an
 * ender pearl above where you are pointing, and the rod breaks. It looks like a normal fishing rod with
 * 4 durability left out of 64.
 *
 * It can only be obtained with  /give:enderpearlcannon [player]  (or /give <player> enderpearlcannon)
 * from chat or the console.
 * Command blocks cannot give it, and it is not one of the command block drop rewards.
 */
public class EnderPearlCannon implements Listener {

    /** The item id that /give understands, as in  /give @s enderpearlcannon  */
    private static final String ITEM_ID = "enderpearlcannon";
    /** The tag that /link toggles. */
    private static final String LINK_TAG = "linked";

    private static final Material CANNON_MATERIAL = Material.FISHING_ROD;
    /** The rod shows "Durability: 4 / 64" (a normal rod's maximum is 64). */
    private static final int MAX_DURABILITY = 64;
    private static final int DURABILITY_LEFT = 4;
    /** How far you can point, in blocks. */
    private static final double RANGE = 150.0;
    private static final int MAX_GIVE = 36;
    /** How far above the spot you point the pearls appear. */
    private static final double SPAWN_HEIGHT = 20.0;
    /** How many blocks apart the pearls land from each other (they spread out in a spiral around the target). */
    private static final double SPACING = 3.0;
    /** Vanilla ender pearls hurt you by 5 when you land. Set to 0 for no damage. */
    private static final double PEARL_DAMAGE = 5.0;
    private static final String DOMAIN_WORLD_NAME = "black_domain";

    private final JavaPlugin plugin;
    private final NamespacedKey cannonKey;
    private final NamespacedKey pearlKey;
    private final NamespacedKey armyKey;

    public EnderPearlCannon(JavaPlugin plugin) {
        this.plugin = plugin;
        this.cannonKey = new NamespacedKey(plugin, "ender_pearl_cannon");
        this.pearlKey = new NamespacedKey(plugin, "cannon_pearl_owner");
        this.armyKey = new NamespacedKey(plugin, "cannon_army");
    }

    // ---- The item ----

    /** Army names are lowercase letters, digits and underscores. Empty means the default army. */
    public static String cleanArmy(String army) {
        if (army == null) return "";
        return army.toLowerCase().replaceAll("[^a-z0-9_]", "");
    }

    /** The scoreboard tag that /link uses for an army: "linked" for the default army, "linked_name" for others. */
    public static String linkTag(String army) {
        String a = cleanArmy(army);
        return a.isEmpty() ? LINK_TAG : LINK_TAG + "_" + a;
    }

    /** Takes every army tag off a player. */
    public static void unlinkAll(Player p) {
        for (String tag : new ArrayList<>(p.getScoreboardTags())) {
            if (tag.equals(LINK_TAG) || tag.startsWith(LINK_TAG + "_")) p.removeScoreboardTag(tag);
        }
    }

    /** Which army a rod fires for ("" = the default one). */
    private String armyOf(ItemStack rod) {
        String a = rod.getItemMeta().getPersistentDataContainer().get(armyKey, PersistentDataType.STRING);
        return a == null ? "" : a;
    }

    @EventHandler
    public void onDeath(org.bukkit.event.entity.PlayerDeathEvent event) {
        unlinkAll(event.getEntity());
    }

    @EventHandler
    public void onQuit(org.bukkit.event.player.PlayerQuitEvent event) {
        unlinkAll(event.getPlayer());
    }

    public ItemStack createCannon() {
        return createCannon("");
    }

    public ItemStack createCannon(String army) {
        // Looks exactly like a normal fishing rod: no custom name, no lore, no glow.
        // Only the hidden tag and the durability (4 left out of 64) tell it apart.
        ItemStack item = new ItemStack(CANNON_MATERIAL);
        ItemMeta meta = item.getItemMeta();
        if (meta instanceof Damageable damageable) {
            damageable.setMaxDamage(MAX_DURABILITY);
            damageable.setDamage(MAX_DURABILITY - DURABILITY_LEFT);
        }
        meta.getPersistentDataContainer().set(cannonKey, PersistentDataType.BYTE, (byte) 1);
        String a = cleanArmy(army);
        if (!a.isEmpty()) meta.getPersistentDataContainer().set(armyKey, PersistentDataType.STRING, a);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isCannon(ItemStack stack) {
        if (stack == null || stack.getType() != CANNON_MATERIAL || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(cannonKey, PersistentDataType.BYTE);
    }

    // ---- Reeling in (unhooking) ----

    @EventHandler
    public void onFish(PlayerFishEvent event) {
        PlayerFishEvent.State state = event.getState();
        // Only the moments where the line is pulled back in count as "unhooking"
        if (state != PlayerFishEvent.State.REEL_IN && state != PlayerFishEvent.State.IN_GROUND
                && state != PlayerFishEvent.State.CAUGHT_ENTITY && state != PlayerFishEvent.State.CAUGHT_FISH
                && state != PlayerFishEvent.State.FAILED_ATTEMPT) {
            return;
        }
        Player player = event.getPlayer();
        EquipmentSlot hand = event.getHand();
        if (hand == null) return;
        ItemStack rod = player.getInventory().getItem(hand);
        if (!isCannon(rod)) return;

        // The cannon never catches anything: it just fires
        event.setCancelled(true);
        event.getHook().remove();

        Vector direction = player.getEyeLocation().getDirection();
        RayTraceResult hit = player.getWorld().rayTrace(player.getEyeLocation(), direction, RANGE,
                FluidCollisionMode.NEVER, true, 0.2, e -> !e.equals(player));
        if (hit == null) {
            player.sendActionBar(Component.text("Point at a block or player to fire.", NamedTextColor.RED));
            return;
        }
        Vector target = hit.getHitPosition();

        String armyTag = linkTag(armyOf(rod));
        List<Player> shooters = new ArrayList<>();
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            if (p.getScoreboardTags().contains(armyTag) && !p.isDead()
                    && !p.getWorld().getName().equals(DOMAIN_WORLD_NAME)
                    && p.getGameMode() != org.bukkit.GameMode.SPECTATOR) {
                shooters.add(p);
            }
        }
        if (shooters.isEmpty()) {
            player.sendActionBar(Component.text("Nobody is linked to this rod. Use /link first.", NamedTextColor.RED));
            return;
        }

        World w = player.getWorld();
        Location above = spawnPoint(w, target);
        int index = 0;
        for (Player shooter : shooters) {
            // Spiral pattern: the first pearl is in the middle, the rest circle outwards, SPACING blocks apart
            double radius = SPACING * Math.sqrt(index);
            double angle = index * 2.399963; // the golden angle, so pearls never line up
            Location at = above.clone().add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
            if (!at.getBlock().isPassable()) at = above.clone();
            index++;
            final String ownerId = shooter.getUniqueId().toString();
            // No shooter is set on purpose: the plugin teleports the owner itself (this also works across worlds)
            w.spawn(at, EnderPearl.class, pearl -> {
                pearl.getPersistentDataContainer().set(pearlKey, PersistentDataType.STRING, ownerId);
                pearl.setVelocity(new Vector(0, -0.6, 0));
            });
        }

        w.playSound(player.getLocation(), Sound.ENTITY_ENDER_PEARL_THROW, 1.0f, 0.6f);
        w.spawnParticle(Particle.PORTAL, target.toLocation(w), 60, 0.6, 0.6, 0.6, 0.5);

        breakRod(player, hand);
    }

    /** The cannon only works once: after firing, the rod breaks. */
    private void breakRod(Player player, EquipmentSlot hand) {
        player.getInventory().setItem(hand, null);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
    }

    /** The point 20 blocks above the target, or just under a ceiling if something is in the way. */
    private Location spawnPoint(World w, Vector target) {
        Location base = target.toLocation(w);
        RayTraceResult up = w.rayTraceBlocks(base.clone().add(0, 0.3, 0), new Vector(0, 1, 0), SPAWN_HEIGHT,
                FluidCollisionMode.NEVER, true);
        if (up != null) {
            return up.getHitPosition().toLocation(w).subtract(0, 0.6, 0);
        }
        return base.add(0, SPAWN_HEIGHT, 0);
    }

    // ---- When a cannon pearl lands ----

    @EventHandler
    public void onPearlHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof EnderPearl pearl)) return;
        String id = pearl.getPersistentDataContainer().get(pearlKey, PersistentDataType.STRING);
        if (id == null) return;

        Location landing = pearl.getLocation();
        Block block = event.getHitBlock();
        BlockFace face = event.getHitBlockFace();
        if (block != null && face != null) {
            int up = face == BlockFace.DOWN ? -2 : face.getModY();
            landing = block.getLocation().add(0.5 + face.getModX(), up, 0.5 + face.getModZ());
        }
        pearl.remove();

        Player found = null;
        try {
            found = plugin.getServer().getPlayer(UUID.fromString(id));
        } catch (IllegalArgumentException e) {
            return;
        }
        if (found == null || found.isDead()) return;
        final Player owner = found;

        landing.setYaw(owner.getLocation().getYaw());
        landing.setPitch(owner.getLocation().getPitch());
        final Location dest = landing;
        owner.teleportAsync(dest, PlayerTeleportEvent.TeleportCause.ENDER_PEARL)
                .thenAccept(ok -> plugin.getServer().getScheduler().runTask(plugin, () -> {
                    if (!ok || !owner.isOnline()) return;
                    owner.getWorld().playSound(owner.getLocation(), Sound.ENTITY_PLAYER_TELEPORT, 1.0f, 1.0f);
                    if (PEARL_DAMAGE > 0 && owner.getGameMode() == org.bukkit.GameMode.SURVIVAL) {
                        owner.damage(PEARL_DAMAGE);
                    }
                }));
    }

    // ---- Getting it: /give <player> enderpearlcannon ----

    private boolean isFromCommandBlock(CommandSender sender) {
        if (sender instanceof ProxiedCommandSender proxied) {
            return isFromCommandBlock(proxied.getCaller()) || isFromCommandBlock(proxied.getCallee());
        }
        return sender instanceof BlockCommandSender || sender instanceof CommandMinecart;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        String message = event.getMessage();
        if (!message.startsWith("/")) return;
        if (handleGive(event.getPlayer(), message.substring(1))) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onServerCommand(ServerCommandEvent event) {
        if (handleGive(event.getSender(), event.getCommand())) event.setCancelled(true);
    }

    /** Returns true if this was a  /give <targets> enderpearlcannon  that we dealt with. */
    private boolean handleGive(CommandSender sender, String commandLine) {
        String[] t = commandLine.trim().split("\\s+");
        if (t.length < 1 || t[0].isEmpty()) return false;
        String cmd = t[0].toLowerCase();
        String targetArg;
        int extraFrom; // where the optional [count] and [army] words start
        if (cmd.equals("give:" + ITEM_ID) || cmd.equals("minecraft:give:" + ITEM_ID)) {
            // Short form:  /give:enderpearlcannon [player] [count] [army]
            targetArg = t.length >= 2 ? t[1] : "@s";
            extraFrom = 2;
        } else if (cmd.equals("give") || cmd.equals("minecraft:give")) {
            // Normal form:  /give <player> enderpearlcannon [count]
            if (t.length < 3) return false;
            String item = t[2].toLowerCase();
            if (item.startsWith("minecraft:")) item = item.substring("minecraft:".length());
            if (!item.equals(ITEM_ID)) return false;
            targetArg = t[1];
            extraFrom = 3;
        } else {
            return false;
        }

        // From here on it is ours. Command blocks are silently refused.
        if (isFromCommandBlock(sender)) return true;
        if (!sender.hasPermission("minecraft.command.give") && !sender.isOp()) {
            sender.sendMessage(Component.text("You don't have permission to do that.", NamedTextColor.RED));
            return true;
        }

        // Extra words: a number is the count, any other word is the army the rod belongs to
        int count = 1;
        String army = "";
        for (int i = extraFrom; i < t.length; i++) {
            try {
                count = Math.max(1, Math.min(MAX_GIVE, Integer.parseInt(t[i])));
            } catch (NumberFormatException e) {
                army = cleanArmy(t[i]);
            }
        }
        final String armyName = army;

        int given = 0;
        try {
            for (Entity e : plugin.getServer().selectEntities(sender, targetArg)) {
                if (!(e instanceof Player target)) continue;
                for (int i = 0; i < count; i++) {
                    target.getInventory().addItem(createCannon(armyName))
                            .values().forEach(left -> target.getWorld().dropItemNaturally(target.getLocation(), left));
                }
                target.sendMessage(Component.text("You received the Ender Pearl Cannon" + (armyName.isEmpty() ? "!" : " for army " + armyName + "!"), NamedTextColor.DARK_AQUA));
                given++;
            }
        } catch (IllegalArgumentException ex) {
            Player byName = plugin.getServer().getPlayerExact(targetArg);
            if (byName != null) {
                for (int i = 0; i < count; i++) {
                    byName.getInventory().addItem(createCannon(armyName))
                            .values().forEach(left -> byName.getWorld().dropItemNaturally(byName.getLocation(), left));
                }
                byName.sendMessage(Component.text("You received the Ender Pearl Cannon" + (armyName.isEmpty() ? "!" : " for army " + armyName + "!"), NamedTextColor.DARK_AQUA));
                given++;
            }
        }
        if (given == 0) {
            sender.sendMessage(Component.text("No player found for '" + targetArg + "'.", NamedTextColor.RED));
        } else {
            sender.sendMessage(Component.text("Gave the Ender Pearl Cannon to " + given + " player(s).",
                    NamedTextColor.DARK_AQUA));
        }
        return true;
    }
}
