package com.example.cbspawner;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.command.BlockCommandSender;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ProxiedCommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Player;
import org.bukkit.entity.minecart.CommandMinecart;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.List;

/**
 * The Ender Pearl Cannon. It can only be obtained with  /give <player> enderpearlcannon  from chat or the console.
 * Command blocks cannot give it, and it is not one of the command block drop rewards.
 * Right-click to fire an ender pearl (it uses one from your inventory) at high speed.
 */
public class EnderPearlCannon implements Listener {

    /** The item id that /give understands, as in  /give @s enderpearlcannon  */
    private static final String ITEM_ID = "enderpearlcannon";

    private static final Material CANNON_MATERIAL = Material.BLAZE_ROD;
    /** Vanilla pearls fly at 1.5; the cannon fires much faster. */
    private static final double SPEED = 4.0;
    private static final int COOLDOWN_TICKS = 20;
    private static final int MAX_GIVE = 36;

    private final JavaPlugin plugin;
    private final NamespacedKey cannonKey;

    public EnderPearlCannon(JavaPlugin plugin) {
        this.plugin = plugin;
        this.cannonKey = new NamespacedKey(plugin, "ender_pearl_cannon");
    }

    // ---- The item ----

    public ItemStack createCannon() {
        ItemStack item = new ItemStack(CANNON_MATERIAL);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Ender Pearl Cannon", NamedTextColor.DARK_AQUA)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Right-click: fire an ender pearl", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Uses one ender pearl from your inventory", NamedTextColor.DARK_AQUA)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(cannonKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isCannon(ItemStack stack) {
        if (stack == null || stack.getType() != CANNON_MATERIAL || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(cannonKey, PersistentDataType.BYTE);
    }

    // ---- Firing ----

    @EventHandler
    public void onUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
        Player player = event.getPlayer();
        if (!isCannon(player.getInventory().getItemInMainHand())) return;

        event.setCancelled(true);
        if (player.hasCooldown(CANNON_MATERIAL)) return;

        if (player.getGameMode() != GameMode.CREATIVE && !takePearl(player)) {
            player.sendActionBar(Component.text("You need an ender pearl to fire the cannon.", NamedTextColor.RED));
            return;
        }

        Vector velocity = player.getEyeLocation().getDirection().normalize().multiply(SPEED);
        player.launchProjectile(EnderPearl.class, velocity);
        player.setCooldown(CANNON_MATERIAL, COOLDOWN_TICKS);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 1.6f);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDER_PEARL_THROW, 1.0f, 0.6f);
    }

    private boolean takePearl(Player player) {
        for (ItemStack stack : player.getInventory().getContents()) {
            if (stack != null && stack.getType() == Material.ENDER_PEARL) {
                stack.setAmount(stack.getAmount() - 1);
                return true;
            }
        }
        return false;
    }

    // ---- Getting it: /give <player> enderpearlcannon ----

    private boolean isFromCommandBlock(CommandSender sender) {
        if (sender instanceof ProxiedCommandSender proxied) {
            return isFromCommandBlock(proxied.getCaller()) || isFromCommandBlock(proxied.getCallee());
        }
        return sender instanceof BlockCommandSender || sender instanceof CommandMinecart;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        String message = event.getMessage();
        if (!message.startsWith("/")) return;
        if (handleGive(event.getPlayer(), message.substring(1))) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onServerCommand(ServerCommandEvent event) {
        if (handleGive(event.getSender(), event.getCommand())) event.setCancelled(true);
    }

    /** Returns true if this was a  /give <targets> enderpearlcannon  that we dealt with. */
    private boolean handleGive(CommandSender sender, String commandLine) {
        String[] t = commandLine.trim().split("\\s+");
        if (t.length < 3) return false;
        String cmd = t[0].toLowerCase();
        if (!cmd.equals("give") && !cmd.equals("minecraft:give")) return false;

        String item = t[2].toLowerCase();
        if (item.startsWith("minecraft:")) item = item.substring("minecraft:".length());
        if (!item.equals(ITEM_ID)) return false;

        // From here on it is ours. Command blocks are silently refused.
        if (isFromCommandBlock(sender)) return true;
        if (!sender.hasPermission("minecraft.command.give") && !sender.isOp()) {
            sender.sendMessage(Component.text("You don't have permission to do that.", NamedTextColor.RED));
            return true;
        }

        int count = 1;
        if (t.length >= 4) {
            try {
                count = Math.max(1, Math.min(MAX_GIVE, Integer.parseInt(t[3])));
            } catch (NumberFormatException e) {
                sender.sendMessage(Component.text("Usage: /give <player> enderpearlcannon [count]", NamedTextColor.RED));
                return true;
            }
        }

        int given = 0;
        try {
            for (Entity e : plugin.getServer().selectEntities(sender, t[1])) {
                if (!(e instanceof Player target)) continue;
                for (int i = 0; i < count; i++) {
                    target.getInventory().addItem(createCannon())
                            .values().forEach(left -> target.getWorld().dropItemNaturally(target.getLocation(), left));
                }
                target.sendMessage(Component.text("You received the Ender Pearl Cannon!", NamedTextColor.DARK_AQUA));
                given++;
            }
        } catch (IllegalArgumentException ex) {
            Player byName = plugin.getServer().getPlayerExact(t[1]);
            if (byName != null) {
                for (int i = 0; i < count; i++) {
                    byName.getInventory().addItem(createCannon())
                            .values().forEach(left -> byName.getWorld().dropItemNaturally(byName.getLocation(), left));
                }
                byName.sendMessage(Component.text("You received the Ender Pearl Cannon!", NamedTextColor.DARK_AQUA));
                given++;
            }
        }
        if (given == 0) {
            sender.sendMessage(Component.text("No player found for '" + t[1] + "'.", NamedTextColor.RED));
        } else {
            sender.sendMessage(Component.text("Gave the Ender Pearl Cannon to " + given + " player(s).",
                    NamedTextColor.DARK_AQUA));
        }
        return true;
    }
}
