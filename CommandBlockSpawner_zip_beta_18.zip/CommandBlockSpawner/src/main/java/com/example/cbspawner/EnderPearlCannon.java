package com.example.cbspawner;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.BlockCommandSender;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ProxiedCommandSender;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.minecart.CommandMinecart;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

/**
 * The Ender Pearl Cannon: a fishing rod with 4 durability.
 * Cast it, then reel in (unhook) while pointing at something: every linked player (see /link) gets an
 * ender pearl thrown from where they stand that lands where you are pointing. Each reel-in costs 1 durability,
 * and the rod breaks after the 4th.
 *
 * It can only be obtained with  /give <player> enderpearlcannon  from chat or the console.
 * Command blocks cannot give it, and it is not one of the command block drop rewards.
 */
public class EnderPearlCannon implements Listener {

    /** The item id that /give understands, as in  /give @s enderpearlcannon  */
    private static final String ITEM_ID = "enderpearlcannon";
    /** The tag that /link toggles. */
    private static final String LINK_TAG = "linked";

    private static final Material CANNON_MATERIAL = Material.FISHING_ROD;
    private static final int DURABILITY = 4;
    /** How far you can point, in blocks. */
    private static final double RANGE = 150.0;
    private static final int MAX_GIVE = 36;

    private final JavaPlugin plugin;
    private final NamespacedKey cannonKey;

    public EnderPearlCannon(JavaPlugin plugin) {
        this.plugin = plugin;
        this.cannonKey = new NamespacedKey(plugin, "ender_pearl_cannon");
    }

    // ---- The item ----

    public ItemStack createCannon() {
        ItemStack item = new ItemStack(CANNON_MATERIAL);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Ender Pearl Cannon", NamedTextColor.DARK_AQUA)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Cast it, then reel in while pointing", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Linked players' pearls land where you point", NamedTextColor.DARK_AQUA)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text(DURABILITY + " uses", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.setEnchantmentGlintOverride(true);
        if (meta instanceof Damageable damageable) {
            damageable.setMaxDamage(DURABILITY);
            damageable.setDamage(0);
        }
        meta.getPersistentDataContainer().set(cannonKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isCannon(ItemStack stack) {
        if (stack == null || stack.getType() != CANNON_MATERIAL || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(cannonKey, PersistentDataType.BYTE);
    }

    // ---- Reeling in (unhooking) ----

    @EventHandler
    public void onFish(PlayerFishEvent event) {
        PlayerFishEvent.State state = event.getState();
        // Only the moments where the line is pulled back in count as "unhooking"
        if (state != PlayerFishEvent.State.REEL_IN && state != PlayerFishEvent.State.IN_GROUND
                && state != PlayerFishEvent.State.CAUGHT_ENTITY && state != PlayerFishEvent.State.CAUGHT_FISH
                && state != PlayerFishEvent.State.FAILED_ATTEMPT) {
            return;
        }
        Player player = event.getPlayer();
        EquipmentSlot hand = event.getHand();
        if (hand == null) return;
        ItemStack rod = player.getInventory().getItem(hand);
        if (!isCannon(rod)) return;

        // The cannon never catches anything: it just fires
        event.setCancelled(true);
        event.getHook().remove();

        Vector direction = player.getEyeLocation().getDirection();
        RayTraceResult hit = player.getWorld().rayTrace(player.getEyeLocation(), direction, RANGE,
                FluidCollisionMode.NEVER, true, 0.2, e -> !e.equals(player));
        if (hit == null) {
            player.sendActionBar(Component.text("Point at a block or player to fire.", NamedTextColor.RED));
            return;
        }
        Vector target = hit.getHitPosition();

        List<Player> shooters = new ArrayList<>();
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            if (p.getScoreboardTags().contains(LINK_TAG) && !p.isDead()
                    && p.getWorld().equals(player.getWorld())
                    && p.getGameMode() != org.bukkit.GameMode.SPECTATOR) {
                shooters.add(p);
            }
        }
        if (shooters.isEmpty()) {
            player.sendActionBar(Component.text("Nobody is linked. Use /link first.", NamedTextColor.RED));
            return;
        }

        for (Player shooter : shooters) {
            Vector velocity = solveLaunch(shooter.getEyeLocation(), target);
            shooter.launchProjectile(EnderPearl.class, velocity);
            shooter.sendActionBar(Component.text("Pulled by " + player.getName() + "'s cannon!",
                    NamedTextColor.DARK_AQUA));
        }

        World w = player.getWorld();
        w.playSound(player.getLocation(), Sound.ENTITY_ENDER_PEARL_THROW, 1.0f, 0.6f);
        w.spawnParticle(Particle.PORTAL, target.toLocation(w), 60, 0.6, 0.6, 0.6, 0.5);
        player.sendActionBar(Component.text("Fired " + shooters.size() + " pearl(s)!", NamedTextColor.DARK_AQUA));

        spendDurability(player, hand, rod);
    }

    /** Uses up one of the 4 durability; when the last is gone, the rod breaks. */
    private void spendDurability(Player player, EquipmentSlot hand, ItemStack rod) {
        ItemMeta meta = rod.getItemMeta();
        if (!(meta instanceof Damageable damageable)) return;
        int damage = damageable.getDamage() + 1;
        if (damage >= DURABILITY) {
            player.getInventory().setItem(hand, null);
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
            player.sendMessage(Component.text("The Ender Pearl Cannon breaks!", NamedTextColor.DARK_AQUA));
            return;
        }
        damageable.setDamage(damage);
        rod.setItemMeta(meta);
        player.getInventory().setItem(hand, rod);
        player.sendMessage(Component.text("The cannon has " + (DURABILITY - damage) + " use(s) left.",
                NamedTextColor.GRAY));
    }

    /**
     * Works out the velocity that makes an ender pearl thrown from {@code from} come down on {@code target}.
     * It tries many launch angles and speeds, simulating how a pearl flies (drag 0.99, gravity 0.03),
     * and keeps the one that lands closest.
     */
    private Vector solveLaunch(Location from, Vector target) {
        double dx = target.getX() - from.getX();
        double dz = target.getZ() - from.getZ();
        double dy = target.getY() - from.getY();
        double dh = Math.hypot(dx, dz);
        if (dh < 0.5) {
            return new Vector(0, dy < 0 ? -0.5 : 0.5, 0); // right above or below: just drop or lob it
        }
        double dirX = dx / dh;
        double dirZ = dz / dh;

        double bestScore = Double.MAX_VALUE;
        double bestHorizontal = 1.5;
        double bestVertical = 0.5;
        double[] speeds = {1.6, 2.5, 3.5, 4.5};
        for (double speed : speeds) {
            for (double deg = -25; deg <= 75; deg += 0.5) {
                double rad = Math.toRadians(deg);
                double vh = speed * Math.cos(rad);
                double vy = speed * Math.sin(rad);
                double startVh = vh;
                double startVy = vy;
                double x = 0;
                double y = 0;
                for (int tick = 0; tick < 400; tick++) {
                    x += vh;
                    y += vy;
                    vh *= 0.99;
                    vy *= 0.99;
                    vy -= 0.03;
                    if (vy < 0 && y <= dy) {
                        double score = Math.abs(x - dh) + Math.abs(deg) * 0.001;
                        if (score < bestScore) {
                            bestScore = score;
                            bestHorizontal = startVh;
                            bestVertical = startVy;
                        }
                        break;
                    }
                }
            }
        }
        return new Vector(dirX * bestHorizontal, bestVertical, dirZ * bestHorizontal);
    }

    // ---- Getting it: /give <player> enderpearlcannon ----

    private boolean isFromCommandBlock(CommandSender sender) {
        if (sender instanceof ProxiedCommandSender proxied) {
            return isFromCommandBlock(proxied.getCaller()) || isFromCommandBlock(proxied.getCallee());
        }
        return sender instanceof BlockCommandSender || sender instanceof CommandMinecart;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        String message = event.getMessage();
        if (!message.startsWith("/")) return;
        if (handleGive(event.getPlayer(), message.substring(1))) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onServerCommand(ServerCommandEvent event) {
        if (handleGive(event.getSender(), event.getCommand())) event.setCancelled(true);
    }

    /** Returns true if this was a  /give <targets> enderpearlcannon  that we dealt with. */
    private boolean handleGive(CommandSender sender, String commandLine) {
        String[] t = commandLine.trim().split("\\s+");
        if (t.length < 3) return false;
        String cmd = t[0].toLowerCase();
        if (!cmd.equals("give") && !cmd.equals("minecraft:give")) return false;

        String item = t[2].toLowerCase();
        if (item.startsWith("minecraft:")) item = item.substring("minecraft:".length());
        if (!item.equals(ITEM_ID)) return false;

        // From here on it is ours. Command blocks are silently refused.
        if (isFromCommandBlock(sender)) return true;
        if (!sender.hasPermission("minecraft.command.give") && !sender.isOp()) {
            sender.sendMessage(Component.text("You don't have permission to do that.", NamedTextColor.RED));
            return true;
        }

        int count = 1;
        if (t.length >= 4) {
            try {
                count = Math.max(1, Math.min(MAX_GIVE, Integer.parseInt(t[3])));
            } catch (NumberFormatException e) {
                sender.sendMessage(Component.text("Usage: /give <player> enderpearlcannon [count]", NamedTextColor.RED));
                return true;
            }
        }

        int given = 0;
        try {
            for (Entity e : plugin.getServer().selectEntities(sender, t[1])) {
                if (!(e instanceof Player target)) continue;
                for (int i = 0; i < count; i++) {
                    target.getInventory().addItem(createCannon())
                            .values().forEach(left -> target.getWorld().dropItemNaturally(target.getLocation(), left));
                }
                target.sendMessage(Component.text("You received the Ender Pearl Cannon!", NamedTextColor.DARK_AQUA));
                given++;
            }
        } catch (IllegalArgumentException ex) {
            Player byName = plugin.getServer().getPlayerExact(t[1]);
            if (byName != null) {
                for (int i = 0; i < count; i++) {
                    byName.getInventory().addItem(createCannon())
                            .values().forEach(left -> byName.getWorld().dropItemNaturally(byName.getLocation(), left));
                }
                byName.sendMessage(Component.text("You received the Ender Pearl Cannon!", NamedTextColor.DARK_AQUA));
                given++;
            }
        }
        if (given == 0) {
            sender.sendMessage(Component.text("No player found for '" + t[1] + "'.", NamedTextColor.RED));
        } else {
            sender.sendMessage(Component.text("Gave the Ender Pearl Cannon to " + given + " player(s).",
                    NamedTextColor.DARK_AQUA));
        }
        return true;
    }
}
