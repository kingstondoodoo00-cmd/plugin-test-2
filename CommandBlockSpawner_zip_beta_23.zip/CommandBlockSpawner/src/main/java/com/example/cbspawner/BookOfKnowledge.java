package com.example.cbspawner;

import net.kyori.adventure.inventory.Book;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Player;
import org.bukkit.entity.Wolf;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.block.Block;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.List;
import java.util.Random;

/**
 * The Book o' Knowledge: a book with seven pages. Each page is unlocked once by spending XP levels,
 * and most pages cost a few levels every time they are used.
 * Your progress is saved on YOU (not on the book), so it survives losing or trading the book.
 */
public class BookOfKnowledge implements Listener {

    // ---- Tuning: change these numbers to rebalance the book ----

    /** XP levels it costs to unlock each page, one time. Page 1 is free. Pages unlock in order. */
    private static final int[] UNLOCK_COST = {0, 5, 8, 12, 15, 20, 30};
    /** XP levels each use costs (page 4 gives XP instead, page 6 only charges for teleporting). */
    private static final int[] USE_COST = {0, 10, 2, 0, 3, 2, 30};

    private static final int ALLY_SECONDS = 120;
    private static final int WOLF_COUNT = 3;
    private static final double SIPHON_RADIUS = 12.0;
    private static final int SIPHON_MAX_LEVELS_PER_PLAYER = 5;
    private static final int RANDOMIZER_EFFECTS = 3;
    private static final int RANDOMIZER_SECONDS = 30;
    private static final double RUPTURE_RADIUS = 20.0;
    private static final double RUPTURE_DAMAGE = 750.0;
    private static final double RUPTURE_PUSH = 2.5;

    private static final String[] PAGE_NAMES = {
            "Allies", "Magic Tools", "Point of Origin", "Siphon", "Randomizer", "Gateway", "Kynara Rupture"
    };

    private static final PotionEffectType[] RANDOM_EFFECTS = {
            PotionEffectType.SPEED, PotionEffectType.JUMP_BOOST, PotionEffectType.STRENGTH,
            PotionEffectType.REGENERATION, PotionEffectType.RESISTANCE, PotionEffectType.FIRE_RESISTANCE,
            PotionEffectType.INVISIBILITY, PotionEffectType.NIGHT_VISION, PotionEffectType.ABSORPTION,
            PotionEffectType.SLOW_FALLING, PotionEffectType.SLOWNESS, PotionEffectType.WEAKNESS,
            PotionEffectType.LEVITATION, PotionEffectType.GLOWING
    };

    /** The mobs page 1 can summon, and what each costs in XP levels. They fight for you for ALLY_SECONDS. */
    private static final String[] MOB_NAMES = {
            "Zombie", "Skeleton", "Spider", "Creeper", "Iron Golem", "Wolf Pack (3)", "Blaze",
            "Witch", "Enderman", "Wither Skeleton", "Ravager", "Warden", "Wither"
    };
    private static final EntityType[] MOB_TYPES = {
            EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER, EntityType.CREEPER, EntityType.IRON_GOLEM,
            EntityType.WOLF, EntityType.BLAZE, EntityType.WITCH, EntityType.ENDERMAN, EntityType.WITHER_SKELETON,
            EntityType.RAVAGER, EntityType.WARDEN, EntityType.WITHER
    };
    private static final int[] MOB_COSTS = {2, 2, 2, 4, 5, 3, 6, 6, 8, 10, 15, 40, 60};
    private static final int MOBS_PER_PAGE = 7;
    /** The most summoned mobs one player can have out at a time; the oldest go first. */
    private static final int MAX_ALLIES = 12;

    private final JavaPlugin plugin;
    private final NamespacedKey bookKey;
    private final NamespacedKey toolKey;
    private final NamespacedKey pagesKey;
    private final NamespacedKey originKey;
    private final NamespacedKey gatewayKey;
    private final NamespacedKey allyKey;
    /** The allies each player currently has out. */
    private final Map<UUID, List<LivingEntity>> allies = new HashMap<>();
    private final Random random = new Random();

    public BookOfKnowledge(JavaPlugin plugin) {
        this.plugin = plugin;
        this.bookKey = new NamespacedKey(plugin, "book_of_knowledge");
        this.toolKey = new NamespacedKey(plugin, "book_tool");
        this.pagesKey = new NamespacedKey(plugin, "book_pages_unlocked");
        this.originKey = new NamespacedKey(plugin, "book_origin");
        this.gatewayKey = new NamespacedKey(plugin, "book_gateway");
        this.allyKey = new NamespacedKey(plugin, "book_ally_owner");
    }

    /** Starts the repeating job that gives Haste 5 to anyone holding a book-forged tool. */
    public void start() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : plugin.getServer().getOnlinePlayers()) {
                if (isTool(p.getInventory().getItemInMainHand())) {
                    p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 30, 4, true, false, false));
                }
            }
        }, 10L, 10L);
    }

    // ---- The items ----

    public ItemStack createBook() {
        ItemStack book = new ItemStack(Material.BOOK);
        ItemMeta meta = book.getItemMeta();
        meta.displayName(Component.text("Book o' Knowledge", NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                line("Right-click: open the book", NamedTextColor.GRAY),
                line("Spend XP levels to unlock and use its pages", NamedTextColor.DARK_PURPLE)));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(bookKey, PersistentDataType.BYTE, (byte) 1);
        book.setItemMeta(meta);
        return book;
    }

    public boolean isBook(ItemStack stack) {
        if (stack == null || stack.getType() != Material.BOOK || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(bookKey, PersistentDataType.BYTE);
    }

    private boolean isTool(ItemStack stack) {
        if (stack == null || stack.getType() == Material.AIR || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(toolKey, PersistentDataType.BYTE);
    }

    private ItemStack createTool(Material type, String name) {
        ItemStack tool = new ItemStack(type);
        ItemMeta meta = tool.getItemMeta();
        meta.displayName(Component.text(name, NamedTextColor.LIGHT_PURPLE).decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(line("Haste 5 while held", NamedTextColor.GRAY)));
        meta.setUnbreakable(true);
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(toolKey, PersistentDataType.BYTE, (byte) 1);
        tool.setItemMeta(meta);
        return tool;
    }

    private static Component line(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    // ---- Opening the book ----

    @EventHandler
    public void onUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
        Player player = event.getPlayer();
        if (!isBook(player.getInventory().getItemInMainHand())) return;

        event.setCancelled(true);
        openBook(player);
    }

    private int unlockedPages(Player player) {
        int n = player.getPersistentDataContainer().getOrDefault(pagesKey, PersistentDataType.INTEGER, 1);
        return Math.max(1, Math.min(PAGE_NAMES.length, n));
    }

    /** Opens a real book: page 1 is the contents, pages 2 to 8 are the seven pages of the Book o' Knowledge. */
    public void openBook(Player player) {
        int unlocked = unlockedPages(player);
        List<Component> pages = new ArrayList<>();
        pages.add(contentsPage(player, unlocked));
        for (int page = 0; page < PAGE_NAMES.length; page++) {
            pages.add(abilityPage(page, unlocked));
        }
        // Pages 9 and 10: the list of mobs you can summon
        for (int start = 0; start < MOB_NAMES.length; start += MOBS_PER_PAGE) {
            pages.add(mobPage(start));
        }
        player.openBook(Book.book(Component.text("Book o' Knowledge"), Component.text("Wisp"), pages));
        player.playSound(player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 1.0f, 1.0f);
    }

    private static Component bookLine(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private Component contentsPage(Player player, int unlocked) {
        Component out = Component.text("Book o' Knowledge", NamedTextColor.DARK_PURPLE, TextDecoration.BOLD)
                .append(Component.newline())
                .append(bookLine("Your levels: " + player.getLevel(), NamedTextColor.DARK_GREEN))
                .append(Component.newline()).append(Component.newline());
        for (int page = 0; page < PAGE_NAMES.length; page++) {
            boolean open = page < unlocked;
            Component entry = Component.text((page + 1) + ". " + PAGE_NAMES[page] + (open ? "" : " (locked)"),
                            open ? NamedTextColor.DARK_PURPLE : NamedTextColor.DARK_GRAY)
                    .decoration(TextDecoration.ITALIC, false)
                    .clickEvent(ClickEvent.changePage(page + 2))
                    .hoverEvent(HoverEvent.showText(Component.text("Turn to this page")));
            out = out.append(entry).append(Component.newline());
        }
        return out;
    }

    private Component abilityPage(int page, int unlocked) {
        boolean open = page < unlocked;
        Component title = Component.text("Page " + (page + 1), NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false)
                .append(Component.newline());
        Component name = Component.text(PAGE_NAMES[page], NamedTextColor.DARK_PURPLE, TextDecoration.BOLD);
        if (page == 6) name = name.decoration(TextDecoration.UNDERLINED, true); // Kynara Rupture
        Component out = title.append(name).append(Component.newline()).append(Component.newline());

        if (open) {
            for (String text : pageDescription(page)) {
                out = out.append(bookLine(text, NamedTextColor.BLACK)).append(Component.newline());
            }
            out = out.append(Component.newline());
            if (USE_COST[page] > 0) {
                out = out.append(bookLine("Costs " + USE_COST[page] + " levels per use", NamedTextColor.DARK_RED))
                        .append(Component.newline());
            } else if (page == 3) {
                out = out.append(bookLine("Costs nothing: it gives you XP", NamedTextColor.DARK_GREEN))
                        .append(Component.newline());
            } else if (page == 0) {
                out = out.append(bookLine("The cost depends on the mob", NamedTextColor.DARK_RED))
                        .append(Component.newline());
            }
            out = out.append(Component.newline());
            if (page == 0) {
                out = out.append(Component.text("[Choose a mob]", NamedTextColor.DARK_GREEN, TextDecoration.BOLD)
                        .clickEvent(ClickEvent.changePage(PAGE_NAMES.length + 2))
                        .hoverEvent(HoverEvent.showText(Component.text("Pick which mob to summon"))));
            } else if (page == 5) {
                out = out.append(actionButton("[Save gateway here]", "/bookaction save " + page, "Save your position (free)"))
                        .append(Component.newline())
                        .append(actionButton("[Teleport to gateway]", "/bookaction use " + page, "Costs " + USE_COST[5] + " levels"));
            } else {
                out = out.append(actionButton("[Use this page]", "/bookaction use " + page, "Use it now"));
            }
        } else if (page == unlocked) {
            out = out.append(bookLine("This page is locked.", NamedTextColor.DARK_RED)).append(Component.newline())
                    .append(Component.newline())
                    .append(actionButton("[Unlock: " + UNLOCK_COST[page] + " levels]", "/bookaction unlock " + page,
                            "Spend " + UNLOCK_COST[page] + " levels to unlock this page"));
        } else {
            out = out.append(bookLine("This page is locked.", NamedTextColor.DARK_RED)).append(Component.newline())
                    .append(bookLine("Unlock the earlier pages first.", NamedTextColor.DARK_GRAY));
        }

        return out.append(Component.newline()).append(Component.newline())
                .append(Component.text("[Contents]", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false)
                        .clickEvent(ClickEvent.changePage(1)));
    }

    private Component mobPage(int start) {
        Component out = Component.text("Summon a Mob", NamedTextColor.DARK_PURPLE, TextDecoration.BOLD)
                .append(Component.newline())
                .append(bookLine("It fights for you for " + ALLY_SECONDS + "s", NamedTextColor.DARK_GRAY))
                .append(Component.newline());
        int end = Math.min(MOB_NAMES.length, start + MOBS_PER_PAGE);
        for (int i = start; i < end; i++) {
            out = out.append(actionButton(MOB_NAMES[i] + " - " + MOB_COSTS[i] + " lvl", "/bookaction summon " + i,
                    "Costs " + MOB_COSTS[i] + " levels")).append(Component.newline());
        }
        int thisPage = PAGE_NAMES.length + 2 + (start / MOBS_PER_PAGE);
        if (end < MOB_NAMES.length) {
            out = out.append(Component.text("[Next]", NamedTextColor.DARK_GRAY)
                    .clickEvent(ClickEvent.changePage(thisPage + 1)));
        } else {
            out = out.append(Component.text("[Back to Allies]", NamedTextColor.DARK_GRAY)
                    .clickEvent(ClickEvent.changePage(2)));
        }
        return out;
    }

    private Component actionButton(String label, String command, String hover) {
        return Component.text(label, NamedTextColor.DARK_GREEN, TextDecoration.BOLD)
                .clickEvent(ClickEvent.runCommand(command))
                .hoverEvent(HoverEvent.showText(Component.text(hover)));
    }

    private List<String> pageDescription(int page) {
        List<String> d = new ArrayList<>();
        switch (page) {
            case 0 -> {
                d.add("Summon a mob that fights");
                d.add("for you for " + ALLY_SECONDS + " seconds.");
                d.add("Stronger mobs cost more.");
            }
            case 1 -> {
                d.add("Forge a Netherite pickaxe, axe and shovel");
                d.add("that give you Haste 5 while held.");
            }
            case 2 -> {
                d.add("Teleport to your Point of Origin.");
                d.add("Set it with /setorigin.");
            }
            case 3 -> {
                d.add("Drain XP from players within " + (int) SIPHON_RADIUS + " blocks,");
                d.add("fully heal and get strong buffs.");
            }
            case 4 -> d.add("Gain " + RANDOMIZER_EFFECTS + " random potion effects.");
            case 5 -> {
                d.add("Save a gateway where you");
                d.add("stand, then teleport back to it.");
            }
            case 6 -> {
                d.add("A huge blast around you:");
                d.add("hurts and throws everything");
                d.add("within " + (int) RUPTURE_RADIUS + " blocks.");
            }
            default -> {
            }
        }
        return d;
    }

    /** Runs when a clickable line in the book is clicked: /bookaction <unlock|use|save> <page 0-6>. */
    public void handleAction(Player player, String[] args) {
        if (!isBook(player.getInventory().getItemInMainHand())) {
            player.sendMessage(Component.text("Hold the Book o' Knowledge to use its pages.", NamedTextColor.RED));
            return;
        }
        if (args.length < 2) return;
        int page;
        try {
            page = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            return;
        }
        if (page < 0 || page >= Math.max(PAGE_NAMES.length, MOB_NAMES.length)) return;

        int unlocked = unlockedPages(player);
        boolean isSummon = args[0].equalsIgnoreCase("summon");
        if (!isSummon && page >= PAGE_NAMES.length) return;
        switch (args[0].toLowerCase()) {
            case "unlock" -> {
                if (page == unlocked) {
                    unlockPage(player, page);
                } else {
                    player.sendMessage(Component.text("You can't unlock that page right now.", NamedTextColor.RED));
                }
            }
            case "use" -> {
                if (page < unlocked) {
                    usePage(player, page, false);
                } else {
                    player.sendMessage(Component.text("That page is still locked.", NamedTextColor.RED));
                }
            }
            case "save" -> {
                if (page == 5 && page < unlocked) usePage(player, page, true);
            }
            case "summon" -> {
                if (page < MOB_NAMES.length) summonMob(player, page); // here the number is the mob's index
            }
            default -> {
            }
        }
    }

    private void unlockPage(Player player, int page) {
        int cost = UNLOCK_COST[page];
        if (!canAfford(player, cost)) {
            player.sendMessage(Component.text("You need " + cost + " levels to unlock this page.", NamedTextColor.RED));
            return;
        }
        charge(player, cost);
        player.getPersistentDataContainer().set(pagesKey, PersistentDataType.INTEGER, page + 1);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);
        player.sendMessage(Component.text("Unlocked " + PAGE_NAMES[page] + "!", NamedTextColor.LIGHT_PURPLE));
        openBook(player); // reopen so the new page shows as unlocked
    }

    private boolean canAfford(Player player, int cost) {
        return cost <= 0 || player.getGameMode() == GameMode.CREATIVE || player.getLevel() >= cost;
    }

    private void charge(Player player, int cost) {
        if (cost > 0 && player.getGameMode() != GameMode.CREATIVE) {
            player.setLevel(player.getLevel() - cost);
        }
    }

    private boolean pay(Player player, int cost) {
        if (!canAfford(player, cost)) {
            player.sendMessage(Component.text("You need " + cost + " levels for that.", NamedTextColor.RED));
            return false;
        }
        charge(player, cost);
        return true;
    }

    private void usePage(Player player, int page, boolean saveMode) {
        switch (page) {
            case 0 -> player.sendMessage(Component.text("Open the book to page 1 and choose a mob.", NamedTextColor.GRAY));
            case 1 -> forgeTools(player);
            case 2 -> teleportToSaved(player, originKey, "Point of Origin", "Set it with /setorigin first.", USE_COST[2]);
            case 3 -> siphon(player);
            case 4 -> randomizer(player);
            case 5 -> {
                if (saveMode) {
                    saveSpot(player, gatewayKey);
                    player.sendMessage(Component.text("Gateway saved here.", NamedTextColor.LIGHT_PURPLE));
                    player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.5f);
                } else {
                    teleportToSaved(player, gatewayKey, "gateway", "Save one on this page first.", USE_COST[5]);
                }
            }
            case 6 -> kynaraRupture(player);
            default -> {
            }
        }
    }

    // ---- Page 1: allies ----

    private void summonMob(Player player, int index) {
        int cost = MOB_COSTS[index];
        if (!canAfford(player, cost)) {
            player.sendMessage(Component.text("You need " + cost + " levels to summon a " + MOB_NAMES[index] + ".",
                    NamedTextColor.RED));
            return;
        }

        Location base = player.getLocation();
        World w = base.getWorld();
        String ownerId = player.getUniqueId().toString();
        int count = MOB_TYPES[index] == EntityType.WOLF ? WOLF_COUNT : 1;
        List<LivingEntity> spawned = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            org.bukkit.entity.Entity entity = w.spawnEntity(safeSpot(base, index + i), MOB_TYPES[index]);
            if (!(entity instanceof LivingEntity mob)) {
                entity.remove();
                continue;
            }
            mob.setPersistent(false);
            mob.setRemoveWhenFarAway(false);
            mob.customName(Component.text(player.getName() + "'s " + MOB_TYPES[index].name().toLowerCase()
                    .replace('_', ' '), NamedTextColor.LIGHT_PURPLE));
            mob.getPersistentDataContainer().set(allyKey, PersistentDataType.STRING, ownerId);
            if (mob instanceof Wolf wolf) {
                wolf.setTamed(true);
                wolf.setOwner(player);
            } else if (mob instanceof IronGolem golem) {
                golem.setPlayerCreated(true);
            }
            spawned.add(mob);
        }
        if (spawned.isEmpty()) {
            player.sendMessage(Component.text("The summon failed.", NamedTextColor.RED));
            return; // no levels taken
        }

        charge(player, cost); // only now that something really appeared

        List<LivingEntity> list = allies.computeIfAbsent(player.getUniqueId(), k -> new ArrayList<>());
        list.addAll(spawned);
        while (list.size() > MAX_ALLIES) {
            LivingEntity oldest = list.remove(0);
            if (oldest.isValid()) oldest.remove();
        }

        w.spawnParticle(Particle.WITCH, base.clone().add(0, 1, 0), 40, 2, 0.5, 2, 0.1);
        w.playSound(base, Sound.ENTITY_EVOKER_PREPARE_SUMMON, 1.0f, 1.0f);
        player.sendMessage(Component.text("You summoned " + MOB_NAMES[index] + "!", NamedTextColor.LIGHT_PURPLE));

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            for (LivingEntity mob : spawned) {
                if (mob.isValid()) {
                    mob.getWorld().spawnParticle(Particle.POOF, mob.getLocation().add(0, 0.5, 0), 10, 0.3, 0.3, 0.3, 0.02);
                    mob.remove();
                }
            }
            List<LivingEntity> current = allies.get(player.getUniqueId());
            if (current != null) current.removeAll(spawned);
        }, ALLY_SECONDS * 20L);
    }

    /** A free, solid spot around the given place: two free blocks above a solid block, near the player. */
    private Location safeSpot(Location around, int index) {
        World w = around.getWorld();
        for (int attempt = 0; attempt < 12; attempt++) {
            double angle = (Math.PI * 2 / 4.0) * index + attempt * 0.9;
            double distance = 2.0 + (attempt / 4) * 1.0;
            int x = around.getBlockX() + (int) Math.round(Math.cos(angle) * distance);
            int z = around.getBlockZ() + (int) Math.round(Math.sin(angle) * distance);
            for (int dy = 2; dy >= -3; dy--) {
                int y = around.getBlockY() + dy;
                Block floor = w.getBlockAt(x, y - 1, z);
                Block feet = w.getBlockAt(x, y, z);
                Block head = w.getBlockAt(x, y + 1, z);
                if (floor.getType().isSolid() && feet.isPassable() && !feet.isLiquid()
                        && head.isPassable() && !head.isLiquid()) {
                    return new Location(w, x + 0.5, y, z + 0.5);
                }
            }
        }
        return around.clone(); // nowhere better: right where the player stands
    }

    private void removeAllies(UUID owner) {
        List<LivingEntity> list = allies.remove(owner);
        if (list == null) return;
        for (LivingEntity ally : list) {
            if (ally.isValid()) {
                ally.getWorld().spawnParticle(Particle.POOF, ally.getLocation().add(0, 0.5, 0), 10, 0.3, 0.3, 0.3, 0.02);
                ally.remove();
            }
        }
    }

    private UUID allyOwner(org.bukkit.entity.Entity entity) {
        String id = entity.getPersistentDataContainer().get(allyKey, PersistentDataType.STRING);
        if (id == null) return null;
        try {
            return UUID.fromString(id);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /** Allies never pick their owner (or the owner's other allies) as a target. */
    @EventHandler(ignoreCancelled = true)
    public void onAllyTarget(EntityTargetLivingEntityEvent event) {
        UUID owner = allyOwner(event.getEntity());
        if (owner == null || event.getTarget() == null) return;
        LivingEntity target = event.getTarget();
        if (target.getUniqueId().equals(owner) || owner.equals(allyOwner(target))) event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onAllyDamage(EntityDamageByEntityEvent event) {
        org.bukkit.entity.Entity damager = event.getDamager();
        if (damager instanceof Projectile proj && proj.getShooter() instanceof org.bukkit.entity.Entity shooter) {
            damager = shooter;
        }
        org.bukkit.entity.Entity victim = event.getEntity();

        // 1. Allies can't hurt their owner or each other
        UUID damagerOwner = allyOwner(damager);
        if (damagerOwner != null
                && (victim.getUniqueId().equals(damagerOwner) || damagerOwner.equals(allyOwner(victim)))) {
            event.setCancelled(true);
            return;
        }

        // 2. When the owner is hit, or hits something, the allies go after that enemy
        if (victim instanceof Player ownerVictim && damager instanceof LivingEntity enemy
                && allyOwner(enemy) == null && !enemy.equals(ownerVictim)) {
            sendAlliesAfter(ownerVictim.getUniqueId(), enemy);
        } else if (damager instanceof Player ownerDamager && victim instanceof LivingEntity enemy
                && allyOwner(enemy) == null && !enemy.equals(ownerDamager)) {
            sendAlliesAfter(ownerDamager.getUniqueId(), enemy);
        }
    }

    private void sendAlliesAfter(UUID owner, LivingEntity enemy) {
        List<LivingEntity> list = allies.get(owner);
        if (list == null) return;
        for (LivingEntity ally : list) {
            if (ally.isValid() && ally instanceof Mob mob && !ally.equals(enemy)) {
                mob.setTarget(enemy);
            }
        }
    }

    @EventHandler
    public void onOwnerDeath(PlayerDeathEvent event) {
        removeAllies(event.getEntity().getUniqueId());
    }

    @EventHandler
    public void onOwnerQuit(PlayerQuitEvent event) {
        removeAllies(event.getPlayer().getUniqueId());
    }

    // ---- Page 2: magic tools ----

    private void forgeTools(Player player) {
        if (!pay(player, USE_COST[1])) return;
        var leftovers = player.getInventory().addItem(
                createTool(Material.NETHERITE_PICKAXE, "Book-Forged Pickaxe"),
                createTool(Material.NETHERITE_AXE, "Book-Forged Axe"),
                createTool(Material.NETHERITE_SHOVEL, "Book-Forged Shovel"));
        leftovers.values().forEach(i -> player.getWorld().dropItemNaturally(player.getLocation(), i));
        player.playSound(player.getLocation(), Sound.BLOCK_SMITHING_TABLE_USE, 1.0f, 1.0f);
        player.sendMessage(Component.text("The book forges you three tools.", NamedTextColor.LIGHT_PURPLE));
    }

    // ---- Pages 3 and 6: saved places ----

    /** /setorigin: saves where you are as your Point of Origin. */
    public void setOrigin(Player player) {
        saveSpot(player, originKey);
        player.sendMessage(Component.text("Point of Origin set to " + player.getLocation().getBlockX() + " "
                + player.getLocation().getBlockY() + " " + player.getLocation().getBlockZ() + ".",
                NamedTextColor.LIGHT_PURPLE));
    }

    private void saveSpot(Player player, NamespacedKey key) {
        Location l = player.getLocation();
        String text = l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ()
                + ";" + l.getYaw() + ";" + l.getPitch();
        player.getPersistentDataContainer().set(key, PersistentDataType.STRING, text);
    }

    private Location readSpot(Player player, NamespacedKey key) {
        PersistentDataContainer pdc = player.getPersistentDataContainer();
        String text = pdc.get(key, PersistentDataType.STRING);
        if (text == null) return null;
        try {
            String[] p = text.split(";");
            World w = plugin.getServer().getWorld(p[0]);
            if (w == null) return null;
            return new Location(w, Double.parseDouble(p[1]), Double.parseDouble(p[2]), Double.parseDouble(p[3]),
                    Float.parseFloat(p[4]), Float.parseFloat(p[5]));
        } catch (RuntimeException e) {
            return null;
        }
    }

    private void teleportToSaved(Player player, NamespacedKey key, String what, String missing, int cost) {
        Location dest = readSpot(player, key);
        if (dest == null) {
            player.sendMessage(Component.text("You don't have a " + what + " yet. " + missing, NamedTextColor.RED));
            return;
        }
        if (!canAfford(player, cost)) {
            player.sendMessage(Component.text("You need " + cost + " levels for that.", NamedTextColor.RED));
            return;
        }
        player.teleportAsync(dest).thenAccept(ok -> plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (!ok || !player.isOnline()) return;
            charge(player, cost);
            player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
            player.sendMessage(Component.text("Teleported to your " + what + ".", NamedTextColor.LIGHT_PURPLE));
        }));
    }

    // ---- Page 4: siphon ----

    private void siphon(Player player) {
        int gained = 0;
        for (Player other : player.getWorld().getNearbyPlayers(player.getLocation(), SIPHON_RADIUS)) {
            if (other.equals(player)) continue;
            int take = Math.min(SIPHON_MAX_LEVELS_PER_PLAYER, other.getLevel());
            if (take <= 0) continue;
            other.setLevel(other.getLevel() - take);
            other.sendMessage(Component.text(player.getName() + " siphoned " + take + " of your levels!",
                    NamedTextColor.RED));
            gained += take;
        }
        player.giveExpLevels(gained);

        var maxHealth = player.getAttribute(Attribute.MAX_HEALTH);
        player.setHealth(maxHealth != null ? maxHealth.getValue() : 20.0);
        player.setFoodLevel(20);
        player.setSaturation(20f);
        player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 20 * 20, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 20 * 20, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 20 * 10, 1));

        player.getWorld().spawnParticle(Particle.ENCHANT, player.getLocation().add(0, 1, 0), 60, 1, 1, 1, 0.5);
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 0.6f);
        player.sendMessage(Component.text(gained > 0
                ? "You siphoned " + gained + " levels and feel invincible!"
                : "Nobody nearby had any levels, but the book still heals you.", NamedTextColor.LIGHT_PURPLE));
    }

    // ---- Page 5: randomizer ----

    private void randomizer(Player player) {
        if (!pay(player, USE_COST[4])) return;
        List<PotionEffectType> pool = new ArrayList<>(List.of(RANDOM_EFFECTS));
        List<String> names = new ArrayList<>();
        for (int i = 0; i < RANDOMIZER_EFFECTS && !pool.isEmpty(); i++) {
            PotionEffectType type = pool.remove(random.nextInt(pool.size()));
            int amplifier = random.nextInt(3);
            player.addPotionEffect(new PotionEffect(type, RANDOMIZER_SECONDS * 20, amplifier));
            names.add(type.getKey().getKey().replace('_', ' ') + " " + (amplifier + 1));
        }
        player.playSound(player.getLocation(), Sound.BLOCK_BREWING_STAND_BREW, 1.0f, 1.0f);
        player.sendMessage(Component.text("The dice land on: " + String.join(", ", names), NamedTextColor.LIGHT_PURPLE));
    }

    // ---- Page 7: Kynara Rupture ----

    private void kynaraRupture(Player player) {
        if (!pay(player, USE_COST[6])) return;
        Location center = player.getLocation();
        World w = center.getWorld();

        for (LivingEntity target : w.getNearbyLivingEntities(center, RUPTURE_RADIUS)) {
            if (target.equals(player)) continue;
            Vector push = target.getLocation().toVector().subtract(center.toVector()).setY(0);
            if (push.lengthSquared() < 0.0001) push = new Vector(1, 0, 0);
            target.damage(RUPTURE_DAMAGE, player);
            target.setVelocity(push.normalize().multiply(RUPTURE_PUSH).setY(0.8));
        }

        w.spawnParticle(Particle.EXPLOSION_EMITTER, center, 6, 4, 1, 4, 0);
        w.spawnParticle(Particle.PORTAL, center.clone().add(0, 1, 0), 400, 8, 3, 8, 1.0);
        w.strikeLightningEffect(center);
        w.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.5f);
        w.playSound(center, Sound.ENTITY_WITHER_SPAWN, 1.0f, 0.5f);
        player.sendMessage(Component.text("KYNARA RUPTURE!", NamedTextColor.DARK_PURPLE, TextDecoration.BOLD));
    }
}
